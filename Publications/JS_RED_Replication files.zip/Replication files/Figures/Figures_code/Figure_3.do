* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* Figure 3

cd "$figpath"
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Load the model results produced by Matlab
import delimited "Figure3_model.csv", clear 
ren v2 LEVq_p50
ren v4 LTD_shareq_p50
ren v6 age_ipo_p50
ren v8 spread_p50
replace spread_p50 = spread_p50 * 100
ren v10 inv_p50
keep *_p50
gen size = _n
gen data = 2
save model_results_size.dta, replace


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Load the Compustat data 
use databins_size3, clear

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Combine empirical data and model results
gen data = 1
label define datl 1 "Data" 2 "Model" 
label values data datl  
append using model_results_size
erase model_results_size.dta

generate datasize = data      if size == 1
replace  datasize = data + 3  if size == 2
replace  datasize = data + 6  if size == 3
replace  datasize = data + 9  if size == 4
replace  datasize = data + 12  if size == 5
lab var datasize "Size"

* Variables in %
replace LEVq_p50 = LEVq_p50 * 100
replace LEVq_lb = LEVq_lb * 100
replace LEVq_ub = LEVq_ub * 100
replace LTD_shareq_p50 = LTD_shareq_p50 * 100
replace LTD_shareq_lb = LTD_shareq_lb * 100
replace LTD_shareq_ub = LTD_shareq_ub * 100


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* Create plots
* Plots are saved inside Figures_data subdirectory

* Leverage
twoway (bar LEVq_p50 datasize if data==1, bcolor(ltblue)) (bar LEVq_p50 datasize if data==2 ) (rcap LEVq_lb LEVq_ub datasize, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) title("Leverage (in %)") xtitle("Size", size(large)) saving(Fig3_a, replace) nodraw

* LTD share
twoway (bar LTD_shareq_p50 datasize if data==1, bcolor(ltblue)) (bar LTD_shareq_p50 datasize if data==2 ) (rcap LTD_shareq_lb LTD_shareq_ub datasize, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) title("Long-term debt share (in %)") xtitle("Size", size(large)) ylabel(0(20)100) saving(Fig3_b, replace) nodraw

* Spreads
twoway (bar spread_p50 datasize if data==1, bcolor(ltblue)) (bar spread_p50 datasize if data==2 ) (rcap spread_lb spread_ub datasize, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(0(1)6, labsize(large)) graphregion(color(white)) title("Credit spread on long-term debt (in %)") xtitle("Size", size(large)) saving(Fig3_c, replace) nodraw

* Age
twoway (bar age_ipo_p50 datasize if data==1, bcolor(ltblue)) (bar age_ipo_p50 datasize if data==2 ) (rcap age_ipo_lb age_ipo_ub datasize, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) title("Age (in quarters)") xtitle("Size", size(large)) saving(Fig3_d, replace) nodraw

* Investment rate (used for Figure 5)
twoway (bar inv_p50 datasize if data==1, bcolor(ltblue)) (bar inv_p50 datasize if data==2 ) (rcap inv_lb inv_ub datasize, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) title("Investment rate") xtitle("Size", size(large)) ysc(r(0 .04)) ylabel(0(.01).04) saving(Fig5_a, replace) nodraw

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Draw Figure
graph combine Fig3_a.gph Fig3_b.gph Fig3_c.gph Fig3_d.gph, title("Figure 3") saving(Fig3, replace) name(Fig3, replace)
cap graph close Graph








