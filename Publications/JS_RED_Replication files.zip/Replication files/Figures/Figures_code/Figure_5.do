* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* Figure 5

cd "$figpath"

* Load the model results produced by Matlab
import delimited "Figure3_model.csv", clear 
ren v27 LT_share_issue_p50
ren v28 eq_issue_share_p50
ren v29 xfin_share_p50
keep *_p50
gen size = _n
gen data = 2
save model_results_size.dta, replace


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Load the Compustat data 
use databins_size5, clear

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Combine empirical data and model results
gen data = 1
label define datl 1 "Data" 2 "Model" 
label values data datl  
append using model_results_size
erase model_results_size.dta

generate datasize = data      if size == 1
replace  datasize = data + 3  if size == 2
replace  datasize = data + 6  if size == 3
replace  datasize = data + 9  if size == 4
replace  datasize = data + 12  if size == 5
lab var datasize "Size"

* Express in %
replace LT_share_issue_p50 = LT_share_issue_p50 * 100
replace LT_share_issue_lb = LT_share_issue_lb * 100
replace LT_share_issue_ub = LT_share_issue_ub * 100
replace xfin_share_p50 = xfin_share_p50 * 100
replace xfin_share_lb = xfin_share_lb * 100
replace xfin_share_ub = xfin_share_ub * 100

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* Create plots
* Plots are saved inside Figures_data subdirectory


* Investment rate plot was created in Figure_3.do


* LTD share of debt issuance
twoway (bar LT_share_issue_p50 datasize if data==1, bcolor(ltblue)) (bar LT_share_issue_p50 datasize if data==2 ) (rcap LT_share_issue_lb LT_share_issue_ub datasize, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) xtitle("Size", size(large)) title("Long-term debt share of debt issuance (in %)") ylabel(0(20)100) saving(Fig5_b, replace) nodraw 


* Equity share of external financing
twoway (bar eq_issue_share_p50 datasize if data==1, bcolor(ltblue)) (bar eq_issue_share_p50 datasize if data==2 ) (rcap eq_issue_share_lb eq_issue_share_ub datasize, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) xtitle("Size", size(large)) title("Equity share of external financing") ylabel(-1.5(.5)1.5) saving(Fig5_c, replace) nodraw 


* External finance share
twoway (bar xfin_share_p50 datasize if data==1, bcolor(ltblue)) (bar xfin_share_p50 datasize if data==2 ) (rcap xfin_share_lb xfin_share_ub datasize, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) xtitle("Size", size(large)) title("External finance as fraction of total assets (in %)") saving(Fig5_d, replace) nodraw 


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Draw Figure
graph combine Fig5_a.gph Fig5_b.gph Fig5_c.gph Fig5_d.gph, title("Figure 5") saving(Fig5, replace) name(Fig5, replace)
cap graph close Graph



* * * * * 
