% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% Master file for Figure 2 (created in Matlab)
% Note: Figures 3,4,5,6 are produced in Stata. Please use the file
% MASTER_Figures.do to replicate them.

clear all
clc
close all

% Direct Matlab to the "Replication files" directory:
direc       = '...\Replication files';
mainfolder      = sprintf('%s/Figures/Figures_code',direc);
cd(mainfolder)
datafolder      = sprintf('%s/Figures/Figures_data',direc);

%% Figure 2: Firm policies

Figure_2

% end of code

