* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* Figure 6

cd "$figpath"

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Load the model results produced by Matlab
import delimited "Figure4_model.csv", clear 
ren v27 LT_share_issue_p50
ren v28 eq_issue_share_p50
ren v29 xfin_share_p50
keep *_p50
gen agegroup = _n
gen data = 2
save model_results_age.dta, replace

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Load the Compustat data 
use databins_age6, clear

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Combine empirical data and model results
gen data = 1
label define datl 1 "Data" 2 "Model" 
label values data datl  
append using model_results_age
erase model_results_age.dta

generate dataage = data      if agegroup == 1
replace  dataage = data + 3  if agegroup == 2
replace  dataage = data + 6  if agegroup == 3
replace  dataage = data + 9  if agegroup == 4
replace  dataage = data + 12  if agegroup == 5
lab var dataage "Age"

replace LT_share_issue_p50 = LT_share_issue_p50 * 100
replace LT_share_issue_lb = LT_share_issue_lb * 100
replace LT_share_issue_ub = LT_share_issue_ub * 100
replace xfin_share_p50 = xfin_share_p50 * 100
replace xfin_share_lb = xfin_share_lb * 100
replace xfin_share_ub = xfin_share_ub * 100

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* Create plots
* Plots are saved inside Figures_data subdirectory


* Investment rate plot was created in Figure_4.do


* LTD share of debt issuance
twoway (bar LT_share_issue_p50 dataage if data==1, bcolor(ltblue)) (bar LT_share_issue_p50 dataage if data==2 ) (rcap LT_share_issue_lb LT_share_issue_ub dataage, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) xtitle("Age", size(large)) title("Long-term debt share of debt issuance (in %)") ylabel(0(20)100) saving(Fig6_b, replace) nodraw 


* Equity share of new capital
twoway (bar eq_issue_share_p50 dataage if data==1, bcolor(ltblue)) (bar eq_issue_share_p50 dataage if data==2 ) (rcap eq_issue_share_lb eq_issue_share_ub dataage, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) xtitle("Age", size(large)) title("Equity share of external financing") ylabel(-.5(.5)1.0) saving(Fig6_c, replace) nodraw


* External finance share
twoway (bar xfin_share_p50 dataage if data==1, bcolor(ltblue)) (bar xfin_share_p50 dataage if data==2 ) (rcap xfin_share_lb xfin_share_ub dataage, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) xtitle("Age", size(large)) title("External finance as fraction of total assets (in %)") saving(Fig6_d, replace) nodraw 


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Draw Figure
graph combine Fig6_a.gph Fig6_b.gph Fig6_c.gph Fig6_d.gph, title("Figure 6") saving(Fig6, replace) name(Fig6, replace)
cap graph close Graph











