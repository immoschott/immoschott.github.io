* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* Master file for Figures 3,4,5,6 (created in Stata)
* Note: Figure 2 is produced in Matlab. Please use the file MASTER_Figures.m to replicate it.

clear

* * * * * *
* INSTRUCTIONS: 	Change the working directory "path" below to direct to the folder "REPLICATION FILES"
* * * * * *


global path ".../Replication files"


* The following path names do not have to be changed:
global datapath "$path/Empirical/Data"
global figpath 	"$path/Figures/Figures_data"
global codepath "$path/Figures/Figures_code"

* * * * * * * 
* Figure 3: Firm variables conditional on size
cd "$codepath"
qui do Figure_3.do


* * * * * * * 
* Figure 4: Firm variables conditional on age
cd "$codepath"
qui do Figure_4.do


* * * * * * * 
* Figure 5: Flow variables conditional on size
cd "$codepath"
qui do Figure_5.do


* * * * * * * 
* Figure 6: Flow variables conditional on age
cd "$codepath"
qui do Figure_6.do

