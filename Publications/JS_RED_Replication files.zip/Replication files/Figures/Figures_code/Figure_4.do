* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* Figure 4

cd "$figpath"
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Load the model results produced by Matlab
import delimited "Figure4_model.csv", clear 
ren v2 LEVq_p50
ren v4 LTD_shareq_p50
ren v6 size
gen latq_p50 = log(size)
ren v8 spread_p50
replace spread_p50 = spread_p50 * 100
ren v10 inv_p50
keep *_p50
gen agegroup = _n
gen data = 2
save model_results_age.dta, replace


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Load the Compustat data 
use databins_age4, clear


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Combine empirical data and model results
gen data = 1
label define datl 1 "Data" 2 "Model" 
label values data datl  
append using model_results_age
erase model_results_age.dta

generate dataage = data      if agegroup == 1
replace  dataage = data + 3  if agegroup == 2
replace  dataage = data + 6  if agegroup == 3
replace  dataage = data + 9  if agegroup == 4
replace  dataage = data + 12  if agegroup == 5
lab var dataage "Age"

* Variables in %
replace LEVq_p50 = LEVq_p50 * 100
replace LEVq_lb = LEVq_lb * 100
replace LEVq_ub = LEVq_ub * 100
replace LTD_shareq_p50 = LTD_shareq_p50 * 100
replace LTD_shareq_lb = LTD_shareq_lb * 100
replace LTD_shareq_ub = LTD_shareq_ub * 100

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* Create plots
* Plots are saved inside Figures_data subdirectory

* Leverage
twoway (bar LEVq_p50 dataage if data==1, bcolor(ltblue)) (bar LEVq_p50 dataage if data==2 ) (rcap LEVq_lb LEVq_ub dataage, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(0(10)40, labsize(large)) graphregion(color(white)) title("Leverage (in %)") xtitle("Age", size(large)) saving(Fig4_a, replace) nodraw

* LTD share
twoway (bar LTD_shareq_p50 dataage if data==1, bcolor(ltblue)) (bar LTD_shareq_p50 dataage if data==2 ) (rcap LTD_shareq_lb LTD_shareq_ub dataage, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) title("Long-term debt share (in %)") xtitle("Age", size(large)) ylabel(0(20)100) saving(Fig4_b, replace) nodraw

* Spreads
twoway (bar spread_p50 dataage if data==1, bcolor(ltblue)) (bar spread_p50 dataage if data==2 ) (rcap spread_lb spread_ub dataage, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) title("Credit spread on long-term debt (in %)") xtitle("Age", size(large)) ylabel(0(1)5) saving(Fig4_c, replace) nodraw

* Size --> Normalize the last bin to 1
gen size_plot = latq_p50 
gen tmp_d = size_plot if agegroup == 5 & data == 1
egen tmp_dd = max(tmp_d) if data == 1
replace size_plot = size_plot / tmp_dd if data == 1
gen size_lb = latq_lb / tmp_dd 
gen size_ub = latq_ub / tmp_dd 
drop tmp_d*
gen tmp_m = size_plot if agegroup == 5 & data == 2
egen tmp_mm = max(tmp_m) if data == 2
replace size_plot = size_plot / tmp_mm if data == 2
drop tmp_m*

twoway (bar size_plot dataage if data==1, bcolor(ltblue)) (bar size_plot dataage if data==2 ) (rcap size_lb size_ub dataage, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) title("Size (normalized)") xtitle("Age", size(large)) ylabel(0(.2)1) saving(Fig4_d, replace) nodraw


* Investment rate (used for Figure 6)
twoway (bar inv_p50 dataage if data==1, bcolor(ltblue)) (bar inv_p50 dataage if data==2 ) (rcap inv_lb inv_ub dataage, msize(*3) lcolor(emidblue)), legend(order(1 "Data" 2 "Model")) legend(size(large))   xla(, nolabels) yla(, labsize(large)) graphregion(color(white)) title("Investment rates") xtitle("Age", size(large)) ylabel(0(.02).06) saving(Fig6_a, replace) nodraw



* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Draw Figure
graph combine Fig4_a.gph Fig4_b.gph Fig4_c.gph Fig4_d.gph, title("Figure 4") saving(Fig4, replace) name(Fig4, replace)
cap graph close Graph










