% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% Create an initial guess for the firm problem

if VAL.period== 1 % period T-1
    if bb == 1
        if zz == 1
            opt_ini = [1.5,  0.3]; % capital, leverage
        else
            opt_ini = [VAL.cap_pol(bb,zz-1),    VAL.lev_pol(bb,zz-1)];
        end
    elseif bb > 1
        % Use previous result as initial guess
        opt_ini         = [VAL.cap_pol(bb-1,zz),    VAL.lev_pol(bb-1,zz)];
    end
else % period T-x
    opt_ini         = [ VAL.HISTORY{VAL.period-1}.cap_pol(bb,zz), VAL.HISTORY{VAL.period-1}.lev_pol(bb,zz)];
end

%% Upper and lower bound for firm problem
if VAL.period == 1
    
    lb0             = 0.1;
    ub0             = 100.0;
    lb_lev          = 0.03;
    ub_lev          = 0.30;
    
    if zz==1
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==2
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==3
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==4
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==5
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==6
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==7
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==8
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    else
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    end
    
elseif VAL.period > 1
    lb0             = 0;
    ub0             = 100.0;
    lb_lev          = 0.03;
    ub_lev          = 0.45;
        
    lb          = [lb0,   0 ];  % Capital, Leverage
    ub          = [ub0,   1.10 ];
end
