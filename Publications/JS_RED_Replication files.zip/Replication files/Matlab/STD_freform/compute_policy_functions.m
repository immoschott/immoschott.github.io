% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% Assign optimal policy

cap_pol(bb,zz)      = eq_out.Kstar;
lev_pol(bb,zz)      = eq_out.Levstar;
lab_pol(bb,zz)      = eq_out.Lstar;
if VAL.period > 1
    mat_pol(bb,zz)  = eq_out.Mstar;
else
    mat_pol(bb,zz)  = 1; 
end

% Default decision
epsbar_pol(bb,zz)   = eq_out.epsbar;

eq_pol(bb,zz)       = eq_out.eprime;
std_pol(bb,zz)      = eq_out.Kstar * eq_out.Levstar;
if VAL.period > 1
    ltd_pol(bb,zz)      = eq_out.Kstar * eq_out.Levstar * eq_out.Mstar;
end

% Prices and value function
if VAL.period == 1
    p_pol(bb,zz)        = 1; 
    ps_pol(bb,zz)       = eq_out.P_ltd;
else
    p_pol(bb,zz)        = eq_out.P_ltd;
    ps_pol(bb,zz)       = eq_out.P_std;
end

value_pol(bb,zz)    = eq_out.V; 
ktilde_pol(bb,zz)   = eq_out.ktilde;

VAL.cap_pol     = cap_pol;
VAL.lev_pol     = lev_pol;
VAL.lab_pol     = lab_pol;
VAL.mat_pol     = mat_pol;

