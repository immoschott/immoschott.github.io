% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020

% Easier reference:
interpmethod = PARMS.interpmethod;
extrapmethod = PARMS.extrapmethod;

def_pol     = 1/2 *(1+erf((epsbar_pol-0)/(PARMS.sigmaeps*sqrt(2)))); % Default rate

VAL.vF      = value_pol;
VAL.pF      = p_pol;
