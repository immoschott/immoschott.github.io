% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
%
%% Baseline parameters

PARMS.BETA              = 0.99;
PARMS.SDF               = PARMS.BETA;
PARMS.R                 = 1/PARMS.BETA - 1;
PARMS.C                 = 1/PARMS.BETA - 1;
PARMS.ZETA              = 0.75;
PARMS.PSI               = 0.33;
PARMS.DELTA             = 0.025;
PARMS.TAU               = 0.40;

PARMS.GAMMA             = 1;
PARMS.p_fl              = 1;
PARMS.THETA             = 2;            
PARMS.RHO               = 1;
PARMS.x                 = 0.017;        

% Equilibrium wage
PARMS.W                 = 0.732255;

PARMS.XI                = 0.095*0.75;
PARMS.sigmaeps          = 0.62;
PARMS.ETA               = 0;
PARMS.F                 = 0.299715;
PARMS.rhoz              = 0.965;
PARMS.sigma             = 0.2050 * 1.4142;

%% Exogenous productivity grid

% Determine grid length
PARMS.lenz              = 16; 
muz                     = 0; 
Z                       = muz + linspace(-PARMS.sigma,PARMS.sigma,PARMS.lenz);
Z                       = exp(Z);
% Ensure that Matlab recognizes the grid as uniformly spaced
Z                       = linspace(Z(1),Z(end),PARMS.lenz);
PARMS.Z                 = Z(:);
clear muz

%% Debt grids
PARMS.DEBT              = cell(PARMS.lenz,1);
PARMS.lenb              = 1;
PARMS.DEBT{1}           = 0;
PARMS.DEBT{2}           = 0;
PARMS.DEBT{3}           = 0;
PARMS.DEBT{4}           = 0;
PARMS.DEBT{5}           = 0;
PARMS.DEBT{6}           = 0;
PARMS.DEBT{7}           = 0;
PARMS.DEBT{8}           = 0;
PARMS.DEBT{9}           = 0;
PARMS.DEBT{10}          = 0;
PARMS.DEBT{11}          = 0;
PARMS.DEBT{12}          = 0;
PARMS.DEBT{13}          = 0;
PARMS.DEBT{14}          = 0;
PARMS.DEBT{15}          = 0;
PARMS.DEBT{16}          = 0;

%% Setup solution method

% Interpolation method
PARMS.interpmethod      = 'cubic';
PARMS.extrapmethod      = 'linear';
% Error for Euler equation
PARMS.fzero_options     = optimset('TolX',1e-07,'TolFun',1e-07);
% Tolerance for the firm problem
PARMS.options_fmsb      = optimset('TolFun',1.e-09,'Display','off','TolX',1.e-09);

PARMS.tabfolder         = tabfolder;
PARMS.figfolder         = figfolder;

