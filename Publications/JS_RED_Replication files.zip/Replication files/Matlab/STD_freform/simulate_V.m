% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020 

value_pol_ini   = value_pol;
for aa  = 1:1000
    for zz = 1:lenz
        for bb = 1:lenb 
            
            % Define firm-level state
            S.DEBT  = PARMS.DEBT{zz}(bb);
            S.zz    = zz;

            optimum     = [cap_pol(bb,zz), lev_pol(bb,zz)];

            [~, eq_out] = firm_optim(optimum,S,PARMS,VAL,1);
            
            % Prices and value function
            p_pol(bb,zz)        = eq_out.P_ltd; 
            value_pol(bb,zz)    = eq_out.V; 
            
        end % End of B loop
    end % End of Z loop
       
    VAL.vF              = value_pol;
    
end

