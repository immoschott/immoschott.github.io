% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates the results of the SHORT-TERM DEBT MODEL with the
% FINANCIAL REFORM in place.
% (This code is identical to MAIN_STD, except for the parameter XI which is
% reduced by 25%.)
% Approximate runtime = a few minutes
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

% Parameter values
set_parms

% Solve model 
solve_model(PARMS);

clear Z PARMS
fprintf('Done computing the STD model with the financial reform.\n');
% End of code