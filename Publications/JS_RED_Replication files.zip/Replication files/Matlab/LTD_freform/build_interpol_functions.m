% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020

% Easier reference:
interpmethod = PARMS.interpmethod;
extrapmethod = PARMS.extrapmethod;

def_pol     = 1/2 *(1+erf((epsbar_pol-0)/(PARMS.sigmaeps*sqrt(2)))); % Default rate

for zz = 1:PARMS.lenz    
    VAL.vF{zz}          = griddedInterpolant(PARMS.DEBT{zz},value_pol(:,zz),interpmethod,extrapmethod);
    VAL.pF{zz}          = griddedInterpolant(PARMS.DEBT{zz},p_pol(:,zz),interpmethod,extrapmethod);
end
