% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates the results of the BENCHMARK MODEL with long-term
% debt & short-term debt with the FINANCIAL REFORM in place
% (This code is identical to MAIN_Benchmark, except for parameter XI which is
% reduced by 25%.)
% Approximate runtime = 120 minutes
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

% Parameter values
set_parms

% Solve model 
solve_model(PARMS);

clear Z PARMS
fprintf('Solved LTD model with a financial reform.\n');   
% End of code