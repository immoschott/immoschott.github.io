% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% Stationary distribution of firms 
 
ztrans                          = zeros(lenz);
ztrans(1:lenz+1:lenz^2)         = PARMS.rhoz;  
ztrans(1+lenz:lenz+1:lenz^2)    = 1-PARMS.rhoz;  
ztrans(end,end)                 = 1;
trans                           = zeros(lenz);
for zz = 1:lenz  
    trans(zz,:)     = ztrans(zz,:) .* (1-def_pol(zz)) * (1-PARMS.x);   
end
clear ztrans

M                               = 1;  
entrants                        = zeros(lenz,1);
entrants(1)                     = 1;
I                               = eye(lenz); 
% Stationary distribution
probst                          = (I-trans')^(-1)*(entrants)*M;  
dist                            = probst;



