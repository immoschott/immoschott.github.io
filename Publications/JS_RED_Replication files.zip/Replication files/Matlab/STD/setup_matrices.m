% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020

lenb        = PARMS.lenb;
lenz        = PARMS.lenz;

% Choices
cap_pol     = zeros(lenb,lenz); % Capital
lev_pol     = zeros(lenb,lenz); % Leverage
lab_pol     = zeros(lenb,lenz); % Labor --> decided today
mat_pol     = zeros(lenb,lenz); % Maturity
%
epsbar_pol  = zeros(lenb,lenz); % EPSbar --> decided today
eq_pol      = zeros(lenb,lenz); % Equity
ltd_pol     = zeros(lenb,lenz); % Long-term debt
std_pol     = zeros(lenb,lenz); % Short-term debt

% Prices and value function
p_pol       = zeros(lenb,lenz); % LTD price
ps_pol      = zeros(lenb,lenz); % STD price
value_pol   = zeros(lenb,lenz); % Value
ktilde_pol  = zeros(lenb,lenz); % Decided today
