% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates the results of the SHORT-TERM DEBT MODEL
% Approximate runtime = two minutes
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

% Parameter values
set_parms

% Solve model 
solve_model(PARMS);

clear PARMS Z   
fprintf('Done computing the STD model.\n');
% End of code