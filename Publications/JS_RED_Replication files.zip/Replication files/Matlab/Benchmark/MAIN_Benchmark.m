% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates the results of the BENCHMARK model with long-term debt and short-term debt
% Approximate runtime = 120 minutes
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

% Parameter values
set_parms

% Solve model 
solve_model(PARMS);

clear Z PARMS
fprintf('Solved benchmark model.\n');   

   
% End of code