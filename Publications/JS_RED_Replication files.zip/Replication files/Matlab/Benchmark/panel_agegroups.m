% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% DEFINE AGE GROUPS
n                       = 5 + 1; % number of bins + 1
ptiles                  = round(linspace(0,100,n));
% Put same firm age restrictions as in the data
tmp                     = panel_age;
cutoff                  = 60; 
tmp(panel_age>cutoff)   = NaN;
edges                   = prctile(tmp(:),ptiles);
bins                    = discretize(tmp(:),edges,'IncludedEdge','right');
n                       = max(bins);

% Moments
modelmoms.age.lev_mean      = zeros(n,1); % Leverage
modelmoms.age.lev_p50       = zeros(n,1);
modelmoms.age.mat_mean      = zeros(n,1); % LTD share
modelmoms.age.mat_p50       = zeros(n,1);
modelmoms.age.lts_mean      = zeros(n,1); % LTD spread
modelmoms.age.lts_p50       = zeros(n,1);
modelmoms.age.size_mean     = zeros(n,1); % Size
modelmoms.age.size_p50      = zeros(n,1);
modelmoms.age.irate_mean    = zeros(n,1); % Investment rate
modelmoms.age.irate_p50     = zeros(n,1);
modelmoms.age.gy_mean       = zeros(n,1); % Sales growth
modelmoms.age.gy_p50        = zeros(n,1);
modelmoms.age.diss_mean     = zeros(n,1); % Debt issuance / assets
modelmoms.age.diss_p50      = zeros(n,1);
modelmoms.age.eqiss_mean    = zeros(n,1); % Equity issuance / assets
modelmoms.age.eqiss_p50     = zeros(n,1);
modelmoms.age.ltdiss_mean   = zeros(n,1); % LTD share of debt issuance
modelmoms.age.ltdiss_p50    = zeros(n,1);
modelmoms.age.eq_share_mean = zeros(n,1); % Equity share of external financing
modelmoms.age.eq_share_p50  = zeros(n,1);
modelmoms.age.outfin_mean   = zeros(n,1); % External finance as fraction of total assets
modelmoms.age.outfin_p50    = zeros(n,1);

% Aggregate moments
modelmoms.age.i_agg         = zeros(n,1); % Investment rate
modelmoms.age.gy_agg        = zeros(n,1); % Sales growth
modelmoms.age.diss_agg      = zeros(n,1); % Debt issuance / assets
modelmoms.age.eqiss_agg     = zeros(n,1); % Equity issuance / assets
modelmoms.age.ltdiss_agg    = zeros(n,1); % LTD share of debt issuance
modelmoms.age.eq_share_agg  = zeros(n,1); % Equity share of external financing
modelmoms.age.outfin_agg    = zeros(n,1); % External finance as fraction of total assets

for nn = 1:n 
    modelmoms.age.lev_mean(nn)      = mean(panel_leverage(bins==nn));
    modelmoms.age.lev_p50(nn)       = median(panel_leverage(bins==nn));
    modelmoms.age.mat_mean(nn)      = mean(panel_maturity(bins==nn));
    modelmoms.age.mat_p50(nn)       = median(panel_maturity(bins==nn));
    modelmoms.age.lts_mean(nn)      = mean(panel_ltspread(bins==nn));
    modelmoms.age.lts_p50(nn)       = median(panel_ltspread(bins==nn));
    modelmoms.age.size_mean(nn)     = mean(panel_k(bins==nn));
    modelmoms.age.size_p50(nn)      = median(panel_k(bins==nn));
    modelmoms.age.irate_mean(nn)    = mean(panel_irate(bins==nn),'omitnan');
    modelmoms.age.irate_p50(nn)     = median(panel_irate(bins==nn),'omitnan');
    modelmoms.age.diss_mean(nn)     = mean(panel_diss(bins==nn),'omitnan');
    modelmoms.age.diss_p50(nn)      = median(panel_diss(bins==nn),'omitnan');
    modelmoms.age.eqiss_mean(nn)    = mean(panel_eqiss(bins==nn),'omitnan');
    modelmoms.age.eqiss_p50(nn)     = median(panel_eqiss(bins==nn),'omitnan');
    modelmoms.age.ltdiss_mean(nn)   = mean(panel_ltdshare_iss(bins==nn),'omitnan');
    modelmoms.age.ltdiss_p50(nn)    = median(panel_ltdshare_iss(bins==nn),'omitnan');
    modelmoms.age.eq_share_mean(nn) = mean(panel_eqshare(bins==nn),'omitnan');
    modelmoms.age.eq_share_p50(nn)  = median(panel_eqshare(bins==nn),'omitnan');
    modelmoms.age.outfin_mean(nn)   = mean(panel_xshare(bins==nn),'omitnan');
    modelmoms.age.outfin_p50(nn)    = median(panel_xshare(bins==nn),'omitnan');
    
    modelmoms.age.i_agg(nn)         = sum(panel_i(bins==nn),'omitnan') / ...
        ((1-PARMS.DELTA)*sum(panel_k_lag(bins==nn),'omitnan'));
    modelmoms.age.gy_agg(nn)        = sum(panel_y(bins==nn),'omitnan')/sum(panel_y_lag(bins==nn),'omitnan') - 1;
    modelmoms.age.diss_agg(nn)      = sum(panel_dd(bins==nn),'omitnan')/sum(panel_k_lag(bins==nn),'omitnan');
    modelmoms.age.eqiss_agg(nn)     = sum(panel_deq(bins==nn),'omitnan')/sum(panel_k_lag(bins==nn),'omitnan');
    modelmoms.age.ltdiss_agg(nn)    = sum(panel_b_iss(bins==nn),'omitnan')/sum(panel_dd(bins==nn),'omitnan');
    modelmoms.age.eq_share_agg(nn)  = sum(panel_deq(bins==nn),'omitnan') / ...
        abs(sum(panel_deq(bins==nn),'omitnan') + sum(panel_dd(bins==nn),'omitnan'));
    modelmoms.age.outfin_agg(nn)    = abs(sum(panel_deq(bins==nn),'omitnan') + sum(panel_dd(bins==nn),'omitnan')) / ...
        sum(panel_k_lag(bins==nn),'omitnan');
end


%% Export age groups to Stata format
stata_model         = zeros(n,29);
% Micro moments
stata_model(:,1)    = modelmoms.age.lev_mean;
stata_model(:,2)    = modelmoms.age.lev_p50;
stata_model(:,3)    = modelmoms.age.mat_mean;
stata_model(:,4)    = modelmoms.age.mat_p50;
stata_model(:,5)    = modelmoms.age.size_mean;
stata_model(:,6)    = modelmoms.age.size_p50;
stata_model(:,7)    = modelmoms.age.lts_mean;
stata_model(:,8)    = modelmoms.age.lts_p50;
stata_model(:,9)    = modelmoms.age.irate_mean;
stata_model(:,10)   = modelmoms.age.irate_p50;
stata_model(:,11)   = modelmoms.age.gy_mean;
stata_model(:,12)   = modelmoms.age.gy_p50;
stata_model(:,13)   = modelmoms.age.diss_mean;
stata_model(:,14)   = modelmoms.age.diss_p50;
stata_model(:,15)   = modelmoms.age.eqiss_mean;
stata_model(:,16)   = modelmoms.age.eqiss_p50;
stata_model(:,17)   = modelmoms.age.ltdiss_mean;
stata_model(:,18)   = modelmoms.age.ltdiss_p50;
stata_model(:,19)   = modelmoms.age.eq_share_mean;
stata_model(:,20)   = modelmoms.age.eq_share_p50;
stata_model(:,21)   = modelmoms.age.outfin_mean;
stata_model(:,22)   = modelmoms.age.outfin_p50;
% Aggregate moments
stata_model(:,23)   = modelmoms.age.i_agg;
stata_model(:,24)   = modelmoms.age.gy_agg;
stata_model(:,25)   = modelmoms.age.diss_agg;
stata_model(:,26)   = modelmoms.age.eqiss_agg;
stata_model(:,27)   = modelmoms.age.ltdiss_agg;
stata_model(:,28)   = modelmoms.age.eq_share_agg;
stata_model(:,29)   = modelmoms.age.outfin_agg;

% Export to Stata format
% Save in Figures_data subfolder
filename            = sprintf('%s%s','Figure4_model','.csv');
fullname            = fullfile(PARMS.figfolder, filename);
writematrix(stata_model,fullname,'Delimiter','tab')


