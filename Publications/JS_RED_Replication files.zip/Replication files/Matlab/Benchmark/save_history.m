% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% Save all policies for this VAL.period
VAL.HISTORY{VAL.period}.cap_pol = cap_pol;
VAL.HISTORY{VAL.period}.lev_pol = lev_pol;
VAL.HISTORY{VAL.period}.lab_pol = lab_pol;
VAL.HISTORY{VAL.period}.mat_pol = mat_pol;
VAL.HISTORY{VAL.period}.epsbar_pol = epsbar_pol;
VAL.HISTORY{VAL.period}.eq_pol = eq_pol;
VAL.HISTORY{VAL.period}.ltd_pol = ltd_pol;
VAL.HISTORY{VAL.period}.std_pol = std_pol;
VAL.HISTORY{VAL.period}.p_pol = p_pol;
VAL.HISTORY{VAL.period}.ps_pol = ps_pol;
VAL.HISTORY{VAL.period}.value_pol = value_pol;
VAL.HISTORY{VAL.period}.ktilde_pol = ktilde_pol;

