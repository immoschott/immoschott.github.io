% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% DEFINE SIZE GROUPS
n                           = 5 + 1; % number of bins + 1
ptiles                      = round(linspace(0,100,n));
edges                       = prctile(panel_k_lag(:),ptiles);
bins                        = discretize(panel_k_lag(:),edges,'IncludedEdge','right');
n                           = max(bins);

% Micro moments
modelmoms.size.lev_mean     = zeros(n,1); % Leverage
modelmoms.size.lev_p50      = zeros(n,1);
modelmoms.size.mat_mean     = zeros(n,1); % LTD share
modelmoms.size.mat_p50      = zeros(n,1);
modelmoms.size.lts_mean     = zeros(n,1); % LTD spread
modelmoms.size.lts_p50      = zeros(n,1);
modelmoms.size.age_mean     = zeros(n,1); % Age
modelmoms.size.age_p50      = zeros(n,1);
modelmoms.size.irate_mean   = zeros(n,1); % Investment rate
modelmoms.size.irate_p50    = zeros(n,1);
modelmoms.size.gy_mean      = zeros(n,1); % Sales growth
modelmoms.size.gy_p50       = zeros(n,1);
modelmoms.size.diss_mean    = zeros(n,1); % Debt issuance / assets
modelmoms.size.diss_p50     = zeros(n,1);
modelmoms.size.eqiss_mean   = zeros(n,1); % Equity issuance / assets
modelmoms.size.eqiss_p50    = zeros(n,1);
modelmoms.size.ltdiss_mean  = zeros(n,1); % LTD share of debt issuance
modelmoms.size.ltdiss_p50   = zeros(n,1);
modelmoms.size.eq_share_mean= zeros(n,1); % Equity share of external financing
modelmoms.size.eq_share_p50 = zeros(n,1);
modelmoms.size.outfin_mean  = zeros(n,1); % External finance as fraction of total assets
modelmoms.size.outfin_p50   = zeros(n,1);

% Aggregate moments
modelmoms.size.i_agg        = zeros(n,1); % Investment rate
modelmoms.size.gy_agg       = zeros(n,1); % Sales growth
modelmoms.size.diss_agg     = zeros(n,1); % Debt issuance / assets
modelmoms.size.eqiss_agg    = zeros(n,1); % Equity issuance / assets
modelmoms.size.ltdiss_agg   = zeros(n,1); % LTD share of debt issuance
modelmoms.size.eq_share_agg = zeros(n,1); % Equity share of external financing
modelmoms.size.outfin_agg   = zeros(n,1); % External finance as fraction of total assets


for nn = 1:n
    modelmoms.size.lev_mean(nn)     = mean(panel_leverage(bins==nn));
    modelmoms.size.lev_p50(nn)      = median(panel_leverage(bins==nn));
    modelmoms.size.mat_mean(nn)     = mean(panel_maturity(bins==nn));
    modelmoms.size.mat_p50(nn)      = median(panel_maturity(bins==nn));
    modelmoms.size.lts_mean(nn)     = mean(panel_ltspread(bins==nn));
    modelmoms.size.lts_p50(nn)      = median(panel_ltspread(bins==nn));
    modelmoms.size.age_mean(nn)     = mean(panel_age(bins==nn));
    modelmoms.size.age_p50(nn)      = median(panel_age(bins==nn));
    modelmoms.size.irate_mean(nn)   = mean(panel_irate(bins==nn),'omitnan');
    modelmoms.size.irate_p50(nn)    = median(panel_irate(bins==nn),'omitnan');
    modelmoms.size.diss_mean(nn)    = mean(panel_diss(bins==nn),'omitnan');
    modelmoms.size.diss_p50(nn)     = median(panel_diss(bins==nn),'omitnan');
    modelmoms.size.eqiss_mean(nn)   = mean(panel_eqiss(bins==nn),'omitnan');
    modelmoms.size.eqiss_p50(nn)    = median(panel_eqiss(bins==nn),'omitnan');
    modelmoms.size.ltdiss_mean(nn)  = mean(panel_ltdshare_iss(bins==nn),'omitnan');
    modelmoms.size.ltdiss_p50(nn)   = median(panel_ltdshare_iss(bins==nn),'omitnan');
    modelmoms.size.eq_share_mean(nn)= mean(panel_eqshare(bins==nn),'omitnan');
    modelmoms.size.eq_share_p50(nn) = median(panel_eqshare(bins==nn),'omitnan');
    modelmoms.size.outfin_mean(nn)  = mean(panel_xshare(bins==nn),'omitnan');
    modelmoms.size.outfin_p50(nn)   = median(panel_xshare(bins==nn),'omitnan');    
    modelmoms.size.i_agg(nn)        = sum(panel_i(bins==nn),'omitnan') / ...
        ((1-PARMS.DELTA)*sum(panel_k_lag(bins==nn),'omitnan'));
    modelmoms.size.gy_agg(nn)       = sum(panel_y(bins==nn),'omitnan')/sum(panel_y_lag(bins==nn),'omitnan') - 1;
    modelmoms.size.diss_agg(nn)     = sum(panel_dd(bins==nn),'omitnan')/sum(panel_k_lag(bins==nn),'omitnan');
    modelmoms.size.eqiss_agg(nn)    = sum(panel_deq(bins==nn),'omitnan')/sum(panel_k_lag(bins==nn),'omitnan');
    modelmoms.size.ltdiss_agg(nn)   = sum(panel_b_iss(bins==nn),'omitnan')/sum(panel_dd(bins==nn),'omitnan');
    modelmoms.size.eq_share_agg(nn) = sum(panel_deq(bins==nn),'omitnan') / ...
        abs(sum(panel_deq(bins==nn),'omitnan') + sum(panel_dd(bins==nn),'omitnan'));
    modelmoms.size.outfin_agg(nn)   = abs(sum(panel_deq(bins==nn),'omitnan') + sum(panel_dd(bins==nn),'omitnan')) / ...
        sum(panel_k_lag(bins==nn),'omitnan');
end


%% Export size groups to Stata format
 
stata_model         = zeros(n,29);
% Micro moments
stata_model(:,1)    = modelmoms.size.lev_mean;
stata_model(:,2)    = modelmoms.size.lev_p50;
stata_model(:,3)    = modelmoms.size.mat_mean;
stata_model(:,4)    = modelmoms.size.mat_p50;
stata_model(:,5)    = modelmoms.size.age_mean;
stata_model(:,6)    = modelmoms.size.age_p50;
stata_model(:,7)    = modelmoms.size.lts_mean;
stata_model(:,8)    = modelmoms.size.lts_p50;
stata_model(:,9)    = modelmoms.size.irate_mean;
stata_model(:,10)   = modelmoms.size.irate_p50;
stata_model(:,11)   = modelmoms.size.gy_mean;
stata_model(:,12)   = modelmoms.size.gy_p50;
stata_model(:,13)   = modelmoms.size.diss_mean;
stata_model(:,14)   = modelmoms.size.diss_p50;
stata_model(:,15)   = modelmoms.size.eqiss_mean;
stata_model(:,16)   = modelmoms.size.eqiss_p50;
stata_model(:,17)   = modelmoms.size.ltdiss_mean;
stata_model(:,18)   = modelmoms.size.ltdiss_p50;
stata_model(:,19)   = modelmoms.size.eq_share_mean;
stata_model(:,20)   = modelmoms.size.eq_share_p50;
stata_model(:,21)   = modelmoms.size.outfin_mean;
stata_model(:,22)   = modelmoms.size.outfin_p50;
% Aggregate moments
stata_model(:,23)   = modelmoms.size.i_agg;
stata_model(:,24)   = modelmoms.size.gy_agg;
stata_model(:,25)   = modelmoms.size.diss_agg;
stata_model(:,26)   = modelmoms.size.eqiss_agg;
stata_model(:,27)   = modelmoms.size.ltdiss_agg;
stata_model(:,28)   = modelmoms.size.eq_share_agg;
stata_model(:,29)   = modelmoms.size.outfin_agg;

% Export to Stata format
% Save in Figures_data subfolder
filename            = sprintf('%s%s','Figure3_model','.csv');
fullname            = fullfile(PARMS.figfolder, filename);
writematrix(stata_model,fullname,'Delimiter','tab')


