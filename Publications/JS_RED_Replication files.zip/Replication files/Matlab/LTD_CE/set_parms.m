% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
%

%% Baseline parameters

PARMS.BETA              = 0.99;
PARMS.SDF               = PARMS.BETA;
PARMS.R                 = 1/PARMS.BETA - 1;
PARMS.C                 = 1/PARMS.BETA - 1;
PARMS.ZETA              = 0.75;
PARMS.PSI               = 0.33;
PARMS.DELTA             = 0.025;
PARMS.TAU               = 0.40;

PARMS.GAMMA             = 0.05;
PARMS.p_fl              = 1;
PARMS.THETA             = 2; 
PARMS.RHO               = 1;
PARMS.x                 = 0.017; 

% Equilibrium wage
PARMS.W                 = 0.72923;

PARMS.XI                = 0.9;
PARMS.sigmaeps          = 0.627;
PARMS.ETA               = 0.0035;
PARMS.F                 = 0.3032;
PARMS.rhoz              = 0.965;
PARMS.sigma             = 0.2050 * 1.4142;

%% Exogenous productivity grid

% Determine grid length
PARMS.lenz              = 16; % number of idiosyncratic productivity states
muz                     = 0;  
Z                       = muz + linspace(-PARMS.sigma,PARMS.sigma,PARMS.lenz);
Z                       = exp(Z);
% Ensure that Matlab recognizes the grid as uniformly spaced
Z                       = linspace(Z(1),Z(end),PARMS.lenz);
PARMS.Z                 = Z(:);
clear muz

%% Debt grids
PARMS.lenb              = 10;
PARMS.DEBT              = cell(PARMS.lenz,1);
PARMS.DEBT{1}           = linspace(0.0, 0.85,PARMS.lenb);
PARMS.DEBT{2}           = linspace(0.0, 2.10,PARMS.lenb);
PARMS.DEBT{3}           = linspace(0.0, 3.70,PARMS.lenb);
PARMS.DEBT{4}           = linspace(0.0, 5.70,PARMS.lenb);
PARMS.DEBT{5}           = linspace(0.0, 8.20,PARMS.lenb);
PARMS.DEBT{6}           = linspace(1.0, 10.60,PARMS.lenb);
PARMS.DEBT{7}           = linspace(2.0, 13.20,PARMS.lenb);
PARMS.DEBT{8}           = linspace(3.0, 16.10,PARMS.lenb);
PARMS.DEBT{9}           = linspace(4.0, 19.20,PARMS.lenb);
PARMS.DEBT{10}          = linspace(5.5, 22.70,PARMS.lenb);
PARMS.DEBT{11}          = linspace(7.0, 26.20,PARMS.lenb);
PARMS.DEBT{12}          = linspace(8.5, 30.00,PARMS.lenb);
PARMS.DEBT{13}          = linspace(10.0, 33.50,PARMS.lenb);
PARMS.DEBT{14}          = linspace(11.5, 37.50,PARMS.lenb);
PARMS.DEBT{15}          = linspace(13.0, 41.50,PARMS.lenb);
PARMS.DEBT{16}          = linspace(14.5, 45.00,PARMS.lenb);

%% Setup solution method

% Interpolation method
PARMS.interpmethod      = 'cubic';
PARMS.extrapmethod      = 'linear';
% Error for Euler equation
PARMS.fzero_options     = optimset('TolX',1e-07,'TolFun',1e-07);
% Tolerance for the firm problem
PARMS.options_fmsb      = optimset('TolFun',1.e-09,'Display','off','TolX',1.e-09);

PARMS.tabfolder         = tabfolder;
PARMS.figfolder         = figfolder;

