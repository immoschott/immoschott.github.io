% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates the results of the COUNTERFACTUAL model without debt
% dilution and debt overhang (Section 4.1 of the paper)
% Approximate runtime = 120 minutes
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

% Parameter values
set_parms

% Solve model 
solve_model(PARMS);

clear Z PARMS
fprintf('Solved LTD CE model.\n');   

% End of code