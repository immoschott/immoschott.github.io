% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% Create an initial guess for the firm problem

if VAL.period== 1
    % No maturity choice in period T-1
    if bb == 1
        if zz == 1
            opt_ini = [1.5,  0.3]; % capital, leverage
        else
            opt_ini = [VAL.cap_pol(bb,zz-1),    VAL.lev_pol(bb,zz-1)];
        end
    elseif bb > 1
        % Use previous result as initial guess
        opt_ini         = [VAL.cap_pol(bb-1,zz),    VAL.lev_pol(bb-1,zz)];
    end
else % T-x
    if VAL.period== 2
        % No maturity choice in T-1
        opt_ini         = [ VAL.HISTORY{VAL.period-1}.cap_pol(bb,zz),        VAL.HISTORY{VAL.period-1}.lev_pol(bb,zz), ...
            .75];  
    else
        % Create initial guess from last period's optimum
        opt_ini         = [ VAL.HISTORY{VAL.period-1}.cap_pol(bb,zz),        VAL.HISTORY{VAL.period-1}.lev_pol(bb,zz), ...
            VAL.HISTORY{VAL.period-1}.mat_pol(bb,zz)];
    end
end

%% Upper and lower bound for firm problem
if VAL.period == 1
    
    lb0             = 0.1;
    ub0             = 100.0;
    lb_lev          = 0.03;
    ub_lev          = 0.30;
    
    if zz==1
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==2
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==3
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==4
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==5
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==6
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==7
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    elseif zz==8
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    else
        lb          = [lb0,     lb_lev];  % Capital, Leverage
        ub          = [ub0,     ub_lev];
    end
    
elseif VAL.period > 1
    lb0             = 3.0;
    ub0             = 100.0;
    lb_lev          = 0.03;
    ub_lev          = 0.45;
    
    if zz==1
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     0.25   1+eps ];
    elseif zz==2
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     0.45  1+eps ];
    elseif zz==3
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     0.55   1+eps ];
    elseif zz==4
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     0.70   1+eps ];
    elseif zz==5
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     0.80   1+eps ];
    elseif zz==6
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     0.85   1+eps ];
    elseif zz==7
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     0.95   1+eps ];
    elseif zz==8
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     1.00   1+eps ];
    elseif zz==9
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     1.05   1+eps ];
    elseif zz==10
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     1.05   1+eps ];
    elseif zz==11
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     1.05   1+eps ];
    elseif zz==12
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     1.05   1+eps ];
    elseif zz==13
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     1.05   1+eps ];
    elseif zz==14
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     1.05   1+eps ];
    elseif zz==15
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     1.05   1+eps ];
    elseif zz==16
        lb          = [lb0,     lb_lev   0 ];
        ub          = [ub0,     1.05   1+eps ];
    end

    
end
