% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% Generate approximate values for bond price and value functions to speed up convergence
value_pol_ini   = value_pol;
for aa  = 1:1000
    for zz = 1:lenz
        for bb = 1:lenb 
            
            % Define firm-level state
            S.DEBT  = PARMS.DEBT{zz}(bb);
            S.zz    = zz;
            
            % Use policy function from T-1 and target for maturity            
            optimum     = [cap_pol(bb,zz), lev_pol(bb,zz), 1];
            
            % Obtain remaining variables
            [~, eq_out] = firm_optim(optimum,S,PARMS,VAL,1);
            
            % Prices and value function
            p_pol(bb,zz)        = eq_out.P_ltd; %#ok<SAGROW>
            value_pol(bb,zz)    = eq_out.V; %#ok<SAGROW> % the minus is already applied
            
        end % End of B loop
    end % End of Z loop
    
    % Update value an price
    % Create Z-specific functions to forecast future prices and values
    for zz = 1:PARMS.lenz 
        VAL.vF{zz}          = griddedInterpolant(PARMS.DEBT{zz},value_pol(:,zz),interpmethod,extrapmethod);
        VAL.pF{zz}          = griddedInterpolant(PARMS.DEBT{zz},p_pol(:,zz),interpmethod,extrapmethod);
    end
end
