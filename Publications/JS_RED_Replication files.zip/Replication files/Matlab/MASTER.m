% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% Master file 

clc
clear all

% Direct Matlab to the "Replication files" directory:
direc       = '...\Replication files';
mainfolder  = sprintf('%s/Matlab',direc);
cd(mainfolder)

% Folders to save output in
tabfolder   = sprintf('%s/Tables/Tables_data',direc);
figfolder   = sprintf('%s/Figures/Figures_data',direc);


%% BENCHMARK MODEL (model with long-term debt & short-term debt)
% This code generates the results of the BENCHMARK model with long-term
% debt & short-term debt
% Approximate runtime = 120 minutes
% 
newfolder  = sprintf('%s/Matlab/Benchmark',direc);
cd(newfolder)
MAIN_Benchmark

%%
%% MODEL EXPERIMENTS
%%

%% COUNTERFACTUAL model without debt dilution and debt overhang (LTD_CE)
% Section 4.1: "The cost of debt dilution and debt overhang"
% This code solves the counterfactual model without debt dilution and
% debt overhang from Section 4.1 of the paper (LTD_CE)
% and computes moments for Table 5.
% Approximate runtime = 120 minutes

newfolder  = sprintf('%s/Matlab/LTD_CE',direc);
cd(newfolder)
MAIN_LTD_CE


%%
%% A FINANCIAL REFORM
%%
%% A) Short-term debt model (STD)
% This code generates the results of the SHORT-TERM DEBT MODEL and computes moments for Tables 6 and 7.
% Approximate runtime = two minutes

newfolder  = sprintf('%s/Matlab/STD',direc);
cd(newfolder)
MAIN_STD

%% B) Short-term debt model with a financial reform (STD_freform)
% This code generates the results of the SHORT-TERM DEBT MODEL with the
% FINANCIAL REFORM in place and computes moments for Table 6.
% (This code is identical to MAIN_STD, except for parameter XI which is
% reduced by 25%.)
% Approximate runtime = two minutes

newfolder  = sprintf('%s/Matlab/STD_freform',direc);
cd(newfolder)
MAIN_STD_freform

%% C) BENCHMARK model with a financial reform (LTD_freform)
% This code generates the results of the BENCHMARK MODEL with long-term
% debt & short-term debt with the FINANCIAL REFORM in place and computes moments for Table 6.
% (This code is identical to MAIN_Benchmark, except for parameter XI which is
% reduced by 25%.)
% Approximate runtime = 120 minutes

newfolder  = sprintf('%s/Matlab/LTD_freform',direc);
cd(newfolder)
MAIN_LTD_freform



%%
    
% End of code