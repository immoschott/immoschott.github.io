% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% Master file for all Tables shown in the paper

clear all
clc

% Direct Matlab to the "Replication files" directory:
direc       = '...\Replication files';
mainfolder      = sprintf('%s/Tables/Tables_code',direc);
cd(mainfolder)
datafolder      = sprintf('%s/Tables/Tables_data',direc);

%% Table 2: Calibration results

Table_2

%% Table 3: Unconditional distributions

Table_3

%% Table 4: Correlation of firm variables with size and age

Table_4

%% Table 5: The cost of debt dilution and debt overhang

Table_5

%% Table 6: A financial reform

Table_6

%% Table 7: Short-term debt model - Calibration results

Table_7


