% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates Table 7.
cd(datafolder)

%% Short-term debt model results 

load Tab7_STD

% Round the results to one digit after the decimal
Tab7_STD.meanlev        = round(Tab7_STD.meanlev*10)/10;
Tab7_STD.meanspread     = round(Tab7_STD.meanspread*10)/10;
% Round the results to two digits after the decimal
Tab7_STD.mass           = round(full(Tab7_STD.mass)*100)/100;

%% Empirical moments

% Load cross-sectional results
data1                   = readtable('Tab_XS.csv');

% Round the results to one digit after the decimal
data1.LEVq_mean         = round(100*data1.LEVq_mean*10)/10;
data1.spread_mean       = round(data1.spread_mean*10)/10;
data1.mass              = NaN;

% Show the results:
fprintf('\nTable 7:\n')
fprintf('\t\tTarget\t\t\t\t\tData\t\tModel\n')
fprintf('-----------------------------------------------------------------------------------------------------\n')
fprintf('\t\tAverage firm leverage\t\t\t%1.1f%%\t\t%1.1f%%\n',data1.LEVq_mean,Tab7_STD.meanlev);
fprintf('\t\tAverage credit spread\t\t\t%1.1f%%\t\t%1.1f%%\n',data1.spread_mean,Tab7_STD.meanspread);
fprintf('\t\tUnit mass of firms\t\t\t%1.2f\t\t%1.2f\n',data1.mass,Tab7_STD.mass);

clear Tab* data1
cd(mainfolder)
