% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates Table 6.
cd(datafolder)

%% Short-term debt model results (pre-reform)

load Tab6_STD

%% Short-term debt model results (post-reform)

load Tab6_STDfr

%% Model with long-term debt & short-term debt (pre-reform)

load Tab6_LTD

%% Model with long-term debt & short-term debt (post-reform)

load Tab6_LTDfr

%% Normalize aggregate variables

% Normalize and round to two digits
Tab6_LTDfr.AvgK         = round((Tab6_LTDfr.AvgK / Tab6_LTD.AvgK - 1) * 100 * 100) / 100;
Tab6_LTDfr.AggK         = round((Tab6_LTDfr.AggK / Tab6_LTD.AggK - 1) * 100 * 100) / 100;
Tab6_LTDfr.GDP          = round((Tab6_LTDfr.GDP / Tab6_LTD.GDP - 1) * 100 * 100) / 100;
Tab6_LTDfr.Cons         = round((Tab6_LTDfr.Cons / Tab6_LTD.Cons - 1) * 100 * 100) / 100;

Tab6_LTD.AvgK           = round((Tab6_LTD.AvgK / Tab6_LTD.AvgK) * 100) / 100;
Tab6_LTD.AggK           = round((Tab6_LTD.AggK / Tab6_LTD.AggK) * 100) / 100;
Tab6_LTD.GDP            = round((Tab6_LTD.GDP / Tab6_LTD.GDP) * 100) / 100;
Tab6_LTD.Cons           = round((Tab6_LTD.Cons / Tab6_LTD.Cons) * 100) / 100;

% Normalize and round to one digit
Tab6_STDfr.AvgK         = round((Tab6_STDfr.AvgK / Tab6_STD.AvgK - 1) * 100 * 100) / 100;
Tab6_STDfr.AggK         = round((Tab6_STDfr.AggK / Tab6_STD.AggK - 1) * 100 * 100) / 100;
Tab6_STDfr.GDP          = round((Tab6_STDfr.GDP / Tab6_STD.GDP - 1) * 100 * 100) / 100;
Tab6_STDfr.Cons         = round(round(100*(Tab6_STDfr.Cons / Tab6_STD.Cons - 1),3),2);

Tab6_STD.AvgK           = round((Tab6_STD.AvgK / Tab6_STD.AvgK) * 100) / 100;
Tab6_STD.AggK           = round((Tab6_STD.AggK / Tab6_STD.AggK) * 100) / 100;
Tab6_STD.GDP            = round((Tab6_STD.GDP / Tab6_STD.GDP) * 100) / 100;
Tab6_STD.Cons           = round((Tab6_STD.Cons / Tab6_STD.Cons) * 100) / 100;


%% Round remaining variables to one digit

Tab6_STD.meanlev        = round(Tab6_STD.meanlev*10)/10;
Tab6_STD.defrate        = round(Tab6_STD.defrate*10)/10;
Tab6_STD.meanspread     = round(Tab6_STD.meanspread*10)/10;
Tab6_STD.LTDshare       = round(Tab6_STD.LTDshare*10)/10;

Tab6_STDfr.meanlev      = round(Tab6_STDfr.meanlev*10)/10;
Tab6_STDfr.defrate      = round(round(Tab6_STDfr.defrate,2),1);
Tab6_STDfr.meanspread   = round(Tab6_STDfr.meanspread*10)/10;
Tab6_STDfr.LTDshare     = round(Tab6_STDfr.LTDshare*10)/10;

Tab6_LTD.meanlev        = round(Tab6_LTD.meanlev*10)/10;
Tab6_LTD.defrate        = round(Tab6_LTD.defrate*10)/10;
Tab6_LTD.meanspread     = round(Tab6_LTD.meanspread*10)/10;
Tab6_LTD.LTDshare       = round(Tab6_LTD.LTDshare*10)/10;

Tab6_LTDfr.meanlev      = round(Tab6_LTDfr.meanlev*10)/10;
Tab6_LTDfr.defrate      = round(Tab6_LTDfr.defrate*10)/10;
Tab6_LTDfr.meanspread   = round(Tab6_LTDfr.meanspread*10)/10;
Tab6_LTDfr.LTDshare     = round(Tab6_LTDfr.LTDshare*10)/10;

%% Show results:

fprintf('\nTable 6:\n')
fprintf('\n      \t\t\t\t\t\tSTD Model\t\t\tLTD Model\n')
fprintf('-----------------------------------------------------------------------------------------------------\n')
fprintf('Moment\t\t\t\t\tPre-reform\tPost-reform\tPre-reform\tPost-reform\n')
fprintf('-----------------------------------------------------------------------------------------------------\n')
fprintf('Average firm leverage\t\t\t%1.1f\t\t%1.1f\t\t%1.1f\t\t%1.1f\n',Tab6_STD.meanlev,Tab6_STDfr.meanlev,Tab6_LTD.meanlev,Tab6_LTDfr.meanlev);
fprintf('Default rate (quarterly)\t\t%1.1f\t\t%1.1f\t\t%1.1f\t\t%1.1f\n',Tab6_STD.defrate,Tab6_STDfr.defrate,Tab6_LTD.defrate,Tab6_LTDfr.defrate);
fprintf('Average credit spread\t\t\t%1.1f\t\t%1.1f\t\t%1.1f\t\t%1.1f\n',Tab6_STD.meanspread,Tab6_STDfr.meanspread,Tab6_LTD.meanspread,Tab6_LTDfr.meanspread);
fprintf('Average share of LTD\t\t\t%1.1f\t\t%1.1f\t\t%1.1f\t\t%1.1f\n',Tab6_STD.LTDshare,Tab6_STDfr.LTDshare,Tab6_LTD.LTDshare,Tab6_LTDfr.LTDshare);
fprintf('-----------------------------------------------------------------------------------------------------\n')
fprintf('Average capital\t\t\t\t%1.2f\t\t%1.2f\t\t%1.2f\t\t%1.2f\n',Tab6_STD.AvgK,Tab6_STDfr.AvgK,Tab6_LTD.AvgK,Tab6_LTDfr.AvgK);
fprintf('Aggregate capital\t\t\t%1.2f\t\t%1.2f\t\t%1.2f\t\t%1.2f\n',Tab6_STD.AggK,Tab6_STDfr.AggK,Tab6_LTD.AggK,Tab6_LTDfr.AggK);
fprintf('GDP\t\t\t\t\t%1.2f\t\t%1.2f\t\t%1.2f\t\t%1.2f\n',Tab6_STD.GDP,Tab6_STDfr.GDP,Tab6_LTD.GDP,Tab6_LTDfr.GDP);
fprintf('Consumption\t\t\t\t%1.2f\t\t%1.2f\t\t%1.2f\t\t%1.2f\n',Tab6_STD.Cons,Tab6_STDfr.Cons,Tab6_LTD.Cons,Tab6_LTDfr.Cons);

clear Tab*
cd(mainfolder)
