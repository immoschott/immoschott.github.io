% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates Table 4.
cd(datafolder)

%% Load correlations produced in Stata
% See Stata do file "CS_data_corrs.do" 

size_data       = readtable('corrs_size_data.csv');
size_model      = readtable('corrs_size_model.csv');

age_data        = readtable('corrs_age_data.csv');
age_model       = readtable('corrs_age_model.csv');

% Round the results to two digits after the decimal
for jj  = 1:size(size_data,1)
    size_data.b{jj}     = round(100*str2double(size_data.b{jj}))/100;
    size_model.b{jj}    = round(100*str2double(size_model.b{jj}))/100;
    age_data.b{jj}      = round(100*str2double(age_data.b{jj}))/100;
    age_model.b{jj}     = round(100*str2double(age_model.b{jj}))/100;
end

%% Show results:

fprintf('\nTable 4:\n')
fprintf('\t\t\t\t\t\tSize\t\t\t\tAge\n')
fprintf('\t\t\t\t\tData\t\tModel\t\tData\t\tModel\n')
fprintf('-----------------------------------------------------------------------------------------------------\n')
fprintf('\tLeverage\t\t\t%1.2f\t\t%1.2f\t\t%1.2f\t\t%1.2f\n',size_data.b{1},size_model.b{1},age_data.b{1},age_model.b{1});
fprintf('\tLong-term debt share\t\t%1.2f\t\t%1.2f\t\t%1.2f\t\t%1.2f\n',size_data.b{2},size_model.b{2},age_data.b{2},age_model.b{2});
fprintf('\tCredit spread on long-term debt\t%1.2f\t\t%1.2f\t\t%1.2f\t\t%1.2f\n',size_data.b{3},size_model.b{3},age_data.b{3},age_model.b{3});
fprintf('\tAge\t\t\t\t%1.2f\t\t%1.2f\t\t%1.2f\t\t%1.2f\n',size_data.b{4},size_model.b{4},NaN,NaN);
fprintf('\tSize\t\t\t\t%1.2f\t\t%1.2f\t\t%1.2f\t\t%1.2f\n',NaN,NaN,age_data.b{4},age_model.b{4});

clear size_* age_* jj
cd(mainfolder)
