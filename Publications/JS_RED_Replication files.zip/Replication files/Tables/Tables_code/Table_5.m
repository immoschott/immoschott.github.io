% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates Table 5.
cd(datafolder)

%% Results benchmark model with long-term debt & short-term debt

load Tab5_LTD

%% Counterfactual: the cost of debt dilution and debt overhang, model with long-term debt & short-term debt

load Tab5_LTDce

%% Normalize aggregate variables

% Normalize and round to one digit
Tab5_LTDce.AvgK         = round((Tab5_LTDce.AvgK / Tab5_LTD.AvgK - 1) * 100 * 10) / 10;
Tab5_LTDce.AggK         = round((Tab5_LTDce.AggK / Tab5_LTD.AggK - 1) * 100 * 10) / 10;
Tab5_LTDce.GDP          = round((Tab5_LTDce.GDP / Tab5_LTD.GDP - 1) * 100 * 10) / 10;
Tab5_LTDce.Cons         = round((Tab5_LTDce.Cons / Tab5_LTD.Cons - 1) * 100 * 10) / 10;

Tab5_LTD.AvgK           = round((Tab5_LTD.AvgK / Tab5_LTD.AvgK) * 100) / 100;
Tab5_LTD.AggK           = round((Tab5_LTD.AggK / Tab5_LTD.AggK) * 100) / 100;
Tab5_LTD.GDP            = round((Tab5_LTD.GDP / Tab5_LTD.GDP) * 100) / 100;
Tab5_LTD.Cons           = round((Tab5_LTD.Cons / Tab5_LTD.Cons) * 100) / 100;

%% Round remaining variables to one digit
Tab5_LTD.meanlev        = round(Tab5_LTD.meanlev*10)/10;
Tab5_LTD.defrate        = round(Tab5_LTD.defrate*10)/10;
Tab5_LTD.meanspread     = round(Tab5_LTD.meanspread*10)/10;
Tab5_LTD.LTDshare       = round(Tab5_LTD.LTDshare*10)/10;

Tab5_LTDce.meanlev      = round(Tab5_LTDce.meanlev*10)/10;
Tab5_LTDce.defrate      = round(Tab5_LTDce.defrate*10)/10;
Tab5_LTDce.meanspread   = round(Tab5_LTDce.meanspread*10)/10;
Tab5_LTDce.LTDshare     = round(Tab5_LTDce.LTDshare*10)/10;

%% Show results:

fprintf('\nTable 5:\n')
fprintf('\tMoment\t\t\t\t\tBenchmark\t\tCounterfactual\n')
fprintf('-----------------------------------------------------------------------------------------------------\n')
fprintf('\tAverage firm leverage\t\t\t%1.1f%%\t\t\t%1.1f%%\n',Tab5_LTD.meanlev,Tab5_LTDce.meanlev);
fprintf('\tDefault rate (quarterly)\t\t%1.1f%%\t\t\t%1.1f%%\n',Tab5_LTD.defrate,Tab5_LTDce.defrate);
fprintf('\tAverage credit spread on long-term debt\t%1.1f%%\t\t\t%1.1f%%\n',Tab5_LTD.meanspread,Tab5_LTDce.meanspread);
fprintf('\tAverage share of long-term debt\t\t%1.1f%%\t\t\t%1.1f%%\n',Tab5_LTD.LTDshare,Tab5_LTDce.LTDshare);
fprintf('-----------------------------------------------------------------------------------------------------\n')
fprintf('\tAverage capital\t\t\t\t%1.1f\t\t\t%1.1f%%\n',Tab5_LTD.AvgK,Tab5_LTDce.AvgK);
fprintf('\tAggregate capital\t\t\t%1.1f\t\t\t%1.1f%%\n',Tab5_LTD.AggK,Tab5_LTDce.AggK);
fprintf('\tGDP\t\t\t\t\t%1.1f\t\t\t%1.1f%%\n',Tab5_LTD.GDP,Tab5_LTDce.GDP);
fprintf('\tConsumption\t\t\t\t%1.1f\t\t\t%1.1f%%\n',Tab5_LTD.Cons,Tab5_LTDce.Cons);

clear Tab*
cd(mainfolder)
