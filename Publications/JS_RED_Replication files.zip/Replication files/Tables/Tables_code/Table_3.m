% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates Table 3.
cd(datafolder)

%% Results benchmark model with long-term debt & short-term debt
load Tab3

% Round the results to one digit after the decimal
Tab3.levmean    = round(Tab3.levmean*10)/10;
Tab3.levp25     = round(Tab3.levp25*10)/10;
Tab3.levp50     = round(Tab3.levp50*10)/10;
Tab3.levp75     = round(Tab3.levp75*10)/10;

Tab3.ltdmean    = round(Tab3.ltdmean*10)/10;
Tab3.ltdp25     = round(Tab3.ltdp25*10)/10;
Tab3.ltdp50     = round(Tab3.ltdp50*10)/10;
Tab3.ltdp75     = round(Tab3.ltdp75*10)/10;

Tab3.ltsmean    = round(Tab3.ltsmean*10)/10;
Tab3.ltsp25     = round(Tab3.ltsp25*10)/10;
Tab3.ltsp50     = round(Tab3.ltsp50*10)/10;
Tab3.ltsp75     = round(Tab3.ltsp75*10)/10;

%% Empirical data moments

% Load cross-sectional results
data1                   = readtable('Tab_XS.csv');

% Round the results to one digit after the decimal
data1.LEVq_mean         = round(100*data1.LEVq_mean*10)/10;
data1.LEVq_p25          = round(100*data1.LEVq_p25*10)/10;
data1.LEVq_p50          = round(100*data1.LEVq_p50*10)/10;
data1.LEVq_p75          = round(100*data1.LEVq_p75*10)/10;

data1.LTD_shareq_mean   = round(100*data1.LTD_shareq_mean*10)/10;
data1.LTD_shareq_p25    = round(100*data1.LTD_shareq_p25*10)/10;
data1.LTD_shareq_p50    = round(100*data1.LTD_shareq_p50*10)/10;
data1.LTD_shareq_p75    = round(100*data1.LTD_shareq_p75*10)/10;

data1.spread_mean       = round(data1.spread_mean*10)/10;
data1.spread_p25        = round(data1.spread_p25*10)/10;
data1.spread_p50        = round(data1.spread_p50*10)/10;
data1.spread_p75        = round(data1.spread_p75*10)/10;


%% Show results:

fprintf('\nTable 3:\n')
fprintf('\t\t\t\t\t\tMean\t     Percentile\n')
fprintf('\t\t\t\t\t\t\tp25\tp50\tp75\n')
fprintf('-----------------------------------------------------------------------------------------------------\n')
fprintf('\t\t\t\t\tMODEL\n\n')
fprintf('\t\tLeverage\t\t\t%1.1f\t%1.1f\t%1.1f\t%1.1f\n',Tab3.levmean,Tab3.levp25,Tab3.levp50,Tab3.levp75);
fprintf('\t\tLong-term debt share\t\t%1.1f\t%1.1f\t%1.1f\t%1.1f\n',Tab3.ltdmean,Tab3.ltdp25,Tab3.ltdp50,Tab3.ltdp75);
fprintf('\t\tCredit spread on long-term debt\t%1.1f\t%1.1f\t%1.1f\t%1.1f\n',Tab3.ltsmean,Tab3.ltsp25,Tab3.ltsp50,Tab3.ltsp75);

fprintf('\n\t\t\t\t\tDATA\n\n')
fprintf('\t\tLeverage\t\t\t%1.1f\t%1.1f\t%1.1f\t%1.1f\n',data1.LEVq_mean,data1.LEVq_p25,data1.LEVq_p50,data1.LEVq_p75);
fprintf('\t\tLong-term debt share\t\t%1.1f\t%1.1f\t%1.1f\t%1.1f\n',data1.LTD_shareq_mean,data1.LTD_shareq_p25,data1.LTD_shareq_p50,data1.LTD_shareq_p75);
fprintf('\t\tCredit spread on long-term debt\t%1.1f\t%1.1f\t%1.1f\t%1.1f\n',data1.spread_mean,data1.spread_p25,data1.spread_p50,data1.spread_p75);

clear Tab* data1
cd(mainfolder)
