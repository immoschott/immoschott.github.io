% Matlab Code for replication of "Optimal Debt Maturity and Firm Investment"
% by J. Jungherr and I. Schott, September 2020
% 
% This code generates Table 2.
cd(datafolder)

%% Results benchmark model with long-term debt & short-term debt
load Tab2

% Round the results to one digit after the decimal
Tab2.meanlev    = round(Tab2.meanlev*10)/10;
Tab2.meanspread = round(Tab2.meanspread*10)/10;
Tab2.LTDshare   = round(Tab2.LTDshare*10)/10;
Tab2.medinv     = round(Tab2.medinv*10)/10;
Tab2.sdinv      = round(Tab2.sdinv*10)/10;
Tab2.xrate      = round(Tab2.xrate*10)/10;
% Round the results to two digits after the decimal
Tab2.mass       = round(full(Tab2.mass)*100)/100;

%% Empirical data moments

% Load cross-sectional results
data1                   = readtable('Tab_XS.csv');
data2                   = readtable('Tab_WI.csv');

% Round the results to one digit after the decimal
data1.LEVq_mean         = round(100*data1.LEVq_mean*10)/10;
data1.spread_mean       = round(data1.spread_mean*10)/10;
data1.LTD_shareq_mean   = round(100*data1.LTD_shareq_mean*10)/10;
data2.inv_mean          = round(100*data2.inv_mean*10)/10;
data2.inv_sd            = round(100*data2.inv_sd*10)/10;
data.exit               = 2.2; % From Ottonello & Winberry
data.mass               = NaN; 


%% Show results:

fprintf('\nTable 2:\n')
fprintf('\t\tTarget\t\t\t\t\tData\t\tModel\n')
fprintf('-----------------------------------------------------------------------------------------------------\n')
fprintf('\t\tAverage firm leverage\t\t\t%1.1f%%\t\t%1.1f%%\n',data1.LEVq_mean,Tab2.meanlev);
fprintf('\t\tAverage credit spread on long-term debt\t%1.1f%%\t\t%1.1f%%\n',data1.spread_mean,Tab2.meanspread);
fprintf('\t\tAverage share of long-term debt\t\t%1.1f%%\t\t%1.1f%%\n',data1.LTD_shareq_mean,Tab2.LTDshare);
fprintf('\t\tMedian of average net investment rate\t%1.1f%%\t\t%1.1f%%\n',data2.inv_mean,Tab2.medinv);
fprintf('\t\tMedian of s.d. of net investment rates\t%1.1f%%\t\t%1.1f%%\n',data2.inv_sd,Tab2.sdinv);
fprintf('\t\tTotal exit rate (quarterly)\t\t%1.1f%%\t\t%1.1f%%\n',data.exit,Tab2.xrate);
fprintf('\t\tUnit mass of firms\t\t\t%1.2f\t\t%1.2f\n',data.mass,Tab2.mass);

clear Tab* data1 data2 data
cd(mainfolder)
