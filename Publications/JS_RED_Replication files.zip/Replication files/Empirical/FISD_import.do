* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
* Import FISD data

* Structure of the FISD data
* Codebook is CorpBondSource.pdf
* bond_issues has issue_id, issuer_id, and agent_id, and parent_id
* bond_ratings has issue_id and issuer_id

cd "$datapath/FISD"

use bond_issues, clear

* remove issues in foreign currencies
keep if country_domicile == "USA"
drop if foreign_currency == "Y"
drop if canadian == "Y"
drop if yankee == "Y"


* Remove SIC Codes as in Compustat data
* Exlude financial firms
drop if substr(sic, 1, 1) == "6"
* Exclude public administration
drop if substr(sic, 1, 1) == "9"
* Exlude utilities, SIC 4900s
drop if substr(sic, 1, 2) == "49"

* Senior unsecured bonds
keep if security_level == "SEN" 

* Keep only US Corporate Debentures and US Corporate MTN (Medium-term Notes)
keep if bond_type == "CDEB" || bond_type == "CMTN"

* Create time variable for panel
* Offering date: 	The date the issue was originally offered.
* Maturity: 		Date that the issue's principal is due for repayment.
order issue_id issuer_id offering_date maturity

* Some offering dates are on the weekend and so cannot be assigned Treasury spreads. 
gen dow = dow(offering_date)
* 0 = Sunday. Change to next Monday.
* 6 = Saturday. Change to next Monday.
replace offering_date = offering_date + 1 if dow == 0
replace offering_date = offering_date + 2 if dow == 6

* Extract quarter and year of the offering date
gen fmth 	= month(offering_date)
gen fqtr 	= quarter(offering_date)
gen fyear 	= year(offering_date)
gen time 	= yq(fyear, fqtr) 
format time %tq
drop fmth fqtr fyear
order issue_id issuer_id time

* Spread information
* Offering yield: 	Yield to maturity at the time of issuance, based on the coupon 
* 					and any discount or premium to par value at the time of sale. 
*					Offering_yield is calculated only for fixed rate issues.
drop if offering_yield == .

compress
* Save temporary dataset 
save bond_1.dta, replace

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Now merge with bond ratings data
use bond_ratings, clear

* Give all variables except issue_id an "R" suffix (for rating)
ren * *_R
ren issue_id issue_id

compress
* Save temporary dataset 
save bond_2.dta, replace

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Merge bonds with ratings
use bond_1.dta, clear
merge 1:m issue_id using bond_2
keep if _ == 3
drop _

* Keep only those ratings that took place in the same quarter as the bond issuance (or within 30 days)
gen fqtr 		= quarter(rating_date)
gen fyear 		= year(rating_date)
gen time_rating = yq(fyear, fqtr) 
format time_rating %tq
drop fqtr fyear
order issue_id time*
gen same = time == time_rating

gen late_rate = rating_date - offering_date
replace same = 1 if same == 0 & late_rate >=-45 & late_rate<=45
drop if same == 0

* The FRED data on T-bills is available for the following maturities:
* M stands for months, the others are years
* GS1M (4 week) GS3M (13 week) GS6M (26 weeks) GS1 (52 weeks) GS2 (2 years) GS3 (3 years) GS5 GS7 GS10 GS20 GS30
* (until exactly the same day on year later)
label define ml 0 "<1GSM" 1 "GS1M" 2 "GS3M" 3 "GS6M" 4 "GS1" 5 "GS2" 6 "GS3" 7 "GS5" 8 "GS7" 9 "GS10" ///
 10 "GS20" 11 "GS30" 12 ">GS30" 

* For every issuance, compute the maturity in days.
* Then assign this maturity into one of the bins defined by the T-bills.
* This is done by finding the closest upper and lower bounds of T-bill maturities.
* Then, the relative distance from the bounds is used as the weight.

* Categories
gen maturity_lb = .
lab var maturity_lb "Maturity: Lower bound"
lab values maturity_lb ml
gen maturity_lb_date = .
lab var maturity_lb_date "Maturity: Lower bound. Date"
format maturity_lb_date %d

gen day = day(offering_date)
gen month = month(offering_date)
gen year = year(offering_date)
* Note that issuances made on Feb 29 are manually changed to 
* March 1st for the maturity computations.
gen tmp = month == 2 & day == 29
replace month = 3 if tmp == 1
replace day = 1 if tmp == 1
drop tmp
* Cutoffs for maturities of 1, 3, 6 months. 
local mats 1 3 6
foreach x of local mats{ 
	qui gen mat_datm`x' = mdy(month, day, year) + `x'*30
	format mat_datm`x' %d
}
* Cutoffs for maturities of 1, 2, 3, 5, 7, 10, 20, 30 years
local mats 1 2 3 5 7 10 20 30
foreach x of local mats{ 
	qui gen mat_dat`x' = mdy(month, day, year + `x')
	format mat_dat`x' %d
}
* Add another 40 days to the 30 year cutoff for measurement error
replace mat_dat30 = mat_dat30 + 40
drop day month year

* Less than one month
replace maturity_lb = 0 if maturity_lb == . & maturity <= mat_datm1
replace maturity_lb_date = 0 if maturity_lb == 1
* Less than three months
replace maturity_lb = 1 if maturity_lb == . & maturity <= mat_datm3
replace maturity_lb_date = mat_datm1 + 1 if maturity_lb == 1
* Less than six months
replace maturity_lb = 2 if maturity_lb == . & maturity <= mat_datm6
replace maturity_lb_date = mat_datm3 + 1 if maturity_lb == 2
* Less than one year
replace maturity_lb = 3 if maturity_lb == . & maturity <= mat_dat1
replace maturity_lb_date = mat_datm6 + 1 if maturity_lb == 3
* Less than two years
replace maturity_lb = 4 if maturity_lb == . & maturity <= mat_dat2
replace maturity_lb_date = mat_dat1 + 1 if maturity_lb == 4
* Less than 3 years
replace maturity_lb = 5 if maturity_lb == . & maturity <= mat_dat3
replace maturity_lb_date = mat_dat2 + 1 if maturity_lb == 5
* Less than 5 years
replace maturity_lb = 6 if maturity_lb == . & maturity <= mat_dat5
replace maturity_lb_date = mat_dat3 + 1 if maturity_lb == 6
* Less than 7 years
replace maturity_lb = 7 if maturity_lb == . & maturity <= mat_dat7
replace maturity_lb_date = mat_dat5 + 1 if maturity_lb == 7
* Less than 10 years
replace maturity_lb = 8 if maturity_lb == . & maturity <= mat_dat10
replace maturity_lb_date = mat_dat7 + 1 if maturity_lb == 8
* Less than 20 years
replace maturity_lb = 9 if maturity_lb == . & maturity <= mat_dat20
replace maturity_lb_date = mat_dat10 + 1 if maturity_lb == 9
* Less than 30 years
replace maturity_lb = 10 if maturity_lb == . & maturity <= mat_dat30
replace maturity_lb_date = mat_dat20 + 1 if maturity_lb == 10
* More than 30 years
replace maturity_lb = 11 if maturity_lb == . & maturity < .
replace maturity_lb_date = mat_dat30 + 1 if maturity_lb == 11

* Upper bound for maturity categories
gen maturity_ub = maturity_lb + 1
lab values maturity_ub ml

* Upper bound dates
gen maturity_ub_date = .
format maturity_ub_date %d
replace maturity_ub_date = mat_datm1 			if maturity_lb == 0
replace maturity_ub_date = mat_datm3 			if maturity_lb == 1
replace maturity_ub_date = mat_datm6  			if maturity_lb == 2
replace maturity_ub_date = mat_dat1 			if maturity_lb == 3
replace maturity_ub_date = mat_dat2 			if maturity_lb == 4
replace maturity_ub_date = mat_dat3 			if maturity_lb == 5
replace maturity_ub_date = mat_dat5 			if maturity_lb == 6
replace maturity_ub_date = mat_dat7 			if maturity_lb == 7
replace maturity_ub_date = mat_dat10 			if maturity_lb == 8
replace maturity_ub_date = mat_dat20 			if maturity_lb == 9
replace maturity_ub_date = mat_dat30 			if maturity_lb == 10
replace maturity_ub_date = . 					if maturity_lb == 11

* Now every issue has a maturity category lb and ub, along with associated dates
* br issue_id  time offering_date maturity maturity_lb maturity_lb_date maturity_ub maturity_ub_date

compress
* Save temporary dataset 
save bond_3.dta, replace
erase bond_1.dta
erase bond_2.dta

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 


use bond_3.dta, clear

keep issue_id time time_rating offering_date maturity  ///
	 offering_yield rating_date_R rating_type_R rating_R ///
	investment_grade_R maturity_?b maturity_*_date mat_dat* 

* Merge bond issues to the list of same-day Treasury yields

* Merge in the complete time series of Treasury yields
merge m:1 offering_date using "$datapath/treasury_yields_wide.dta"
* Delete treasury yields that are not associated with any issue:
drop if _merge == 2
* Treasury data starts in 1962
drop if time<tq(1962,1)

save tmp.dta, replace
keep if _ == 1
drop yield? yield??
replace offering_date = offering_date + 1
merge m:1 offering_date using "$datapath/treasury_yields_wide.dta",  gen(_merge2)
drop if _merge2 == 2
label data "Previously unmatched, now matched. 1"
save tmp2.dta, replace
keep if _merge2 == 1
* There are only 9 unmatched observations left.
* The all have an original offering date 31mar2018. The closest Treasury auction was 02apr2018
replace offering_date = offering_date + 2
drop yield? yield??
merge m:1 offering_date using "$datapath/treasury_yields_wide.dta",  gen(_merge3)
drop if _merge3 == 2
label data "Previously unmatched, now matched. 2"
save tmp3.dta, replace

* Now merge all the datasets back together.
use tmp.dta, clear
* There are 47  unmatched that we now delete
drop if _merge == 1
* Bring in the first round of matches
append using tmp2.dta 
drop if _merge2 == 1
append using tmp3.dta 
drop if _merge == 1 & _merge2 == 1 & _merge3 == 1
* Now every firm has a Treasury yield
drop _merge*
sort issue_id time

compress
save bond_4.dta, replace
erase tmp.dta
erase tmp2.dta
erase tmp3.dta

* For each bond issue, find the closest-fitting Treasury bill categories
* Upper and lower bounds, weighted by actual maturity.

use bond_4.dta, clear

gen madeachange = 0
gen yield_T_lb = .
gen yield_T_ub = .
* First assign the obvious cases
forval g = 1/11 {
	replace yield_T_lb = yield`g' if maturity_lb == `g'
	replace yield_T_ub = yield`g' if maturity_ub == `g'
}
* Assign the one-month spread to maturities less than one month
replace yield_T_lb = yield1 if maturity_lb == 0
replace yield_T_ub = yield1 if maturity_ub == 0
replace maturity_lb_date = mat_datm1 if maturity_lb == 0
replace maturity_ub_date = mat_datm1 if maturity_ub == 0

* Assign the 30-year spread to maturities with longer durations
replace yield_T_ub = yield11 if maturity_ub == 12
replace maturity_lb_date = mat_dat30 if maturity_ub == 12
replace maturity_ub_date = mat_dat30 if maturity_ub == 12
replace madeachange = 1 if maturity_ub == 12
* Some fixes: If upper bound 20 is missing, use 30
gen fixthis = 1 if maturity_ub == 10 & yield_T_ub == . & yield11 < .
replace madeachange = 1 if fixthis == 1
replace yield_T_ub = yield11 if fixthis == 1 
replace maturity_ub_date = mat_dat30 if fixthis == 1 
drop fixthis
* If lower bound 20 is missing, use 10
gen fixthis = 1 if maturity_lb == 10 & yield_T_lb == . & yield9 < .
replace madeachange = 1 if fixthis == 1
replace yield_T_lb = yield9 if fixthis == 1
replace maturity_lb_date = mat_dat10 if fixthis == 1 
drop fixthis
* If upper bound 30 is missing, use 20
gen fixthis = 1 if maturity_ub == 11 & yield_T_ub == . & yield10 < .
replace madeachange = 1 if fixthis == 1
replace yield_T_ub = yield10 if fixthis == 1
drop fixthis
* If maturity is over 30 years, but closest T-bill is 20 years, use 20
gen fixthis = 1 if maturity_lb == 11 & yield_T_lb == . & yield10 < .
replace madeachange = 1 if fixthis == 1
replace yield_T_lb = yield10 if fixthis == 1
replace maturity_lb_date = mat_dat30 if fixthis == 1
drop fixthis
gen fixthis = 1 if maturity_ub == 12 & yield_T_ub == . & yield10 < .
replace madeachange = 1 if fixthis == 1
replace yield_T_ub = yield10 if fixthis == 1
replace maturity_ub_date = mat_dat30 if fixthis == 1
drop fixthis
* For all the remaining cases, the closest T-bill is 10 years, use that
gen fixthis = 1 if maturity_lb == 11 & yield_T_lb == . & yield9 < .
replace madeachange = 1 if fixthis == 1
replace yield_T_lb = yield9 if fixthis == 1
replace maturity_lb_date = mat_dat10 if fixthis == 1
drop fixthis
gen fixthis = 1 if maturity_ub == 10 & yield_T_ub == . & yield9 < .
replace madeachange = 1 if fixthis == 1
replace yield_T_ub = yield9 if fixthis == 1
replace maturity_ub_date = mat_dat10 if fixthis == 1
drop fixthis
gen fixthis = 1 if maturity_ub == 11 & yield_T_ub == . & yield9 < .
replace madeachange = 1 if fixthis == 1
replace yield_T_ub = yield9 if fixthis == 1
replace maturity_ub_date = mat_dat10 if fixthis == 1
drop fixthis
gen fixthis = 1 if maturity_ub == 12 & yield_T_ub == . & yield9 < .
replace madeachange = 1 if fixthis == 1
replace yield_T_ub = yield9 if fixthis == 1
replace maturity_ub_date = mat_dat10 if fixthis == 1
drop fixthis
* Now assign the correct weights to the upper and lower bounds
* Create weight of lower bound
gen w = (maturity - maturity_ub_date) / (maturity_lb_date - maturity_ub_date)
lab var w "Weight of lower maturity bound"
* Adjust weights for those bonds with >30 years maturity
table madeachange, c(mean w p50 w max w)
replace w = 1 if w > 1 & w < .
* For every issuance, compute linear interpolation weights between the 
* upper and lower duration bounds
gen yield_Tbill = w * yield_T_lb + (1-w)* yield_T_ub
drop w yield?? yield? mat_dat* yield*_?b
lab var yield_Tbill "Closest T-bill spread"
* Create spreads of bond yield over treasury yield
gen spread = offering_yield - yield_Tbill
lab var spread "Bond yield - T-bill"
* Cleaning steps
drop if spread < 0.005
drop if spread > 35
* Define a maturity variable in days
gen mat_days = maturity - offering_date
lab var mat_days "Maturity (days)"
drop if mat_days < 364  
compress
save bonds_spreads.dta, replace
erase bond_3.dta

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 


use bonds_spreads.dta, clear

* We have four types of ratings, convert them all to S&P scale
* see https://en.wikipedia.org/wiki/Bond_credit_rating
* --> Johnson (2003) Table 1
gen rating = .
lab var rating "Rating, numeric"
label define ratl 22 "AAA" 21 "AA+" 20 "AA" 19 "AA-" 18 "A+" 17 "A" 16 "A-" ///
	15 "BBB+" 14 "BBB" 13 "BBB-" 12 "BB+" 11 "BB" 10 "BB-" 9 "B+" 8 "B" 7 "B-" ///
	6 "CCC+" 5 "CCC" 4 "CCC-" 3 "CC" 2 "C" 1 "D" 0 "NR"      
label values rating ratl

local ratings1 FR SPR DPR
foreach r of local ratings1 {
	replace rating = 22 if rating_R == "AAA" & rating_type_R == "`r'"
	replace rating = 21 if rating_R == "AA+" & rating_type_R == "`r'"
	replace rating = 20 if rating_R == "AA" & rating_type_R == "`r'"
	replace rating = 19 if rating_R == "AA-" & rating_type_R == "`r'"
	replace rating = 18 if rating_R == "A+" & rating_type_R == "`r'"
	replace rating = 17 if rating_R == "A" & rating_type_R == "`r'"
	replace rating = 16 if rating_R == "A-" & rating_type_R == "`r'"
	replace rating = 15 if rating_R == "BBB+" & rating_type_R == "`r'"
	replace rating = 14 if rating_R == "BBB" & rating_type_R == "`r'"
	replace rating = 13 if rating_R == "BBB-" & rating_type_R == "`r'"
	replace rating = 12 if rating_R == "BB+" & rating_type_R == "`r'"
	replace rating = 11 if rating_R == "BB" & rating_type_R == "`r'"
	replace rating = 10 if rating_R == "BB-" & rating_type_R == "`r'"
	replace rating = 9  if rating_R == "B+" & rating_type_R == "`r'"
	replace rating = 8  if rating_R == "B" & rating_type_R == "`r'"
	replace rating = 7  if rating_R == "B-" & rating_type_R == "`r'"
	replace rating = 6  if rating_R == "CCC+" & rating_type_R == "`r'"
	replace rating = 5 if rating_R == "CCC" & rating_type_R == "`r'"
	replace rating = 4 if rating_R == "CCC-" & rating_type_R == "`r'"
	replace rating = 3 if rating_R == "CC" & rating_type_R == "`r'"
	replace rating = 2 if rating_R == "C" & rating_type_R == "`r'"
	replace rating = 1 if rating_R == "D" & rating_type_R == "`r'"
	replace rating = 0 if rating_R == "NR" & rating_type_R == "`r'"
}
* Moodys
replace rating = 22 if rating_R == "Aaa" & rating_type_R == "MR"
replace rating = 21 if rating_R == "Aa1" & rating_type_R == "MR"
replace rating = 20 if rating_R == "Aa2" & rating_type_R == "MR"
replace rating = 19 if rating_R == "Aa3" & rating_type_R == "MR"
replace rating = 18 if rating_R == "A1" & rating_type_R == "MR"
replace rating = 17 if rating_R == "A2" & rating_type_R == "MR"
replace rating = 16 if rating_R == "A3" & rating_type_R == "MR"
replace rating = 15 if rating_R == "Baa1" & rating_type_R == "MR"
replace rating = 14 if rating_R == "Baa2" & rating_type_R == "MR"
replace rating = 13 if rating_R == "Baa3" & rating_type_R == "MR"
replace rating = 12 if rating_R == "Ba1" & rating_type_R == "MR"
replace rating = 11 if rating_R == "Ba2" & rating_type_R == "MR"
replace rating = 10 if rating_R == "Ba3" & rating_type_R == "MR"
replace rating = 9  if rating_R == "B1" & rating_type_R == "MR"
replace rating = 8  if rating_R == "B2" & rating_type_R == "MR"
replace rating = 7  if rating_R == "B3" & rating_type_R == "MR"
replace rating = 6  if rating_R == "Caa1" & rating_type_R == "MR"
replace rating = 5  if rating_R == "Caa2" & rating_type_R == "MR"
replace rating = 4  if rating_R == "Caa3" & rating_type_R == "MR"
replace rating = 3  if rating_R == "Ca" & rating_type_R == "MR"
replace rating = 2  if rating_R == "C" & rating_type_R == "MR"
replace rating = 0  if rating_R == "NR" & rating_type_R == "MR"

* A few Moody's ratings are unmatched. They are Caa, A, and B.
* For those cases we assume it is the first option in that category
replace rating = 18 if rating_R == "A" & rating_type_R == "MR" 
replace rating = 9  if rating_R == "B" & rating_type_R == "MR"
replace rating = 6  if rating_R == "Caa" & rating_type_R == "MR"

* Drop non-rated spreads
drop if rating == 0

* Before collapsing: Combine certain ratings to get more observations
* enough observations
qui do "$path/Empirical/coarser_ratings.do"
drop rating 
ren rating_coarse rating 

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Collapse by time and rating: Obtain percentiles of spread
collapse (mean) spread_mean = spread maturity_mean = mat_days ///
	(p50) spread_p50 = spread maturity_p50 = mat_days ///
	(count) N = spread, by(time rating)
xtset rating time 

label values rating ratcl

* Save and prepare for the merge with Compustat
compress

save "FISD_spreads.dta", replace
erase bond_4.dta

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 


