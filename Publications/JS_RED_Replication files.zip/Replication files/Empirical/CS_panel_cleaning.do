* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* Cleaning and sample selection

use "$datapath/Compustat/CS_tmp", clear
sort id time

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Sample selection
drop if fyear > 2018
drop if fyear < 1984

drop if atq == .
drop if atq < 0
drop if saleq == .
drop if saleq < 0

* Drop GE (General Electric), Ford, Chrysler and GM (General Motors)
drop if gvkey == "005047"
drop if gvkey == "004839"
drop if gvkey == "003022"
drop if gvkey == "005073"

* Drop firms with more than 50% sales growth over one quarter due to a merger.
* This information is in a footnote to SALEQ
drop if saleq_fn1 == "AB"

* Drop observations that violate the accounting identity 
* by more than 10 per cent of the book value of assets.
* "Assets = Liabilities + Equity"
gen atq2 = ltq + seqq
* Compare total assets to the new variables
gen tmp = atq/atq2
gen problem = tmp < .9 | tmp > 1.1
drop if problem == 1
drop tmp atq2 problem 

* Firms must have at least five quarters of information
bys id: gen N = _N
drop if N < 5
drop N

* Set LEVq > 20 to missing
replace LEVq = . if LEVq > 20

* Set extreme growth rates to missing
replace debt_iss = . if debt_iss > 1 | debt_iss < -1
replace eq_iss = . if eq_iss > 1 | eq_iss < -1
replace eq_issue_share = . if eq_issue_share > 1 | eq_issue_share < -1
replace xfin_share = . if xfin_share > 1 | xfin_share < -1
replace inv  = . if inv  > 1 | inv < - 1

* Drop firms with gaps in the sample
gen run = .
by id: replace run = cond(L.run == ., 1, L.run + 1)
gen startspell = run == 1
by id: egen spells = sum(startspel)
drop if spells > 1
drop run startspell spells

* Merge in the updated ratings information
merge 1:1 gvkey time using "$datapath/Compustat/Spreads.dta", gen(_rmerge)
drop if _rmerge == 2
drop N maturity_mean
ren spread_p50 spread
drop spread_mean
sort id time

compress
drop _*merge
label data "Quarterly Compustat data. 1984-2018. Cleaned."
save "$datapath/Compustat/CS_panel", replace
erase "$datapath/Compustat/Spreads.dta"
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Add aggregate investment rate
local aggs "(sum)"
local aggvars ppegtq_real i_BS
foreach x of local aggvars{
	local aggs "`aggs' `x'_agg = `x'"
}
local infls "(firstnm)"
local inflvars gIPD CPI_avg CPI_eoq
foreach x of local inflvars{
	local infls "`infls' `x'_t = `x'"
}
collapse `aggs' `infls' , by(time)
tsset time

* Investment rate:
gen INV = i_BS_agg / l.ppegtq_real_agg
drop i_BS_agg ppegtq_real_agg

* Save temporary dataset
compress
save "$datapath/Compustat/tmp1.dta", replace

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

use "$datapath/Compustat/CS_panel", clear
sort time id
merge m:1 time using "$datapath/Compustat/tmp1.dta"
erase "$datapath/Compustat/tmp1.dta"
drop _

save "$datapath/Compustat/CS_panel", replace

erase "$datapath/Compustat/CS_tmp.dta"

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 



