* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* This file creates size and age bins from the empirical firm panel

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

use "$datapath/Compustat/CS_panel.dta", clear
sort id time

qui levelsof time, local(times)
* Create size quintiles
gen size = .
foreach tt of local times{
	qui egen tmp = cut(atq_lag) if time == `tt', group(5) 
	qui replace size = tmp if time == `tt'
	drop tmp
}
drop if size == .
replace size = size + 1

* Save temporary dataset
compress
save "$datapath/Compustat/tmp_sizegroups.dta", replace

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 


* Create dataset for Figure 3:
use "$datapath/Compustat/tmp_sizegroups.dta", clear

local p50s "(p50)"
local vars LEVq LTD_shareq spread age_ipo inv
foreach x of local vars {
	local p50s "`p50s' `x'_p50 = `x'"
}

* Compute confidence intervals around each median
levelsof size, local(sizes)
foreach x of local vars {
	qui gen `x'_lb = .
	qui gen `x'_ub = .
	foreach s of local sizes{	
		qui centile `x' if size == `s',  centile(50) level(95)
		qui replace `x'_lb = r(lb_1) if size == `s'
		qui replace `x'_ub = r(ub_1) if size == `s'
	}
}

* Collapse
collapse (firstnm) *_lb *_ub `p50s', by(size)

* Save
compress
save "$figpath/databins_size3.dta", replace


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 


* Create dataset for Figure 5:
use "$datapath/Compustat/tmp_sizegroups.dta", clear

local sums "(sum)"
local vars atq_real dlcq dlttq dvq prstkcq sstkq sppeq
foreach x of local vars {
	local sums "`sums' `x'_sum = `x'"	
}
local firstnms "(firstnm)"
local vars CPI_eoq CPI_avg
foreach x of local vars {
	local firstnms "`firstnms' `x'"	
}

* Collapse
collapse `sums' `firstnms', by(size time)
xtset size time 
sort size time

* Construct aggregate variables:
gen tmp 			= dlttq + dlcq
gen tmp_d 			= tmp / CPI_eoq * 100
gen debt_issue 		= d.tmp_d
gen debt_issue_agg 	= debt_issue / l.atq_real
gen eq_issue 		= - ( dvq + prstkcq - sstkq ) / CPI_avg * 100
gen eq_issue_agg 	= eq_issue / l.atq_real
gen LT_share_issue 	= d.dlttq / d.tmp
gen eq_issue_share 	= eq_issue / abs(debt_issue + eq_issue)
gen xfin_share 		= abs(debt_issue + eq_issue) / l.atq_real

* List of variables to keep
local vars LT_share_issue eq_issue_share xfin_share

* Compute confidence intervals around each median
levelsof size, local(sizes)
foreach x of local vars {
	qui gen `x'_lb = .
	qui gen `x'_ub = .
	foreach s of local sizes{	
		qui centile `x' if size == `s',  centile(50) level(95)
		qui replace `x'_lb = r(lb_1) if size == `s'
		qui replace `x'_ub = r(ub_1) if size == `s'
	}
}

local p50s "(p50)"
foreach x of local vars {
	local p50s "`p50s' `x'_p50 = `x'"
}

collapse (firstnm) *_lb *_ub `p50s', by(size)

* Save
compress
save "$figpath/databins_size5.dta", replace

* Erase temporary data
erase "$datapath/Compustat/tmp_sizegroups.dta"



* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 




use "$datapath/Compustat/CS_panel.dta", clear
sort id time
drop if age_ipo == .
drop if age_ipo <= 0
drop if age_ipo > 60

qui levelsof time, local(times)
gen agegroup = .
foreach tt of local times{
	qui egen tmp  = cut(age_ipo) if time == `tt', group(5) 	
	qui replace agegroup = tmp if time == `tt'
	drop tmp
}
replace agegroup = agegroup + 1

* Save temporary dataset
compress
save "$datapath/Compustat/tmp_agegroups.dta", replace


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 


* Create dataset for Figure 4:
use "$datapath/Compustat/tmp_agegroups.dta", clear

local p50s "(p50)"
local vars LEVq LTD_shareq spread latq inv
foreach x of local vars {
	local p50s "`p50s' `x'_p50 = `x'"
}

* Compute confidence intervals around each median
levelsof agegroup, local(agegroups)
foreach x of local vars {
	qui gen `x'_lb = .
	qui gen `x'_ub = .
	foreach s of local agegroups{	
		qui centile `x' if agegroup == `s',  centile(50) level(95)
		qui replace `x'_lb = r(lb_1) if agegroup == `s'
		qui replace `x'_ub = r(ub_1) if agegroup == `s'
	}
}


* Collapse 
collapse (firstnm) *_lb *_ub `p50s', by(agegroup)

* Save
compress
save "$figpath/databins_age4.dta", replace



* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 



* Create dataset for Figure 6:
use "$datapath/Compustat/tmp_agegroups.dta", clear

local sums "(sum)"
local vars atq_real dlcq dlttq dvq prstkcq sstkq sppeq
foreach x of local vars {
	local sums "`sums' `x'_sum = `x'"	
}
local firstnms "(firstnm)"
local vars CPI_eoq CPI_avg
foreach x of local vars {
	local firstnms "`firstnms' `x'"	
}

* Collapse
collapse `sums' (firstnm) CPI*, by(agegroup time)
xtset agegroup time 
sort agegroup time

* Construct aggregate variables:
gen tmp 			= dlttq + dlcq
gen tmp_d 			= tmp / CPI_eoq * 100
gen debt_issue 		= d.tmp_d
gen debt_issue_agg 	= debt_issue / l.atq_real
gen eq_issue 		= - ( dvq + prstkcq - sstkq ) / CPI_avg * 100
gen eq_issue_agg 	= eq_issue / l.atq_real
gen LT_share_issue 	= d.dlttq / d.tmp
gen eq_issue_share 	= eq_issue / abs(debt_issue + eq_issue)
gen xfin_share 		= abs(debt_issue + eq_issue) / l.atq_real

* List of variables to keep
local vars LT_share_issue eq_issue_share xfin_share

* Compute confidence intervals around each median
levelsof agegroup, local(sizes)
foreach x of local vars {
	qui gen `x'_lb = .
	qui gen `x'_ub = .
	foreach s of local sizes{	
		qui centile `x' if agegroup == `s',  centile(50) level(95)
		qui replace `x'_lb = r(lb_1) if agegroup == `s'
		qui replace `x'_ub = r(ub_1) if agegroup == `s'
	}
}

local p50s "(p50)"
foreach x of local vars {
	local p50s "`p50s' `x'_p50 = `x'"
}

collapse (firstnm) *_lb *_ub `p50s', by(agegroup)

* Save
compress
save "$figpath/databins_age6.dta", replace

* Erase temporary data
erase "$datapath/Compustat/tmp_agegroups.dta"



* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 




