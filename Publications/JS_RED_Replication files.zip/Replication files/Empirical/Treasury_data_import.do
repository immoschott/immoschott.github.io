* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020

* Source: https://www. federalreserve.gov/datadownload/
* Preformatted package: Treasury Constant Maturities [csv, All Observations, 3.3 MB ]

import delimited "$datapath/FRB_H15_daily.csv", rowrange(7) clear 
gen time=date(v1,"YMD")
format time %d
drop v1
lab var v2 "1-month Treasury constant maturity"
lab var v3 "3-month Treasury constant maturity"
lab var v4 "6-month Treasury constant maturity"
lab var v5 "1-year Treasury constant maturity"
lab var v6 "2-year Treasury constant maturity"
lab var v7 "3-year Treasury constant maturity"
lab var v8 "5-year Treasury constant maturity"
lab var v9 "7-year Treasury constant maturity"
lab var v10 "10-year Treasury constant maturity"
lab var v11 "20-year Treasury constant maturity"
lab var v12 "30-year Treasury constant maturity"
ren v* yield*
* Make categories correspond to those used in FISD data
ren yield2 yield1
ren yield3 yield2
ren yield4 yield3
ren yield5 yield4
ren yield6 yield5
ren yield7 yield6
ren yield8 yield7
ren yield9 yield8
ren yield10 yield9
ren yield11 yield10
ren yield12 yield11

* Create panel
reshape long yield, i(time) j(maturity_group)
label define ml 0 "<1GSM" 1 "GS1M" 2 "GS3M" 3 "GS6M" 4 "GS1" 5 "GS2" 6 "GS3" 7 "GS5" 8 "GS7" 9 "GS10"  10 "GS20" 11 "GS30" 12 ">GS30" 
destring yield, replace force
label values maturity_group ml
xtset maturity_group time 
ren time offering_date
gen maturity_lb = maturity_group
gen maturity_ub = maturity_group
drop maturity_group
label values maturity_lb ml
label values maturity_ub ml

* Drop observations without a yield
drop if yield == .

sort offering_date  maturity_lb 

* Reshape to wide format
drop *ub
ren *lb maturity
reshape wide yield, i(of) j(maturity)
tsset of

lab var yield1 "1-month Treasury constant maturity"
lab var yield2 "3-month Treasury constant maturity"
lab var yield3 "6-month Treasury constant maturity"
lab var yield4 "1-year Treasury constant maturity"
lab var yield5 "2-year Treasury constant maturity"
lab var yield6 "3-year Treasury constant maturity"
lab var yield7 "5-year Treasury constant maturity"
lab var yield8 "7-year Treasury constant maturity"
lab var yield9 "10-year Treasury constant maturity"
lab var yield10 "20-year Treasury constant maturity"
lab var yield11 "30-year Treasury constant maturity"

compress	
save "$datapath/treasury_yields_wide.dta", replace

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
