* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* This file computes the correlations between age, size, and other key variables
* reported in Table 4 of the paper


* By size:
use "$datapath/Compustat/CS_panel", clear
sort id time
gen llatq = l.latq

* List of summary statistics which are collected:
local p50s "(p50)"
local vars LEVq LTD_shareq spread age_ipo llatq
 foreach x of local vars {
	local p50s "`p50s' `x'_p50 = `x'"
}

* Create bins 
qui levelsof time, local(times)
gen size = .
foreach tt of local times{
	qui egen tmp = cut(atq_lag) if time == `tt', group(50) 
	qui replace size = tmp if time == `tt'
	drop tmp
}
drop if size == .
replace size = size + 1

* Collapse by size bin
collapse `p50s', by(size)

estpost corr llatq_p50 LEVq_p50 LTD_shareq_p50 spread_p50 age_ipo_p50
eststo correlation
esttab correlation using "$tabpath/corrs_size_data.csv", replace nolines nogaps compress plain nomtitles noobs cell("b")



************************************************************************
************************************************************************
************************************************************************
************************************************************************
************************************************************************
************************************************************************


* By age:
use "$datapath/Compustat/CS_panel", clear
sort id time

drop if age_ipo == .
drop if age_ipo <= 0
drop if age_ipo > 60

* List of summary statistics which are collected:
local p50s "(p50)"
local vars LEVq LTD_shareq spread age_ipo latq 
foreach x of local vars {
	local p50s "`p50s' `x'_p50 = `x'"
}

* Every period, sort every firm into one of n age bins
qui levelsof time, local(times)
gen agegroup = .
local n = 50
foreach tt of local times{
	qui egen tmp  = cut(age_ipo) if time == `tt', group(`n') 	
	qui replace agegroup = tmp if time == `tt'
	drop tmp
}
replace agegroup = agegroup + 1

* Collapse by age bin
collapse `p50s', by(agegroup)

corr age_ipo_p50 LEVq_p50
corr age_ipo_p50 LTD
corr age_ipo_p50 spread
corr age_ipo_p50 latq


estpost corr age_ipo_p50 LEVq_p50 LTD_shareq_p50 spread_p50 latq_p50
eststo correlation
esttab correlation using "$tabpath/corrs_age_data.csv", replace nolines nogaps compress plain nomtitles noobs cell("b")


************************************************************************
************************************************************************
************************************************************************
************************************************************************
************************************************************************
************************************************************************



