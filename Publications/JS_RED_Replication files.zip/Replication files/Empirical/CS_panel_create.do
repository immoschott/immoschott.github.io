* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

use "$datapath/Compustat/Compustat_DDDO", clear
sort gvkey fyear fqtr

* Delete non-US firms
drop if fic ~= "USA"

* Quarterly data: Replace missing sectoral information
replace sic = sic[_n-1] if fqtr ~= . & sic == "" & gvkey == gvkey[_n-1]

* See e.g. here for a list of 2-digit SICS:
* https://mckimmoncenter.ncsu.edu/2digitsiccodes/
* Exlude financial firms, SIC 6000s
drop if substr(sic, 1, 1) == "6"
* Exclude public administration
drop if substr(sic, 1, 1) == "9"
* Exlude utilities, SIC 4900s
drop if substr(sic, 1, 2) == "49"

encode(sic), gen(SIC)
lab var SIC "SIC code"
drop sic

sort gvkey fyear fqtr

* Create time variable for panel
gen time = yq(fyear, fqtr) 
format time %tq
* Delete observations without quarter
drop if time == .
isid gvkey time

* Create panel
egen id = group(gvkey)
xtset id time
order id time

* Merge with CPI
merge m:1 time using "$datapath/CPI", gen(_cpimerge)
keep if _cpimerge == 3
drop _cpimerge
sort id time 

* Total assets
replace at = . if at < 0
replace atq = . if atq < 0

* Sales
replace sale = . if sale < 0
replace saleq = . if saleq < 0

* Short-term debt
replace dlc = . if dlc < 0
replace dlcq = . if dlcq < 0

* Long-term debt
replace dltt = . if dltt < 0
replace dlttq = . if dlttq < 0

compress

label data "Joint quarterly-annual Compustat data. 1961-2019. US, non-financial. Nominal."
save "$datapath/Compustat/CS_tmp", replace

erase "$datapath/Compustat/Compustat_DDDO.dta"

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

