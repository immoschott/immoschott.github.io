* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* Download price deflators from FRED

* Investment price deflator
import fred A008RD3Q086SBEA, clear
tsmktim time, start(1947q1)
drop dat*
order time
ren A IPD
* Compute the inflation rate
gen tmp = log(IPD)
gen gIPD = tmp - l.tmp
lab var gIPD "Growth rate of IPD"
drop tmp
compress
lab data "Quarterly investment price deflator"
save IPD.dta, replace

* Consumer Price Index for All Urban Consumers: All Items (CPIAUCSL)	
* End of period
import fred CPIAUCSL,  aggregate(quarterly,eop) clear
tsmktim time, start(1947q1)
drop dat*
order time
ren CPI CPI_eoq
lab var CPI "CPI, end of quarter"
lab data "CPI, end of quarter"
gen tmp = log(CPI_eoq)
gen gCPI = tmp - l.tmp
lab var gCPI "Growth rate of CPI (eoq)"
drop tmp
compress
save CPI_eoq.dta, replace

import fred CPIAUCSL, aggregate(quarterly,avg) clear
tsmktim time, start(1947q1)
drop dat*
order time
ren CPI CPI_avg
lab var CPI "CPI, quarterly average"
compress
lab data "CPI, quarterly average"
save CPI_avg.dta, replace


* * * * * * * *

use CPI_avg.dta,clear 

merge 1:1 time using CPI_eoq.dta
drop _merge
merge 1:1 time using IPD.dta
keep if _ == 3
drop _merge

save "$datapath/CPI.dta", replace

erase CPI_eoq.dta
erase CPI_avg.dta
erase IPD.dta


