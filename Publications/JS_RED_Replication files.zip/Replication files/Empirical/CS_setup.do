* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* This file combines the quarterly and annual Compustat databases

* Turn the annual CS dataset into a gvkey-time panel
run CS_annual_panel.do

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Turn quarterly CS data into a panel (gvkey-(year-qtr))
run CS_quaterly_panel.do

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

* Merge annual and quarterly CS
use Compustat_quarterly, clear
ren fyear fyear
merge m:1 gvkey fyear using Compustat_annual
sort gvkey datadate
drop if _merge == 2
drop _merge

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

compress
label data "Joint quarterly-annual Compustat data."
save "$datapath/Compustat/Compustat_DDDO.dta", replace

erase Compustat_quarterly.dta
erase Compustat_annual.dta







