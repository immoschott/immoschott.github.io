* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* Turns the quarterly Compustat dataset into a panel (id time)
use "$datapath/Compustat/CompustatQ.dta", clear

* Delete variables we do not need
drop adrrq ajexq ajpq bsprq currtrq curuscnq ogmq pdateq aociderglq aociotherq ///
aocipenq aocisecglq aol2q aqdq aqepsq aqpl1q arcedq arceepsq arceq aul3q billexceq ///
capr1q capr2q capr3q capsftq ceiexbillq cibegniq cicurrq ciderglq cimiiq ciotherq ///
cipenq ciq cisecglq citotalq cshfdq derhedglq derlcq derlltq diladq derhedglq dilavq ///
dpacreq dtedq dteepsq dteaq dtepq epsf12 epsfi12 epsfiq epsfxq epspi12 epspiq epspxq ///
epsx12 esopctq esopnrq esoprq esoptq esubq fcaq finacoq-finxoprq gdwlamq-gdwlipq ///
glcea12-hedgeglq ibadj12-ibmiiq lnoq-lqpl1q ltmibq lul3q mibnq-msaq nrtxtdq ///
nrtxtepsq nrtxtq obkq oepf12 oeps12 oepsxq oiadpq-optlifeq pllq-pncwipq pnrshoq ///
prcaq-prcpq rcaq-rcpq rectaq rectoq recubq rllq-rstcheq seta12-spiopq tfvaq-tfvlq ///
tieq-tstkq txdbcaq-txdiq uddq-udpcoq udvpq updvpq-upstkq usubdvpq usubpcvq wddq ///
wdepsq xopt12-xoptqp xsgaq-afudciy aqdy aqepsy arcedy arceepsy cibegniy-ciy
drop indfmt consol popsrc datafmt tic cusip acctchgq compstq curcdq ///
	curncdq finalq rp srcq staltq updq apdedateq fdateq rdq acchgq acomincq ///
	acoq actq altoq ancq anoq aoq apq aqaq aqpq capsq csh12q cshfd12 cshiq ///
	cshopq cshprq cstkcvq cstkeq dcomq deracq deraltq doq dpretq drcq drltq ///
	dvintfq dvpq ffoq gdwlq glaq icaptq intaccq intanoq invfgq invoq invrmq invtq ///
	invwipq ivaeqq ivaoq ivltq ivstq lseq ncoq niitq nimq niq nopiq npatq npq ///
	optrfrq optvolq prcraq prshoq pstknq pstkrq rdipaq rdipdq rdipepsq rdipq ///
	recdq rectq rectrq retq reunaq seqoq spiq sretq stkcoq stkcpaq txdbaq txditcq ///
	txpq txtq txwq uacoq uaoq uaptq ucapsq ucconsq uceqq ugiq ulcoq uniamiq ///
	unopincq uopiq urectq uspiq utemq wdaq wdpq xaccq xidoq xintq xiq xoprq xrdq ///
	amcy aolochy apalchy aqay aqpy arcey cdvcy cogsy dlcchy doy dprety esubcy ///
	esuby exrey fcay ffoy fiaoy fincfy finrevy finxinty finxopry fopoxy fopoy ///
	fopty fsrcoy fsrcty fuseoy fusety gdwlamy glay glceay glcedy glceepsy glcepy ///
	gldy glepsy glivy glpy hedgegly ibadjy ibcomy ibcy ibmiiy intpny invchy itccy ///
	ivacoy ivchy ivncfy ivstchy miiy ncoy niity nimy niy nopiy oancfy oepsxy ///
	oiadpy oibdpy opepsy optdry optfvgry optlifey optrfry optvoly pdvcy piy plly ///
	rdipay rdipdy rdipepsy rdipy recchy setay setdy setepsy setpy spiy srety ///
	stkcoy stkcpay tdcy tfvcey tiey tiiy tsafcy txachy txbcofy txbcoy txdcy txdiy ///
	txpdy txty txwy uaolochy udfccy udvpy ufretsdy ugiy uniamiy unopincy unwccy ///
	uoisy updvpy uptacy uspiy ustdncy usubdvpy utfdocy utfoscy utmey uwkcapcy ///
	wcapchy wcapcy wday wddy wdepsy wdpy xidocy xidoy xinty xiy exchg ///
	dvpspq dvpsxq prchq prclq adjex 
drop cshfdy-dilavy dteay-dtepy epsfiy-epspxy gdwliay-gdwlipy nrtxtdy-nrtxty pncdy-prcpy ///
	rcay-rcpy rray-rrpy spcedpy-spcey spidy-spiopy xoptdqpy-xopty 
drop add1 add2 add3 add4 addzip busdesc city conml county ein fax ggroup gind gsector ///
	gsubind idbflag incorp phone prican prirow priusa spcindcd spcseccd state weburl
* Drop all of the footnotes except the one for SALEQ
ren saleq_fn1 tmp
drop *_fn*
ren tmp saleq_fn1

drop if gvkey == ""
drop if fyear == .
drop if fqtr == .

order gvkey fyear fqtr

* Some companies file twice. They have resulting different Accounting Standards,
* Income Statement Model Numbers, etc.
sort gvkey fyear fqtr
egen tmp_id = group(gvkey fyear fqtr)
bys tmp_id: gen counter = _n
bys tmp_id: gen counterx = _N

* 1) Some of this happens because of Canadian firms
drop if counterx > 1 & fic == "CAN"

* 2) If "duplicate", the delete if cash flow model is not 7 (the most common)
drop if counterx > 1 & scfq ~= 7
drop counter counterx
bys tmp_id: gen counter = _n
bys tmp_id: gen counterx = _N

* 3) If "duplicate", the delete non DS (domestic standard) accounting standard
drop if counterx > 1 & acctstd ~= "DS"
drop counter counterx
bys tmp_id: gen counter = _n
bys tmp_id: gen counterx = _N

* 4) Remaining duplicates have different data dates. Some filings oocur
* prior to the quarter in question. Keep later filing for those cases
drop if counterx > 1 & counter == 1
drop counter counterx

drop tmp_id
order gvkey fyear fqtr conm
sort gvkey fyear fqtr
isid gvkey fyear fqtr

compress
label data "Quarterly Compustat. No cleaning. All nominal"
save Compustat_quarterly, replace
