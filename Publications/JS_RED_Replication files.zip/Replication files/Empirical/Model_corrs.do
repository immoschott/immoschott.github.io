* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* This file computes correlations between age, size, and other key variables
* using the model-generated simulated firm panel


* By size:
import delimited using "$tabpath/Matlab_panel_corrs.csv", clear

ren v1 id
ren v2 time
ren v3 capital_prime
ren v4 std_prime
ren v5 ltd_prime
ren v6 spread

xtset id time

* Take a random sub-sample to speed up calculations
keep if time > 1000 & time <= 2000

by id: gen age = _n
by id: gen N = _N

* Same treatmet as in the data
drop if N < 5

gen capital = capital_prime
lab var capital "Capital, end of time t"
drop capital_prime
gen lk = log(l.capital)
lab var lk "Log capital, beginning of time t"
gen td_prime 		= std_prime + ltd_prime
gen debt_tot = l.td_prime
lab var debt_tot "Total debt outstanding, beginning of t"
drop td
gen lev =  debt_tot / l.capital
lab var lev "Leverage at the beginning of period t"
gen ltd_share = ltd / (std + ltd)
gen LTD_share = l.ltd_share
lab var LTD_share "LTD share at time t"
drop ltd_share

* List of summary statistics which are collected:
local p50s "(p50)"
local vars lev LTD_share spread age lk 
foreach x of local vars {
	local p50s "`p50s' `x'_p50 = `x'"
}
* Drop first period because lagged capital is missing
egen tmp = min(time)
drop if time == tmp 
drop tmp 
* Create size bins 
qui levelsof time, local(times)
gen size = .
foreach tt of local times{
	qui egen tmp = cut(lk) if time == `tt', group(50) 
	qui replace size = tmp if time == `tt'
	drop tmp
}
drop if size == .
replace size = size + 1

* Collapse by size group
collapse `p50s', by(size)


estpost corr lk_p50 lev LTD spread age
eststo correlation
esttab correlation using "$tabpath/corrs_size_model.csv", replace nolines nogaps compress plain nomtitles noobs cell("b")



************************************************************************
************************************************************************
************************************************************************
************************************************************************
************************************************************************
************************************************************************


* By age:
import delimited using "$tabpath/Matlab_panel_corrs.csv", clear

ren v1 id
ren v2 time
ren v3 capital_prime
ren v4 std_prime
ren v5 ltd_prime
ren v6 spread

xtset id time

* Take a random sub-sample to speed up calculations
keep if time > 1000 & time <= 2000

by id: gen age = _n
by id: gen N = _N

* Same treatmet as in the data
drop if N < 5
drop if age > 60

gen capital = capital_prime
lab var capital "Capital, end of time t"
drop capital_prime
gen lk = log(capital)
lab var lk "Log capital, end of time t"
gen td_prime 		= std_prime + ltd_prime
gen debt_tot = l.td_prime
lab var debt_tot "Total debt outstanding, beginning of t"
drop td
gen lev =  debt_tot / l.capital
lab var lev "Leverage at the beginning of period t"
gen ltd_share = ltd / (std + ltd)
gen LTD_share = l.ltd_share
lab var LTD_share "LTD share at time t"
drop ltd_share

* List of summary statistics which are collected:
local p50s "(p50)"
local vars lev LTD_share spread lk age
foreach x of local vars {
	local p50s "`p50s' `x'_p50 = `x'"
}


* Every period, sort every firm into one of n age bins
qui levelsof time, local(times)
gen agegroup = .
local n = 50
foreach tt of local times{
	qui egen tmp  = cut(age) if time == `tt', group(`n') 	
	qui replace agegroup = tmp if time == `tt'
	drop tmp
}
replace agegroup = agegroup + 1

* Collapse by age group
collapse `p50s', by(agegroup)

estpost corr age_p50 lev LTD spread lk 
eststo correlation
esttab correlation using "$tabpath/corrs_age_model.csv", replace nolines nogaps compress plain nomtitles noobs cell("b")


************************************************************************
************************************************************************
************************************************************************
************************************************************************
************************************************************************
************************************************************************






