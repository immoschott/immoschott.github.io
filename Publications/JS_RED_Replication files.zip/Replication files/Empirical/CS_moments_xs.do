* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* This file computes the distributions of key variables in the cross-section

use "$datapath/Compustat/CS_panel", clear

sort time id

* List of variables to collect descriptive statistics for:
local vars LEVq LTD_shareq spread 
local means "(mean)"
local p25s "(p25)"
local p50s "(p50)"
local p75s "(p75)"
foreach x of local vars {
	local means "`means' `x'_mean = `x'"
	local p25s "`p25s' `x'_p25 = `x'"
	local p50s "`p50s' `x'_p50 = `x'"
	local p75s "`p75s' `x'_p75 = `x'"	
}
collapse `means' `p25s' `p50s' `p75s', by(time)
tsset time
sort time

* Export this data into CSV format
collapse (p50) LEVq* LTD* spread*
export delimited using "$tabpath/Tab_XS.csv", replace

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

