* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
* Combine several ratings that do not have many observations

gen rating_coarse = rating 
lab var rating_coarse "Coarser rating"
* Combine everything at or below CCC+
replace rating_coarse = 6 if rating <= 6
* Combine everything at or better than AA-
replace rating_coarse = 19 if rating >= 19
* Combine BB and BB+
replace rating_coarse = 11 if rating == 12

label define ratcl 19 "AA- or better" 18 "A+" 17 "A" 16 "A-" ///
	15 "BBB+" 14 "BBB" 13 "BBB-" 11 "BB and BB+" 10 "BB-" 9 "B+" 8 "B" 7 "B-" ///
	6 "CCC+ or worse" 
label values rating_coarse ratcl