* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* This is the Master file that generates the empirical data used throughout the paper.
* Table and Figure output is automatically saved in TABLES_DATA and FIGURES_DATA
*
*
clear

* * * * * *
* INSTRUCTIONS: 	1. Change the working directory "path" below to direct to the folder "REPLICATION FILES"
*					2. The FISD and Compustat data are proprietary and are NOT included in the replication files.
*					3. To run this do file, please place the necessary Compustat data files inside the directory REPLICATION FILES/EMPIRICAL/DATA/COMPUSTAT
*					4. To run this do file, please place the necessary FISD data files inside the directory REPLICATION FILES/EMPIRICAL/DATA/FISD								
* 					   See README.txt for details
* * * * * *

global path "...\Replication files"

* The following path names do not have to be changed:
global datapath "$path/Empirical/Data"
global figpath 	"$path/Figures/Figures_data"
global tabpath 	"$path/Tables/Tables_data"


* * * * * * * 
* 1) Computes yields of US treasuries of various maturities
cd "$path/Empirical"
qui do Treasury_data_import.do


* * * * * * * 
* 2) Import FISD data and compute FISD spreads
cd "$path/Empirical"
qui do FISD_import.do


* * * * * * * 
* 3) Compustat Monthly Updates --> Extract ratings and merge with FISD ratings & spreads
cd "$path/Empirical"
qui do CS_ratings_update.do


* * * * * * * * 
* * Obtain CPI from FRED
* cd "$path/Empirical"
* qui do CPI.do


* * * * * * * 
* 4) Merge quarterly and annual Compustat databases
cd "$path/Empirical"
qui do CS_setup.do


* * * * * * * 
* 5) Empirical data: Keep US firms, exclude finance & utilites, ...
cd "$path/Empirical"
qui do CS_panel_create.do


* * * * * * * 
* 6) Empirical data: Create new variables, e.g. leverage, long-term debt share
cd "$path/Empirical"
qui do CS_panel_variables.do


* * * * * * * 
* 7) Empirical data: Clean the firm panel
cd "$path/Empirical"
qui do CS_panel_cleaning.do


* * * * * * * 
* 8) Empirical data: Compute distributions of key variables in the cross-section (Tables 2,3,7)
cd "$path/Empirical"
qui do CS_moments_xs.do


* * * * * * * 
* 9) Empirical data: Compute distributions of net investment rates within firms (Table 2)
cd "$path/Empirical"
qui do CS_moments_wi.do


* * * * * * * 
* 10) Empirical data: Correlation of firm variables with size and age (Table 4)
cd "$path/Empirical"
qui do CS_data_corrs.do


* * * * * * * 
* 11) Empirical data: Collapse data by size and age bins (for Figures 3,4,5,6)
cd "$path/Empirical"
qui do CS_data_bins.do


* * * * * * * 
* 12) Model-generated data: Correlation of firm variables with size and age (Table 4)
cd "$path/Empirical"
qui do Model_corrs.do
