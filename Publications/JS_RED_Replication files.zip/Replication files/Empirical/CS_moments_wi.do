* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* This file computes the distributions of within-firm net investment rates

use "$datapath/Compustat/CS_panel", clear
sort time id

* Subtract aggregate investment rates from individual ones
replace inv = inv - INV

* For each FIRM, compute key moments 
local vars inv
local means "(mean)"
local sds "(sd)"
foreach x of local vars {
	local means "`means' `x'_mean = `x'"
	local sds "`sds' `x'_sd = `x'"
}

* Collapse by firm
collapse `means' `sds' , by(id)

* Export this data into CSV format
collapse (p50) inv_mean inv_sd
export delimited using "$tabpath/Tab_WI.csv", replace

