* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* This file is called from setup_CS.do
* Turn the annual CS dataset into a gvkey-time panel

* Turns the dataset into a true panel (id year)
use "$datapath/Compustat/CompustatY.dta", clear

order gvkey fyear conm

compress

sort gvkey fyear
isid gvkey fyear

* Delete unnecessary variables
drop mrcta msa msvrv mtl nat nco nfsr niadj nieci niint niintpfc niintpfp niit nim ///
	nio nipfc nipfp nit nits nopi nopio np npanl npaore nparl npat nrtxt nrtxtd ///
	nrtxteps oancf ob oiadp oibdp opeps opili opincar opini opioi opiri opiti oprepsx ///
	optca optdr optrfr optvol palr panlr patr pcl pclr pcnlr pctr pdvc pi pidom pifo ///
	pll pltbl ppcbl ppenb ppenc ppenli ppenls ppenme ppennr ppeno ppevbb ppeveb ///
	ppevo ppevr pppabl ppphbl pppobl ppptbl prc prca prcad prcaeps prebl pri prodv ///
	prsho prstkcc prstkpc prvt pstk pstkc pstkl pstkn pstkr pstkrv ptbl ptran pvcl ///
	pvo pvon pvpl pvt pwoi radp ragr rari rati rca rcd rceps rcl rcp rdip rdipa rdipd ///
	rdipeps rdp rea reajo recch recco recd recta rectr recub reuna reunr ris rll rlo ///
	rlp rlri rlt rmum rpag rveqt rvlrv salepfc salepfp sbdc sc sco secu seqo siv spce ///
	spced spceeps spi spid spieps spioa spiop sppiv spstkc sret srt ssnp stbo stio ///
	stkco stkcpa tdc tf tfva tfvce tfvl tie tii tlcf transa tsa txach txbco txbcof ///
	txc txdb txdba txdbca txdbcl txdc txdfed txdfo txdi txditc txds txeqa txeqii ///
	txfed txfo txndb txndba txndbl txndbr txo txp txpd txr txs txt txva txw uaoloch ///
	uaox uapt ucaps uccons uceq ucustad udcopres udd udfcc udmb udolt udpco udpfa ///
	udvp ufretsd ugi ui uinvt ulcm ulco uniami unl unnp unnpl unopinc unwcc uois ///
	uopi uopres updvp upmcstk upmpf upmpfs upmsubp upstk upstkc upstksf urect ///
	urectr urevub uspi ustdnc usubdvp usubpstk utfdoc utfosc utme utxfed uwkcapc ///
	uxinst uxintd vpac vpo wcapc wcapch wda wdd wdeps wdp xacc xad xago xagt xcom ///
	xcomi xdepl xdp xdvre xeqo xi xido xidoc xindb xindc xins xinst xint xintd ///
	xintopt xivi xivre xlr xnbi xnf xnins xnitb xobd xoi xopr xoprar xoptd xopteps ///
	xore xpp xpr xrd xrent xs xsga xstf xstfo xstfws xt xuw xuwli xuwnli xuwoi ///
	xuwrei xuwti naicsh sich cshtr_c adjex_c cshtr_f dvpsp_f dvpsx_f mkvalt adjex_f rank 

drop au auop auopic ceoso cfoso add1 add2 add3 add4 addzip city county ein ///
	fax ggroup gind gsector gsubind idbflag incorp loc phone prican prirow priusa ///
	spcindcd spcseccd state stko weburl

drop acctchg acctstd acqmeth adrr ajex ajp bspr ///
	compst curncd currtr curuscn final ismod ltcm ogm pddur scf src stalt udpl ///
	upd apdedate fdate pdate acchg acco acdo aco acodo acominc acox acoxar acqao ///
	acqcshi acqgdwl acqic acqintan acqinvt acqlntal acqniintc acqppe acqsc adpac ///
	aedi afudcc afudci aldo am amc amdc amgw ano ao aodo aol2 aoloch aox ap apalch ///
	apb apc apofs aqa aqd aqeps aqi aqp aqpl1 arb arc arce arced arceeps artfs ///
	aul3 autxr balr banlr bast bastr batr bcef bclr bcltbl bcnlr bcrbl bct bctbl ///
	bctr bkvlps bltbl ca capr1 capr2 capr3 caps cb cbi cdpac cdvc ceql ceqt cfbd ///
	cfere cfo cfpdo cga cgri cgti cgui chech chs ci clrll clt cmp cnltbl ///
	cpcbl cpdoi cpnli cppbl cprei crv crvnli cshfd cshpri cstkcv cstke dbi dc dclo ///
	dcom dcpstk dcs dcvsr dcvsub dcvt dd dfpac dfs diladj dilavx dn do donr dpacre ///
	dpact dpdc dpltb dpret dpsc dpstb dptb dptc dptic dpvieb dpvio dpvir drc drci ///
	drlt ds dtea dted dteeps dtep dudd dv dvdnp dvpa dvpd dvpdp dvpibb dvrpiv ///
	dvrre dvsco ea eiea emol esopct esopdlt esub esubc excadj exre fatb fatc fatd ///
	fca fdfr fea fel ffo ffs fiao fincf fopo fopox fopt fsrco fsrct fuseo fuset ///
	gbbl gdwl gdwlam gdwlia gdwlid gdwlieps gdwlip geqrv gla glp govgr govtown ///
	gwo hedgegl ibadj ibbl ibcom ibki ibmii icapt initb intano intc intpn invch ///
	invfg invo invofs invrm invwip iobd ioi iore ipc irei irent ivch ivgod ivi ///
	ivncf ivpt ivst ivstch lco lcox lcoxar lcoxdr lcuacu li lif lifr lno lo lrv ///
	ls lse lst

drop cibegni-clo cshrc-cshrw dpacb-dpaco dxd2-dxd5 epsfi-epspx esopnr-esopt fate-fatp ///
glcea-gleps gphbl-gptbl iaeq-iaui idiis-iire invreh-invres ipabl iphbl-ipv irii-ivao ///
lcabg-lcat lloml-llwocr lol2 lqpl1 loxdr lul3 mib-mrct optex-optprcwa pnca-pobl ///
rra-rvdt rvno-sal seta-setp tdscd-tdst tsafc-tstkp txtubadjust-txtubxintis
	
* Drop footnotes
drop *_fn

compress
label data "Annual Compustat. No cleaning. All nominal"
save Compustat_annual, replace

