* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* This file creates new variables in the empirical firm panel


use "$datapath/Compustat/CS_tmp", clear
sort id time

* AGE (Time since IPO date)
sort id time
gen tmp_y 	= year(ipodate)
gen tmp_q 	= quarter(ipodate)
gen tmp 	= yq(tmp_y,tmp_q)
bys id: egen ipo = max(tmp)
format ipo %tq
lab var ipo "IPO date"
drop tmp*
gen age_ipo = time - ipo
lab var age_ipo "Quarters since IPO"

* Total debt
gen debt_totq = dlttq + dlcq
lab var debt_totq "Total Debt"
gen debt_tot = dltt + dlc
lab var debt_tot "Total Debt"

* Leverage
gen LEVq = debt_totq / atq
lab var LEVq "Leverage, Book"

* Market equity:
gen meq = cshoq*prccq
lab var meq "Market equity"
gen me = csho*prcc_c
lab var me "Market equity"

* Long-term debt share
gen LTD_shareq = dlttq / debt_totq
lab var LTD_shareq "Long-term Debt Share"

* Measure lagged capital
gen atq_lag = l.atq 
lab var atq_lag "Lagged capital"

* Deflate total assets
gen atq_real = atq / CPI_eoq * 100
lab var atq_real "Real total assets"
gen latq = log(atq_real)
lab var latq "Log total assets (real)"

* Deflate sales
gen saleq_real = saleq / CPI_avg * 100
lab var saleq_real "Real sales"
gen lsaleq = log(saleq_real)
lab var lsaleq "Log sales (real)"

* Note that variables ending in y are year-to-date variables
* Convert them into quarterly frequency by subtracting the past quarter from the 
* current observation for all but the first quarter of the firm.
local vars capxy sppey dvy prstkcy sstky
foreach x of local vars{
	gen `x'_qq = `x'
	forval i = 2/4{
		replace `x'_qq = `x' - l.`x' if fqtr == `i'
	}
}
ren capxy_qq capxq  
ren sppey_qq sppeq 
ren dvy_qq dvq
ren prstkcy_qq prstkcq
ren sstky_qq sstkq
* Set missing to zero
replace capxq = 0 if capxq == .
replace sppeq = 0 if sppeq == .
* Set negative to missing
replace capxq = . if capxq < 0
replace sppeq = . if sppeq < 0
* Define investment and investment rate 
gen i_BS = capxq - sppeq
* Deflate investment 
replace i_BS = i_BS  / CPI_avg * 100
lab var i_BS "Capx - SPPE, real"
gen ppegtq_real = ppegtq  / CPI_eoq * 100
* Create investment rate
gen inv = i_BS / l.ppegtq_real
lab var inv "Investment rate"

* Net debt issuance
gen tmpl = dlttq / CPI_eoq * 100
gen tmps = dlcq / CPI_eoq * 100
gen ddebt_real = d.tmpl + d.tmps
gen debt_iss = (ddebt_real)/l.atq_real
lab var debt_iss "Net debt issuance divided by lagged assets"
drop tmpl tmps ddebt_real

* Net equity issuance 
gen tmp1 = dvq / CPI_avg * 100
gen tmp2 = prstkcq / CPI_avg * 100
gen tmp3 = sstkq / CPI_avg * 100
gen deq = -(dvq + prstkcq - sstkq)
gen deq_real = -(tmp1 + tmp2 - tmp3)
gen eq_iss = deq_real/l.atq_real
lab var eq_iss "Net equity issuanced divided by lagged assets"
drop tmp3 deq_real

* Long-term debt share of debt issuance
* This is the change in total debt:
gen iss_debt = d.debt_totq
gen iss_long = d.dlttq
gen iss_short = d.dlcq
gen ltshare_iss = iss_long / (iss_debt)
lab var ltshare_iss "Long-term debt share of debt issuance"

* Compute equity issuance as a fraction of the absolute value
* of total capital that enters the firm
gen eq_issue_share 	= deq / abs(deq + iss_debt)
lab var eq_issue_share "Eq. issuance over Equity + Debt issuance"

* Compute external funds raised over lagged assets
gen tmp 		= abs(deq + iss_debt) / CPI_avg * 100
gen xfin_share 	= tmp / l.atq_real
lab var xfin_share "External finance over lagged assets"
drop iss_long iss_short iss_debt tmp 


* Update the data set
save "$datapath/Compustat/CS_tmp", replace

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

