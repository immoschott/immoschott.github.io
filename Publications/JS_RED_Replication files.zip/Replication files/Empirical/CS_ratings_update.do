* Stata Code for replication of "Optimal Debt Maturity and Firm Investment"
* by J. Jungherr and I. Schott, September 2020
*
* Historical Ratings Data

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
cd "$datapath/Compustat"
use "daily updates - ratings.dta", clear

drop conm
* Extract quarter and year
gen fqtr 	= quarter(data)
gen fyear 	= year(data)
gen time 	= yq(fyear, fqtr) 
format time %tq
drop fqtr fyear
order gvkey time
sort gvkey time

* Use numeric scale for ratings as in Johnson (2003) Table 1
gen rating = .
lab var rating "Rating, numeric"
label define ratl 22 "AAA" 21 "AA+" 20 "AA" 19 "AA-" 18 "A+" 17 "A" 16 "A-" ///
	15 "BBB+" 14 "BBB" 13 "BBB-" 12 "BB+" 11 "BB" 10 "BB-" 9 "B+" 8 "B" 7 "B-" ///
	6 "CCC+" 5 "CCC" 4 "CCC-" 3 "CC" 2 "C" 1 "D" 0 "NR"      
label values rating ratl

replace rating = 22 if splticrm == "AAA" 
replace rating = 21 if splticrm == "AA+" 
replace rating = 20 if splticrm == "AA" 
replace rating = 19 if splticrm == "AA-" 
replace rating = 18 if splticrm == "A+" 
replace rating = 17 if splticrm == "A" 
replace rating = 16 if splticrm == "A-" 
replace rating = 15 if splticrm == "BBB+" 
replace rating = 14 if splticrm == "BBB" 
replace rating = 13 if splticrm == "BBB-" 
replace rating = 12 if splticrm == "BB+" 
replace rating = 11 if splticrm == "BB" 
replace rating = 10 if splticrm == "BB-" 
replace rating = 9  if splticrm == "B+" 
replace rating = 8  if splticrm == "B" 
replace rating = 7  if splticrm == "B-" 
replace rating = 6  if splticrm == "CCC+" 
replace rating = 5 if splticrm == "CCC" 
replace rating = 4 if splticrm == "CCC-" 
replace rating = 3 if splticrm == "CC" 
replace rating = 2 if splticrm == "C" 
replace rating = 1 if splticrm == "D" 
replace rating = 1 if splticrm == "SD" 
replace rating = 0 if splticrm == "N.M." 

ren splticrm rating_name_CSmu
lab var rating_name_CSmu "Rating from CS montly updates"

* Drop empty observations
drop if rating == .

compress
save SP_Rating_tmp.dta, replace

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 

use SP_Rating_tmp.dta, clear

* Sort such that the last observation in a given quarter comes first
gsort gvkey time -datadate

by gvkey time: gen counter = _n
keep if counter == 1

drop counter datadate

ren rating rating_l 
lab var rating_l "Rating, last in quarter"
ren rating_name_CSmu rating_name_l

compress

sort gvkey time

save Ratings.dta, replace

erase SP_Rating_tmp.dta


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 


* Merge with median and average spreads from MERGENT FISD
use Ratings.dta, clear
drop *name*
drop sp*
ren rating rating 

* Combine several ratings that do not have many observations
qui do "$path/Empirical/coarser_ratings.do"
drop rating 
ren rating_coarse rating 

merge m:1 time rating using "$datapath/FISD/FISD_spreads.dta"
drop if _merge == 2
save Spreads.dta, replace
erase "$datapath/FISD/FISD_spreads.dta"

