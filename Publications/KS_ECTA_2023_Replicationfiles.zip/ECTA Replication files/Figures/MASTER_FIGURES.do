* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Master file to create the Figures in the paper

global path ".../Replication files/Data/Data_setup"
global figpath ".../Replication files/Figures/Figures_data"

cd "$path"

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* MAIN PAPER

* Create Figure 1
do Figure_1.do 

* Create Figure 2 
do Figure_2.do

* Create Figure 3
do Figure_3.do

* Create Figure 5
do Figure_5.do 

* Create Figure 6
do Figure_6.do


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* APPENDIX

* Create Figure B.1
do Figure_B1.do 

* Create Figure B.2
do Figure_B2.do 

* Create Figure B.3
do Figure_B3.do 

* Create Figure B.4
do Figure_B4.do 

* Create Figure B.5
do Figure_B5.do 

* Create Figure D.1
do Figure_D1.do 

* Create Figure D.2
do Figure_D2.do 
