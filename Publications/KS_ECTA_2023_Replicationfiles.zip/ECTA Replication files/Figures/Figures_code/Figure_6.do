* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use Figure6.dta

******
* Set up font sizes, etc. for graphs (common across all graphs)
* All axis and label fonts:
local fontsize medlarge
******

local xstyle xtitle("{&Delta} Corporate Tax Rate", size(`fontsize')) xlabel(-2(1)2.1, labsize(`fontsize')) 
local ystyle ytitle("{&Delta} Labor Share", size(`fontsize')) ylabel(, labsize(`fontsize'))

* Scatter Diagram of state level changes between 1972 and 2007
tw sc s35.lis s35.atr if year==2007 & statefip!=0 & statefip!=2 & statefip!=15, ///
		mlabel(state_abbr) mlabsize(small) || lfit s35.lis s35.atr if year==2007& statefip!=0 & statefip!=2 & statefip!=15,  ///
		`xstyle' `ystyle' ///
		scheme(s1color)  legend(off) name(Fig6, replace) 

cd "$path"
