* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use Figure2.dta

******
* Set up font sizes, etc. for graphs (common across all graphs)
* All axis and label fonts:
local fontsize large
******

local xstyle xtitle("Corporate Tax Rate", size(`fontsize')) xlabel(, labsize(`fontsize')) 
local ystyle ytitle("Labor Share", size(`fontsize')) ylabel(, labsize(`fontsize'))

* Manufacturing sector
twoway (scatter LIS cit if year==2007 & sector==0, mlabel(country_abbr) mlabsize(medlarge))  || /// 
	(lfit LIS cit if year==2007 & sector==0) ///
	, `xstyle' `ystyle' scheme(s1color) legend(off) name(Fig2a, replace) 

* Aggregate economy
twoway (scatter LIS cit if year==2007 & sector==2, mlabel(country_abbr) mlabsize(medlarge)) || ///
	(lfit LIS cit if year==2007 & sector==2) ///
	, `xstyle' `ystyle' scheme(s1color)  legend(off)  name(Fig2b, replace) 

cd "$path"


