* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use FigureD2.dta

******
* Set up font sizes, etc. for graphs (common across all graphs)
* All axis and label fonts:
local fontsize medlarge
******

local xstyle xtitle("{&Delta} Corporate Tax Rate", size(`fontsize')) xlabel(, labsize(`fontsize')) 
local ystyle ytitle("{&Delta} Capital / Employment", size(`fontsize')) ylabel(, labsize(`fontsize'))

rreg dlknhc dcit, gen(robw_dkn)
est store r1

tw sc dlknhc dcit, mlabel(country_) mlabsize(small) || lfit dlknhc dcit [aw=robw_dkn], ///
	scheme(s1color) legend(off) `xstyle' `ystyle' name(FigD2, replace)  

cd "$path"





