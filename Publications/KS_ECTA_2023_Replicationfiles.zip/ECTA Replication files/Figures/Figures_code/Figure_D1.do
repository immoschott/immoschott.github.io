* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use FigureD1.dta

sort year sizeclass

******
* Set up font sizes, etc. for graphs (common across all graphs)
* Line thickness
local lthick lwidth(thick)
* All axis and label fonts:
local fontsize large
******

local leg legend( order(1 "10,000+" 2 "5,000+" 3 "1,000+") size(`fontsize'))
local ystyle ylabel(, labsize(`fontsize')) ytitle("Employment Concentration", size(`fontsize'))
local xstyle xlabel(1975(10)2015, labsize(`fontsize')) xtitle("")

* Define line styles
local style1 lcolor(gs9) lpattern(solid) connect(l) mcolor(gs9) msize(vsmall) `lthick'
local style2 lcolor(orange_red) lpattern(solid) connect(d) msymbol(O) mlcolor(orange_red) mfcolor(white) mcolor(orange_red) `lthick'  msize(medlarge)
local style3 lcolor(black) lpattern(solid) connect(l) msize(small) mcolor(black) `lthick'

twoway 	(connect concentration year if sizeclass==1, `style1')  ///
		(connect concentration year if sizeclass==2, `style2')  ///
		(connect concentration year if sizeclass==4, `style3') ///
		, `xstyle' `ystyle' `leg' graphregion(color(white)) name(FigD1a, replace)  

************************************

local style1a lcolor(gs3) lpattern(solid) connect(l) msymbol(O) mcolor(gs3) msize(medium) `lthick'
local style1b lcolor(gs3) lpattern(solid) connect(l) msymbol(O) mfcolor(white) msize(medium) mcolor(gs3) `lthick'
local style2a lcolor(orange_red) lpattern(solid) connect(l) msize(medium) mcolor(orange_red) `lthick'
local style2b lcolor(orange_red) lpattern(solid) connect(l) msymbol(O) mcolor(orange_red) mlcolor(orange_red) mfcolor(white) mcolor(orange_red) `lthick'  msize(medium)


local leg legend( order(1 "250+ (>20 only)" 2 "250+" 3 "1000+ (>20 only)" 4 "1000+") size(`fontsize'))
local ystyle ylabel(.6(.05).85, labsize(`fontsize')) ytitle("", size(`fontsize'))
local xstyle xlabel(1955(10)2015, labsize(`fontsize')) xtitle("")

twoway 	(connect Conc_250_20p year, `style1a' ) ///
	 	(connect Conc_1000_20p year, `style1b') ///
		(connect Conc_250 year, `style2a' ) ///
	 	(connect Conc_1000 year, `style2b') ///
	 	, `xstyle' `ystyle' `leg' graphregion(color(white)) name(FigD1b, replace)  


cd "$path"
