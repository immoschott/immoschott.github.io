* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use Figure3.dta

******
* Set up font sizes, etc. for graphs (common across all graphs)
* All axis and label fonts:
local fontsize medlarge
******

local xstyle xtitle("{&Delta} Corporate Tax Rate", size(`fontsize')) xlabel(-40(10)2.5, labsize(`fontsize')) 
local ystyle ytitle("{&Delta}  Labor Share", size(`fontsize')) ylabel(, labsize(`fontsize'))

* Manufacturing sector
twoway (scatter dLIS dcit if year==2007 & sector==0, mlabel(country_abbr) mlabsize(`fontsize')) || /// 
	 (lfit dLIS dcit if year==2007 & sector==0) ///
	, `xstyle' `ystyle' scheme(s1color) legend(off) name(Fig3a, replace) 

* Aggregate economy
local xstyle xtitle("{&Delta} Corporate Tax Rate", size(`fontsize')) xlabel(-40(10)2.5, labsize(`fontsize')) 

twoway (scatter dLIS dcit if year==2007 & sector==2, mlabel(country_abbr) mlabsize(`fontsize') )|| /// 
	 (lfit dLIS dcit if year==2007 & sector==2) ///
	, `xstyle' `ystyle' scheme(s1color) legend(off) name(Fig3b, replace) 

cd "$path"



