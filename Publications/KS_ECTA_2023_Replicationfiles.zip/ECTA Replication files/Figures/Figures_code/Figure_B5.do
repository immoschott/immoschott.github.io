* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use FigureB4_B5.dta

twoway 	(line atr100 year, xlabel(1970(20)2010) lw(thick) leg(lab(1 Corporate Tax Rate (left axis, %))) )  ///
 		(line lis year, xlabel(1970(20)2010) yaxis(2) lw(thick) lpattern("-") leg(lab(2 Payroll Share (right axis)))) ///
 		if atr!=. & statefip!=0 & statefip!=2 & statefip!=15 & statefip>=32 & year>=1972 & year<=2011, ///
 		by(State, c(5) yr iscale(*1.2) note("")) scheme(s1color) ytitle("") ylab(minmax,format(%9.1fc)) ///
 		ylab(minmax, format(%9.1fc) axis(2)) name(FigB5, replace)   

cd "$path"




