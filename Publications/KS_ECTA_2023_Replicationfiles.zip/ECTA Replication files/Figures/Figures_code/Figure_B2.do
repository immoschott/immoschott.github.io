* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use FigureB2.dta

******
* Set up font sizes, etc. for graphs (common across all graphs)
* Line thickness
local lthick lwidth(thick)
* All axis and label fonts:
local fontsize large
******

local leg legend(order(1 "NIPA" 2 "KLEMS") size(`lfontsize') )
local xstyle xlabel(1960(10)2010, labsize(`fontsize')) xtitle("")
local ystyle ylabel(, labsize(`fontsize')) ytitle("Labor share (%)", size(`fontsize'))

* Define line styles
local style1a lcolor(gs3) lpattern(solid) connect(l) msymbol(O) mcolor(gs3) msize(medium) `lthick'
local style1b lcolor(gs3) lpattern(solid) connect(l) msymbol(O) mfcolor(white) msize(medium) mcolor(gs3) `lthick'
local style2a lcolor(orange_red) lpattern(solid) connect(l) msize(medium) mcolor(orange_red) `lthick'
local style2b lcolor(orange_red) lpattern(solid) connect(l) msymbol(O) mcolor(orange_red) mlcolor(orange_red) mfcolor(white) mcolor(orange_red) `lthick'  msize(medium)

			
twoway 	(connect LSS_tmp1 year,  lcolor(white) msymbol(O) mcolor(gs3) ) || ///
		(connect LSS_tmp2 year, lcolor(white) msymbol(O) mfcolor(white)  mcolor(gs3)) || ///
		(connect LS_tmp1 year, `style1a' ) || ///
		(connect LS_tmp2 year, `style1b' ) || ///
		(connect LSS_tmp1 year, `style2a' ) || ///
		(connect LSS_tmp2 year, `style2b' ) || ///
		(pcarrowi 67 2003.5 64 2000.5 (12) "COMP/VA", mcolor(gs3) lcolor(gs3) mlabcolor(gs3) mlabsize(`lfontsize')) ///
		(pcarrowi 44 1981 49 1984 (6) "COMP/(VA+P.SERV)", mcolor(orange_red) lcolor(orange_red) mlabcolor(orange_red) mlabsize(`lfontsize')) ///
		, `xstyle' `ystyle' `leg' graphregion(color(white)) name(FigB2a, replace)  

* Percentage of purchased services in value added

local styleS lcolor(black) lpattern(solid) connect(l) msymbol(i) `lthick'
local ystyle ylabel(0(10)40, labsize(`fontsize')) ytitle("Purchased service share (%)", size(`fontsize'))

twoway (connect Serv_share year, `styleS') ///
		, leg(on label (1 "P. Serv / (VA + P. Serv)") size(`fontsize')) ///
		`ystyle' `xstyle' graphregion(color(white)) name(FigB2b, replace)   

cd "$path"


