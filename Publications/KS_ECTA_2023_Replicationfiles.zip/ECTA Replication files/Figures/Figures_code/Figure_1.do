* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use Figure1.dta

******
* Set up font sizes, etc. for graphs  
* Line thickness
local lthick lwidth(thick)
* All axis and label fonts:
local fontsize large
******


* FIGURE 1, panel a)

local leg legend( order(1 "Manufacturing (NIPA)" 3 "Manufacturing (Census)" 4 "Aggregate (BLS)") size(`fontsize'))
local ystyle ylabel(20(20)80, labsize(`fontsize')) ytitle("Manufacturing", size(`fontsize'))
local ystyle2 ylabel(50(10)70, labsize(`fontsize') axis(2)) ytitle("Aggregate", size(`fontsize') axis(2))
local xstyle xlabel(1950(10)2010, labsize(`fontsize')) xtitle("")

* Define line styles
local style1 lcolor(gs9) lpattern(solid) connect(l) mcolor(gs9) msize(vsmall) `lthick'
local style2 lcolor(orange_red) lpattern(solid) connect(d) msymbol(O) mlcolor(orange_red) mfcolor(white) mcolor(orange_red) `lthick'  msize(medium)
local style3 lcolor(black) lpattern(solid) connect(l) msize(small) mcolor(black) `lthick'

twoway 	(connect LS_BEA_man_2 year, `style1' `ystyle')  || ///
		(connect LS_BEA_man_4 year, `style1') ///
		(connect LS_Census year, `style3') ///
		(connect LS_BLS_agg year, `style2' yaxis(2) `ystyle2') ///
		(pcarrowi 76 1963.5 71 1965.5 (12) "Manufacturing (NIPA)", mcolor(gs7) lcolor(gs7) mlabcolor(gs3) mlabsize(`fontsize') ) ///
		(pcarrowi 43 1976 49 1978 (6) "Manufacturing (Census)", mcolor(black) lcolor(black) mlabcolor(black) mlabsize(`fontsize')) ///
		(pcarrowi 45.5 2001.5 51 1997.5 (6) "(BLS)", mcolor(white) lcolor(white) mlabcolor(orange_red) mlabsize(`fontsize')) ///
		(pcarrowi 49 2001 52 1997.5 (6) "Aggregate", mcolor(orange_red) lcolor(orange_red) mlabcolor(orange_red) mlabsize(`fontsize')) ///
		, `xstyle' legend(off) graphregion(color(white)) name(Fig1a, replace) 

	
* FIGURE 1, panel b)	

local ystyle ylabel(0(10)60, labsize(`fontsize'))
local xstyle xlabel(1950(10)2010, labsize(`fontsize')) xtitle("")	  

twoway 	(connect ctax_stat year, `style1' `ystyle' )  || ///
		(connect ctax_avg year, `style3') ///
		(connect ctax_marg year, `style2') ///
		(line ctax_avg year, lpattern(blank) yaxis(2) yscale(axis(2) off fill) ) ///
		(pcarrowi 46 1991 41 1988 (2) "Statutory rate", mcolor(gs7) lcolor(gs7) mlabcolor(gs3) mlabsize(`fontsize')) ///
		(pcarrowi 16 1989 21 1986 (6) "Average rate", mcolor(black) lcolor(black) mlabcolor(black) mlabsize(`fontsize')) ///
		(pcarrowi 25 2008 31 2002.5 (3) "rate", mcolor(white) lcolor(white) mlabcolor(orange_red) mlabsize(`fontsize')) ///
		(pcarrowi 28 2005.5 29 2003 (3) "Marginal", mcolor(orange_red) lcolor(orange_red) mlabcolor(orange_red) mlabsize(`fontsize')) ///
		, xline(2017.25, lwidth(thin) lcolor(black)) `xstyle' legend(off) graphregion(color(white)) name(Fig1b, replace) 


cd "$path"


