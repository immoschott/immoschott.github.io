% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

% This code generates Figure 4.
% Directory of files to be loaded:
cd(datafolder)

load Figure4a.mat
load Figure4b.mat

close all

%% Generate figure

figure(1)
% set(gcf,'units','centimeters','position',[5,30,60,20])

% Baseline economy
yyaxis left
bar(Fig4a.x,100*Fig4a.y1,'FaceAlpha',.5)
ylim(100*[0 0.105])
yticks(100*[0 0.02 0.04 0.06 0.08 0.1])
ylabel('Share of VA (\%)','interpreter','latex','FontSize',18)
hold on
yyaxis right
plot(Fig4a.x,Fig4a.y2,'-','LineWidth',3.4,'Color',[0.6350 0.0780 0.1840]);
ylabel('Density of Labor Shares','interpreter','latex','FontSize',18,'Color',[0.6350 0.0780 0.1840])
yticks([0 1 2 3])
ax = gca;
legend({'Value-added','Labor Share'},'interpreter','latex','fontsize',16);
xlabel('Labor Share','interpreter','latex','FontSize',18);
ax.YColor = [0.6350 0.0780 0.1840];
hold off


%%
figure(2)
% Economy with lower taxes

yyaxis left
bar(Fig4b.x,100*Fig4b.y1,'FaceAlpha',.5)
ylim(100*[0 0.105])
yticks(100*[0 0.02 0.04 0.06 0.08 0.1])
ylabel('Share of VA (\%)','interpreter','latex','FontSize',18)
hold on
yyaxis right
plot(Fig4b.x,Fig4b.y2,'-','LineWidth',3.4,'Color',[0.6350 0.0780 0.1840]);
ylabel('Density of Labor Shares','interpreter','latex','FontSize',18,'Color',[0.6350 0.0780 0.1840])
yticks([0 1 2 3])
ax  = gca;
legend({'Value-added','Labor Share'},'interpreter','latex','fontsize',16);
xlabel('Labor Share','interpreter','latex','FontSize',18);
ax.YColor = [0.6350 0.0780 0.1840];
hold off

%%
cd(codefolder)

clear AX Fig4*
