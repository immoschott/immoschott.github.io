* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use FigureB3.dta

tw (line LIS year, lw(thick) lpattern("-") leg(lab(2 "Manufacturing Labor Share")) )  ///
  (line cit_aux year, yaxis(2) lw(thick)leg(lab(2 "Corporate Tax Rate")))  ///
   , by(cname, yr iscale(*1.2) note(""))  ///
    scheme(s1color) xlabel(1980(10)2010) xtitle("Year") ylab(minmax,format(%9.1fc)) ylab(minmax,format(%9.1fc) axis(2)) name(FigB3, replace)  

cd "$path"


