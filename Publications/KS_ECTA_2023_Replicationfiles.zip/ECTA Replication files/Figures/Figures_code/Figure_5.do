* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use Figure5.dta


******
* Set up font sizes, etc. for graphs (common across all graphs)
* All axis and label fonts:
local fontsize large
******

local xstyle xtitle("Predicted Change in Labor Share", size(`fontsize')) xlabel(-5(2.5)0, labsize(`fontsize')) 
local ystyle ytitle("Actual Change in Labor Share", size(`fontsize')) ylabel(-20(5)5, labsize(`fontsize'))

sc dLS14_BEA dls_hat_cal_sec14, ml(SIC) mlabsize(medium) mc(black) mlabv(pos) mlabcolor(black) msize(medlarge) ||  ///
	lfit dLS14_BEA dls_hat_cal_sec14 [aw=share_VA], lc(red) lwidth(thick) || ///
	function y = x, range( -5 0) lpattern(dash) lcolor(black)   scheme(s1color)  ///
	`xstyle' `ystyle'  legend(off) name(Fig5a, replace) 

* B) Compare actual decline (BEA) to calibrated values (sector-specific and common taxes together)
expand 2
bys SIC: gen id = _n
gen x = dls_hat_cal_sec14 if id == 1
replace x = dls_hat_cal_com14 if id == 2
drop id 

cap drop pos
gen pos = 4 
replace pos = 2 if SIC == 40

local xstyle xtitle("Predicted Change in Labor Share", size(`fontsize')) xlabel(-7.5(2.5)0, labsize(`fontsize')) 
local ystyle ytitle("Actual Change in Labor Share", size(`fontsize')) ylabel(-20(5)5, labsize(`fontsize'))

linkplot dLS14_BEA x, link(SIC) lcolor(red) addplot(  sc dLS14_BEA dls_hat_cal_sec14 ,  mc(black) msize(medlarge)  || /// 
	sc dLS14_BEA dls_hat_cal_com14 , mlabel(SIC) mlabsize(medium) mc(black) mfcolor(white)  mlabv(pos) mlabcolor(black) msize(medlarge) || ///  
	function y = x, range( -7.5 0) lpattern(dash) lcolor(black) scheme(s1color) ///
	`xstyle' `ystyle' ) ///
	legend(order(2 "Sectoral Tax Rate Changes" 3 "Average Tax Rate Change" ) position(0) bplacement(nwest) rows(2)) ///
	name(Fig5b, replace) 

cd "$path"
