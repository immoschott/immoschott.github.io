* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$figpath"

use FigureB1.dta

******
* Set up font sizes, etc. for graphs (common across all graphs)
* Line thickness
local lthick lwidth(thick)
* All axis and label fonts:
local fontsize large
******

local leg legend( rows(1) order(1 "BEA"  5 "Census" 6 "NBER" 3 "BLS") size(`fontsize'))
local xstyle xlabel(1950(10)2010, labsize(`fontsize')) xtitle("")
local ystyle ylabel(20(20)80, labsize(`fontsize')) ytitle("Manufacturing", size(`fontsize'))

* Define line styles
local style1 lcolor(gs9) lpattern(solid) connect(l) mcolor(gs9) msize(vsmall) `lthick'
local style2 lcolor(black) lpattern(solid) connect(l) msymbol(O) mfcolor(white) msize(small) mcolor(black) `lthick'
local style3 lcolor(black) lpattern(solid) connect(l) msize(small) mcolor(black) `lthick'
local style4 lcolor(orange_red) lpattern(solid) connect(l) msymbol(S) mcolor(orange_red) mlcolor(orange_red) mfcolor(white) mcolor(orange_red) `lthick'  msize(medium)

twoway 	(connect PS_BEA_man_2 year, `style1' `ystyle' title("Payroll share (%)", size(`fontsize')))  || ///
		(connect PS_BEA_man_4 year, `style1') ///
		(connect PS_BLS_man_SIC year, `style2') ///
		(connect PS_BLS_man_NAICS year, `style2') ///
		(connect PS_Census year, `style4') ///
		(connect PS_NBER year, `style3') ///
		, `xstyle'`leg' graphregion(color(white)) name(PS, replace) nodraw


twoway 	(connect LS_BEA_man_2 year, `style1' `ystyle' title("Labor share (%)", size(`fontsize') ))  || ///
		(connect LS_BEA_KLEMS_man year, `style1') ///
		(connect LS_BLS_man_SIC year, `style2') ///
		(connect LS_BLS_man_NAICS year, `style2') ///		
		(connect LS_Census year, `style4') ///
		, `xstyle' `leg' graphregion(color(white)) name(LS, replace) nodraw


grc1leg PS LS, graphregion(color(white)) name(fig_B1, replace) rows(1) iscale(1) imargins(0 0 0 0) 

gr draw fig_B1, ysize(2) xsize(4)

cd "$path"

