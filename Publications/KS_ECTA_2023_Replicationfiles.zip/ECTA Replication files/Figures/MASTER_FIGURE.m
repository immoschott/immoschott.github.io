% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

% Master file to create the Figures in the paper

clear
clc

% To run, adjust the working directory path below
direc           = '...\Replication files/Figures';

% Path where m-files are located
codefolder      = sprintf('%s/Figures_code',direc);

% Path where data is located
datafolder      = sprintf('%s/Figures_data',direc);

cd(codefolder)

%% Create Figure 4

Figure_4

% NOTE: The remaining figures are created using Stata.
