* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Master file to create the Tables in the paper

global path 	".../Replication files/Tables/Tables_code"
global tabpath ".../Replication files/Tables/Tables_data"

cd "$path"

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* MAIN PAPER

* Create Table 1
do Table_1.do 

* Create Table 7 
do Table_7.do
 
* Create Table 8
do Table_8.do 

* Create Table 9
do Table_9.do 

* Create Table 10
do Table_10.do 

* Create Table 11
do Table_11.do 


* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* APPENDIX

* Create Table B.1
do Table_B1.do 

* Create Table D.1
do Table_D1.do 

* Create Table D.2
do Table_D2.do 

* Create Table D.3
do Table_D3.do 

* Create Table D.4
do Table_D4.do 

* Create Table D.5
do Table_D5.do 

* Create Table D.6
do Table_D6.do 

* Create Table D.7
do Table_D7.do 

* Create Table D.8
do Table_D8.do 

* Create Table D.9
do Table_D9.do 

* Create Table D.10
do Table_D10.do 



