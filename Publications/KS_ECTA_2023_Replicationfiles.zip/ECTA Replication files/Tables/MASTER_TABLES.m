% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

% Master file to create the Tables in the paper

clear
clc

% To run, adjust the working directory path below
direc           = '...\Replication files/Tables';

% Path of the data folder where model output is saved
codefolder      = sprintf('%s/Tables_code',direc);

% Path of the data folder where model output is saved
datafolder      = sprintf('%s/Tables_data',direc);

cd(codefolder)

%% Create Table 3

Table_3

%% Create Table 4

Table_4

%% Create Table 5

Table_5

%% Create Table 6

Table_6

%% APPENDIX material

Table_C1 
