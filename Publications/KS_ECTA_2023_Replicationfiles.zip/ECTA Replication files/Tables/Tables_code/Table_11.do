* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use Table11.dta

foreach num of numlist 8 20 {
	quietly reghdfe con`num'_va ls_NBER if year>1993, absorb(year sic) vce(cl sic)
	est store post93_va_ls_`num'
	quietly reghdfe con`num' ls_NBER if year>1993, absorb(year sic) vce(cl sic)
	est store post93_ls_`num'
	quietly reghdfe con`num' ls_NBER if year<1993, absorb(year sic) vce(cl sic)
	est store pre93_ls_`num'
}

foreach num of numlist 8 20 {
	quietly reghdfe con`num'_va teit if year>1993, absorb(year sic) vce(cl sic)
	est store post93_va_`num'
	quietly reghdfe con`num' teit if year>1993, absorb(year sic) vce(cl sic)
	est store post93_`num'
	quietly reghdfe con`num' teit if year<1993, absorb(year sic) vce(cl sic)
	est store pre93_`num'
}

* Display Table
esttab post93_va_ls_8 post93_va_ls_20 post93_ls_8 post93_ls_20 pre93_ls_8 pre93_ls_20, se nostar b(2) keep(ls_NBER) label 
esttab post93_va_8 post93_va_20 post93_8 post93_20  pre93_8 pre93_20,  se nostar b(2) keep(teit) label 


cd "$path"
