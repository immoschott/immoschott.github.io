* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use Table7.dta

* Create a variable that orders the sectors as in the paper
gen ord 	= 1 if SIC == 20
replace ord = 2 if SIC == 10
replace ord = 3 if SIC == 40
replace ord = 4 if SIC == 999
replace ord = 5 if SIC == 50
replace ord = 6 if SIC == 52
replace ord = 7 if SIC == 70

sort ord 

format tau85 tau13 dtax LS_SIC_* %9.2f

l SIC tau85 tau13 dtax LS_SIC_* N

cd "$path"
