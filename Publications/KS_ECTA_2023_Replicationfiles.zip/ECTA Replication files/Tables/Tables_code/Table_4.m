% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

cd(datafolder)

% Load the model results
load Table4.mat

fprintf(2,'Showing Table 4... \n');

%% Data
% Source: Statistical Abstract of the United States 1970 Manufacturing Table 1190

% Establishments, percentage distribution 
data.est    = [65.0, 24.2, 6.5, 3.6, 0.7];
data.emp    = [5.6, 17.7, 16.6, 27.3, 32.8];
data.va     = [5.1, 14.9, 14.9, 27.1, 38.0];

% Display model output in percentage terms
Tab4.est    = Tab4.est * 100;
Tab4.emp    = Tab4.emp * 100;
Tab4.va     = Tab4.va  * 100;


%% Generate output

fprintf('\nData: 1967\n')
fprintf('\nEstablishment size  \t1-19\t20-99\t100-249\t\t250-999\t\t1000+\n\n')
fprintf('Establishments\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n',data.est(1),data.est(2),data.est(3),data.est(4),data.est(5)) 
fprintf('Employment\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n',data.emp(1),data.emp(2),data.emp(3),data.emp(4),data.emp(5)) 
fprintf('Value Added\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n',data.va(1),data.va(2),data.va(3),data.va(4),data.va(5)) 


fprintf('\nCalibrated Model\n')
fprintf('\nEstablishment size  \t1-19\t20-99\t100-249\t\t250-999\t\t1000+\n\n')
fprintf('Establishments\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n',Tab4.est(1),Tab4.est(2),Tab4.est(3),Tab4.est(4),Tab4.est(5)) 
fprintf('Employment\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n',Tab4.emp(1),Tab4.emp(2),Tab4.emp(3),Tab4.emp(4),Tab4.emp(5)) 
fprintf('Value Added\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n',Tab4.va(1),Tab4.va(2),Tab4.va(3),Tab4.va(4),Tab4.va(5)) 

cd(codefolder)

clear data Tab4
