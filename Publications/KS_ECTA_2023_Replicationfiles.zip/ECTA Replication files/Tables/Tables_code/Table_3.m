% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

cd(datafolder)

load Table3.mat

fprintf(2,'Showing Table 3... \n');


%% Generate output

fprintf('%53s\t\t%s\n','     Data' , 'Model')
fid=fopen('test.txt','w');
momchoice   = [Tab3.momchoice(3), Tab3.momchoice(4), Tab3.momchoice(1), Tab3.momchoice(2)];
for ii = momchoice
    fprintf(fid,'%30s\t\t\t%0.2f%15.2f\n',Tab3.data{ii,2},Tab3.data{ii,1},Tab3.model{ii});    
end
type test.txt
fclose(fid);
fprintf('\n The distance between data and model moments is %4.3f%%\n', 100*Tab3.res  )
delete test.txt

cd(codefolder)

clear fid ii momchoice Tab3
