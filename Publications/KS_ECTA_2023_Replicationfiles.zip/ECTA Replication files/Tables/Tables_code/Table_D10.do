* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* May 2022

clear
cd "$tabpath"

use TableD7_D8_D9_D10.dta

foreach num of numlist 4 8 20 50 {
	quietly reghdfe con`num' teit , absorb(year sic) vce(cl sic)
	est store sales`num'
	quietly reghdfe con`num' teit , absorb(year sic sic#c.year) vce(cl sic)
	est store trsales`num'
	quietly reghdfe con`num' ls_NBER , absorb(year sic) vce(cl sic)
	est store bsales`num'
	quietly reghdfe con`num' ls_NBER , absorb(year sic sic#c.year) vce(cl sic)
	est store btrsales`num'

}

g pre93=(year<1993)
foreach num of numlist 4 8 20 50 {
	quietly reghdfe con`num' teit , absorb(year sic#pre93) vce(cl sic)
	est store nsales`num'
	quietly reghdfe con`num' teit , absorb(year sic#pre93 sic#c.year) vce(cl sic)
	est store ntrsales`num'
	quietly reghdfe con`num' ls_NBER , absorb(year sic#pre93) vce(cl sic)
	est store bnsales`num'
	quietly reghdfe con`num' ls_NBER , absorb(year sic#pre93 sic#c.year) vce(cl sic)
	est store bntrsales`num'

}


esttab bsales4 bsales8 bsales20 bsales50 btrsales4  btrsales8 btrsales20 btrsales50 , se stats(N, fmt(0 3)) keep(ls_NBER) b(2) nomtitles label nostar
esttab sales4 sales8 sales20 sales50 trsales4  trsales8 trsales20 trsales50 , se stats(N, fmt(0 3)) keep(teit) b(2) nomtitles label nostar
esttab bnsales4 bnsales8 bnsales20 bnsales50 bntrsales4  bntrsales8 bntrsales20 bntrsales50, se stats(N, fmt(0 3)) keep(ls_NBER) b(2) nomtitles label  nostar
esttab nsales4 nsales8 nsales20 nsales50 ntrsales4 ntrsales8 ntrsales20 ntrsales50 , se stats(N, fmt(0 3)) keep(teit) b(2) nomtitles label  nostar 


cd "$path"
