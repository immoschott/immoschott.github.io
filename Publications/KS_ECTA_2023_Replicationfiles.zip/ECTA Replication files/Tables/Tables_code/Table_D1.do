* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use TableD1.dta

* Baseline (w/o country specific trends)
quietly reghdfe lknhc cit_aux, absorb(i.cid i.year) vce(cl cid)
est store kh1
quietly reghdfe lknhc cit_aux lplk ltfp, absorb(i.cid i.year) vce(cl cid)
est store kh2
quietly rreg lknhc cit_aux  i.cid i.year 
est store kh3
quietly rreg lknhc cit_aux lplk ltfp i.cid i.year 
est store kh4

* w/ country-specific trends.
quietly reghdfe lknhc cit_aux, absorb(cid year cid#c.year) vce(cl cid)
est store tkh1
quietly reghdfe lknhc cit_aux lplk ltfp,absorb(cid year cid#c.year) vce(cl cid)
est store tkh2
quietly rreg lknhc cit_aux  i.cid i.year i.cid#c.year
est store tkh3
quietly rreg lknhc cit_aux lplk ltfp i.cid i.year i.cid#c.year
est store tkh4
	
* Print results
esttab kh1 kh2 kh3 kh4, se stats(N, fmt(0 3)) b(2) keep(cit_aux lplk ltfp) label   nomtitles
esttab tkh1 tkh2 tkh3 tkh4, se stats(N, fmt(0 3)) b(2) keep(cit_aux lplk ltfp) label   nomtitles


cd "$path"



