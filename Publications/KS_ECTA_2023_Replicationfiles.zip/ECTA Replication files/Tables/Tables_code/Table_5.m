% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

cd(datafolder)

load Table5a.mat
load Table5b.mat
load Table5c.mat

fprintf(2,'Showing Table 5... \n');

%% Data
% Source: Annual Survey of Manufactures, and Business Dynamics Statistics

% Establishments, percentage distribution 
data.y1967  = [0.4, 0.539, .62/.7, 0.84, 60.5];
data.y1954  = [0.5, 0.61, NaN, 0.84, 54.5];
data.y2014  = [0.2, 0.34, 0.44, 0.77, 44.4];

% Round labor share to two digits
LS      = round(1000*[Tab5a(2),Tab5b(2),Tab5c(2)]) / 1000; 


%% Generate output

fprintf('\n    \t\t\t\tModel Simulation\t\t\tData\n')
fprintf('\nYear  \t\t\t\t1967\t1954\t2014\t\t1967\t1954\t2014\n\n')
fprintf('Corporate tax rate\t\t%1.2f\t%1.2f\t%1.2f\t\t%1.2f\t%1.2f\t%1.2f\n',Tab5a(1),Tab5b(1),Tab5c(1),data.y1967(1),data.y1954(1),data.y2014(1))
fprintf('Labor share\t\t\t%1.2f\t%1.2f\t%1.2f\t\t%1.2f\t%1.2f\t%1.2f\n',LS(1),LS(2),LS(3),data.y1967(2),data.y1954(2),data.y2014(2))
fprintf('Median LS ratio\t\t\t%1.2f\t%1.2f\t%1.2f\t\t%1.2f\t%1.2f\t%1.2f\n',Tab5a(3),Tab5b(3),Tab5c(3),data.y1967(3),data.y1954(3),data.y2014(3))
fprintf('Inverse Pareto Index (250+)\t%1.2f\t%1.2f\t%1.2f\t\t%1.2f\t%1.2f\t%1.2f\n',Tab5a(4),Tab5b(4),Tab5c(4),data.y1967(4),data.y1954(4),data.y2014(4))
fprintf('Average Establishment Size\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t%1.1f\t%1.1f\n\n',Tab5a(5),Tab5b(5),Tab5c(5),data.y1967(5),data.y1954(5),data.y2014(5))
fprintf('Price Level p\t\t\t%1.2f\t%1.2f\t%1.2f\n',Tab5a(6),Tab5b(6),Tab5c(6))
fprintf('Cost of capital r\t\t%1.2f\t%1.2f\t%1.2f\n',Tab5a(7),Tab5b(7),Tab5c(7))
fprintf('Aggregate capital demand\t%1.2f\t%1.2f\t%1.2f\n\n',Tab5a(8),Tab5b(8),Tab5c(8))


%%
cd(codefolder)

clear data LS Tab5*
