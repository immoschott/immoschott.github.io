* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear

cd "$tabpath"

use Table1.dta

* Regressions

* Manufacturing sector
quietly reghdfe LIS cit_aux if sector==0,absorb(i.cid i.year) vce(cl cid)
est store tM
* Include country-specific trends
quietly reghdfe LIS cit_aux if sector==0,absorb(i.cid i.year i.cid#c.year) vce(cl cid)
est store trM

* Aggregate sector
quietly reghdfe LIS cit_aux if sector==2,absorb(i.cid i.year) vce(cl cid)
est store tagg
* Include country-specific trends
quietly reghdfe LIS cit_aux if sector==2,absorb(i.cid i.year i.cid#c.year) vce(cl cid)
est store tragg

esttab tM tagg trM tragg, se stats(N, fmt(0 3)) b(2) label mtitles("Manufacturing" "Aggregate" "Manufacturing" "Aggregate")  keep(cit_aux)

cd "$path"

