* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use Table10.dta

* Levels regressions with fixed effects w and w/o trends
foreach var of varlist lest {
	* no industry-soecific trends
		quietly reghdfe `var' teit ,absorb(sic year) vce(cl sic)
		est store l`var'
		quietly reghdfe `var' beta ,absorb(sic year) vce(cl sic)
		est store b`var'
	* industry specific trends	
		quietly reghdfe `var' teit ,absorb(sic year sic#c.year) vce(cl sic)
		est store tl`var'
		quietly reghdfe `var' beta ,absorb(sic year sic#c.year) vce(cl sic)
		est store tb`var'
}

esttab blest tblest , se keep(beta) b(2) label
esttab llest tllest , se keep(teit) b(2) label 
cd "$path"
