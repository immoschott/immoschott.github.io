* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use TableD4.dta

g dtr=.
g dlw=.
g dunemp=.
forvalues d=10(10)10 {
	replace dtr=s`d'.atr
	replace dlw=s`d'.lw
	replace dunemp=s`d'.unemp

	quietly reghdfe s`d'.lis dtr, absorb(year) vce(cl statefip)
	est store de1`d'
	quietly reghdfe s`d'.lis dtr, absorb(year statefip) vce(cl statefip)
	est store de2`d'
	quietly reghdfe s`d'.lis dtr dlw, absorb(year) vce(cl statefip)
	est store de3`d'
	quietly reghdfe s`d'.lis dtr dlw, absorb(year statefip) vce(cl statefip)
	est store de4`d'
	quietly reghdfe s`d'.lis dtr dlw dunemp, absorb(year) vce(cl statefip)
	est store de5`d'
	quietly reghdfe s`d'.lis dtr dlw dunemp, absorb(year statefip) vce(cl statefip)
	est store de6`d'
}

esttab de110 de210 de310 de410 de510 de610 , se stats(N, fmt(0 3)) keep(dtr dlw dunemp) b(2) nomtitles label 

cd "$path"
