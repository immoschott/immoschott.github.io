* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use TableD7_D8_D9_D10.dta

* Difference Specifications

g dls=.
lab var dls "∆Labor Share"

g dtr=.
lab var dtr "∆Corporate tax rate"

forvalues i=10(5)10{

	replace dls = s`i'.ls
	replace dtr = s`i'.teit

	foreach num of numlist 4 8 20 50 {
		quietly reghdfe s`i'.con`num' dtr if year<1993, absorb(year ) vce(cl sic)
		est store tdif`i'_`num'
		quietly reghdfe s`i'.con`num' dls if year<1993, absorb(year ) vce(cl sic)
		est store lsdif`i'_`num'
	}
	esttab lsdif`i'_4 lsdif`i'_8 lsdif`i'_20 lsdif`i'_50, se star  b(2)  keep(dls) label mtitles("∆con4" "∆con8" "∆con20" "∆con50")  	ti("Difference over `i' years")
	esttab tdif`i'_4 tdif`i'_8 tdif`i'_20 tdif`i'_50, se star  b(2)  keep(dtr) label mtitles("∆con4" "∆con8" "∆con20" "∆con50")  ti("Difference over `i' years")
}


forvalues i=10(5)10{
	replace dls = s`i'.ls
	replace dtr = s`i'.teit
	foreach num of numlist 4 8 20 50 {
		quietly reghdfe s`i'.con`num' dtr if year>=2007, absorb(year ) vce(cl sic)
		est store tdif`i'_`num'
		quietly reghdfe s`i'.con`num' dls if year>=2007, absorb(year ) vce(cl sic)
		est store lsdif`i'_`num'
	}
	esttab lsdif`i'_4 lsdif`i'_8 lsdif`i'_20 lsdif`i'_50, se star  b(2)  keep(dls) label mtitles("∆con4" "∆con8" "∆con20" "∆con50")  	ti("Difference over `i' years")
	esttab tdif`i'_4 tdif`i'_8 tdif`i'_20 tdif`i'_50, se star  b(2)  keep(dtr) label mtitles("∆con4" "∆con8" "∆con20" "∆con50")  ti("Difference over `i' years")
}


forvalues i=10(5)10{
	replace dls = s`i'.ls
	replace dtr = s`i'.teit
	foreach num of numlist 4 8 20 50 {
		quietly reghdfe s`i'.con`num' dtr, absorb(year ) vce(cl sic)
		est store tdif`i'_`num'
		quietly reghdfe s`i'.con`num' dls, absorb(year ) vce(cl sic)
		est store lsdif`i'_`num'
	}
	esttab lsdif`i'_4 lsdif`i'_8 lsdif`i'_20 lsdif`i'_50, se star  b(2)  keep(dls) label mtitles("∆con4" "∆con8" "∆con20" "∆con50")  	ti("Difference over `i' years")
	esttab tdif`i'_4 tdif`i'_8 tdif`i'_20 tdif`i'_50, se star  b(2)  keep(dtr) label mtitles("∆con4" "∆con8" "∆con20" "∆con50")  ti("Difference over `i' years")
}

cd "$path"

