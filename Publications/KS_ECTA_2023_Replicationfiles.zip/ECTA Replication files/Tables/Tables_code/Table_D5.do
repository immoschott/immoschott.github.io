* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use TableD5_D6.dta 

*  Difference regressions 
g dteit=.
g dbeta=.

label var dteit "Δ Tax Rate (x100)"
label var dbeta "Δ Labor Share"


sort sic year
foreach d of numlist 10 {
	replace dteit=s`d'.teit
	replace dbeta=s`d'.beta

	foreach var of varlist lkn lin lest lik   {
		quietly reghdfe s`d'.`var' dteit ,absorb(year) vce(cl sic)
		est store e`var'`d'
		quietly reghdfe s`d'.`var' dbeta ,absorb(year) vce(cl sic)
		est store b`var'`d'
	}
}

esttab blkn10 blin10 blik10 blest10, se keep(dbeta) b(2) label nostar
esttab elkn10 elin10 elik10 elest10, se keep(dteit) b(2) label nostar 

cd "$path"
