* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use TableD2.dta

* Difference Specifications
g dtr=.
forvalues d=10(10)20 {
	replace dtr=s`d'.cit_aux
	quietly reghdfe s`d'.lknhc dtr, absorb(i.year) vce(cl cid)
	est store kh1`d'
	quietly reghdfe s`d'.lknhc dtr s`d'.lplk s`d'.ltfp, absorb(i.year) vce(cl cid)
	est store kh2`d'
}

* Print results
esttab kh110 kh120 kh210 kh220 ,  se stats(N, fmt(0 3)) b(2) keep(dtr) label   nomtitles


cd "$path"



