* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use TableB1.dta

format d_LS_BEA_man d_LS_BLS_man d_LS_Census d_*PS* %3.1f

* Labor share measures
l d_LS_BEA_man d_LS_BLS_man d_LS_Census

* Payroll share measures
l d_*PS* 

cd "$path"


