% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

cd(datafolder)

% Load model results 
load Table6.mat

fprintf(2,'Showing Table 6... \n');

%% Data
% Source: Business Dynamics Statistics for 2014

% Establishments, percentage distribution 
data.est    = [67.1, 23.6, 6.1, 2.8, 0.4];
data.emp    = [9.5, 23.7, 21.2, 28.2, 17.3];

% Display model output in percentage terms
Tab6.est   = Tab6.est * 100;
Tab6.emp   = Tab6.emp * 100;

%% Generate output

fprintf('\nData: 2014\n')
fprintf('Establishment size  \t<20\t20-99\t100-249\t\t250-999\t\t1000+\n')
fprintf('Establishments\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n',data.est(1),data.est(2),data.est(3),data.est(4),data.est(5)) 
fprintf('Employment\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n',data.emp(1),data.emp(2),data.emp(3),data.emp(4),data.emp(5)) 

fprintf('\nModel Simulation with tau = 0.2\n')
fprintf('Establishment size  \t<20\t20-99\t100-249\t\t250-999\t\t1000+\n')
fprintf('Establishments\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n',Tab6.est(1),Tab6.est(2),Tab6.est(3),Tab6.est(4),Tab6.est(5)) 
fprintf('Employment\t\t%1.1f\t%1.1f\t%1.1f\t\t%1.1f\t\t%1.1f\n\n\n',Tab6.emp(1),Tab6.emp(2),Tab6.emp(3),Tab6.emp(4),Tab6.emp(5)) 


cd(codefolder)

clear data Tab6
