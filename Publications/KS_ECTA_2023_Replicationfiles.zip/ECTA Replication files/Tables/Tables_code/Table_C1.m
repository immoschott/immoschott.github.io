% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

cd(datafolder)

% Load model results 
load TableC1.mat

fprintf(2,'Showing Table C.1... \n');


%% Generate output

data    = TabC1.data;
model   = TabC1.model;
names   = TabC1.names;

% Number of sectors
numsec  = size(model,1);

fprintf('\n%10s%30s\t\t%40s\n','Sector', 'Data' , 'Model')
fprintf('%20s\t%s\t%s\t%s\t%s\t%s \t\t%s\t%s\t%s\t%s\t%s\t%s\n','(1)', '(2)', '(3)', '(4)', '(5)', '(6)','(1)', '(2)', '(3)', '(4)', '(5)', '(6)')
for jj = 1:numsec
fprintf('%10s\t%1.3f\t%1.3f\t%1.3f\t%1.3f\t%1.3f\t%1.3f \t\t%1.3f\t%1.3f\t%1.3f\t%1.3f\t%1.3f\t%1.3f\n',names{jj}, ...
    data(jj,1), data(jj,2), data(jj,3), data(jj,4), data(jj,5), data(jj,6), model(jj,1), model(jj,2), model(jj,3), model(jj,4), model(jj,5), model(jj,6))
end

cd(codefolder)

clear data model names numsec TabC1 jj
