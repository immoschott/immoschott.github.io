* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear

cd "$tabpath"

use TableD3.dta

* Create 10-year differences
gen dtr = s10.cit_aux
gen dls = s10.LIS

keep if year>=1981 

lab var dtr "{$\Delta_10$}  Corporate tax rate"

quietly reghdfe dls dtr if sector==0  , absorb(year) vce(cl cid)
est store dM
quietly reghdfe dls dtr if sector==2  , absorb(year) vce(cl cid)
est store dagg

quietly reghdfe dls dtr if sector==0  , absorb(cid year) vce(cl cid)
est store dtM
quietly reghdfe dls dtr if sector==2  , absorb(cid year) vce(cl cid)
est store dtagg

esttab dM dagg dtM dtagg, se stats(N, fmt(0 3)) b(2) label mtitles("Manufacturing" "Aggregate" "Manufacturing" "Aggregate")  keep(dtr) 

cd "$path"

