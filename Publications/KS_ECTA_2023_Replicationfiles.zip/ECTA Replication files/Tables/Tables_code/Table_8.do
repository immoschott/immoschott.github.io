* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$tabpath"

use Table8.dta


quietly reghdfe lis atr, absorb(year statefip) vce(cl statefip)
est store e1
quietly reghdfe lis atr, absorb(year statefip i.statefip#c.year) vce(cl statefip)
est store e2

quietly reghdfe lis atr lw, absorb(year statefip) vce(cl statefip)
est store e3
quietly reghdfe lis atr lw, absorb(year statefip i.statefip#c.year) vce(cl statefip)
est store e4

quietly reghdfe lis atr lw unemp, absorb(year statefip) vce(cl statefip)
est store e5
quietly reghdfe lis atr lw unemp, absorb(year statefip i.statefip#c.year) vce(cl statefip)
est store e6

* Show results
esttab e1 e2 e3 e4 e5 e6 , se stats(N, fmt(0 3)) keep(atr lw unemp) b(2) nomtitles label
cd "$path"
