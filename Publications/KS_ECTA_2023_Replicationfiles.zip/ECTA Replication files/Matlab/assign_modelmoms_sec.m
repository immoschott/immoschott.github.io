% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

%% Define model moments
modelmoms       = cell(1,1);

% Aggregate labor share
LS              = (n_pol(:)'*probst*Mstar) / (pstar*Q_star); % Total wage payments over total output
modelmoms{1,1}  = LS;

% Median labor share value-added weighted
% Sort the firms by their labor share
[lssort, order] = sort(w*n_pol(:)./(pstar*q_pol(:)),'ascend');
% Apply the same order to value added distribution
va              = pstar*q_pol(:);
va              = va(order) / sum(va);
% Find weighted median labor share
idx             = find(cumsum(va)>=0.5,1,'first');
% Find the unweighted median labor share
firms           = probst(order) / sum(probst); 
idx_uw          = find(cumsum(firms)>=0.5,1,'first');
% VA-weighted median labor share divided by unweighted median labor share
modelmoms{2,1}  = lssort(idx)/lssort(idx_uw);

% Exit rate
modelmoms{3,1}  = x;

% Average employment
modelmoms{4,1}  = n_pol(:)'*probst/sum(probst);

% Concentration of employment in largest firms 
% "Largest" always corresponds to the same size bin cutoff, hence
% the fraction of firms in that bin varies by sector.
cutoffs         = [0.0379, 0.042, 0.037, 0.0404, 0.046, 0.041];
[nsort, order] = sort(n_pol(:),'descend');
% Now sum up employment in top x% of firms and ask how 
% much employment is concentrated within those firms
firms = probst(order) / sum(probst); % Apply order to probst
idx = find(cumsum(firms)>=cutoffs(jj),1,'first');
% Total employment in those firms:
modelmoms{5,1}  = sum(nsort(1:idx).*firms(1:idx)) / sum(nsort.*firms);

% Standard deviation of labor shares divided by median (weighted by output)
[lssort, order] = sort(w*n_pol(:)./(pstar*q_pol(:)),'ascend');
% Now find the value added of those firms in the same order
va              = pstar*q_pol(:);
va              = va(order) / sum(va);
idx             = find(cumsum(va)>=0.5,1,'first');
% Now find the weighted standard deviation of labor shares
modelmoms{6,1}  = std(w*n_pol(:)./(pstar*q_pol(:)),va) / lssort(idx);

nummoms         = size(modelmoms,1);
