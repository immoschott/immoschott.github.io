% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

% Construct labor share grid
BETA_GRID       = linspace(betalow,GAMMA,PARMS.lenalpha);
base            = GAMMA - betalow;
middle          = base/m;
[~, aux]        = min(abs(BETA_GRID - betalow - middle));
middle          = BETA_GRID(aux) - betalow;
% The area of the triangle = 1, and A = h*b / 2,
height          = 2/base;
% calculate the PDF for the first half. slope = rise/run
slope           = height/middle;
tri_pdf         = @(x) (x-betalow)*slope;
weights_1       = [tri_pdf(BETA_GRID)] .* (BETA_GRID<(betalow+middle));
% calculate the PDF for the second half. slope = rise/run
slope           = -height/(base-middle);
tri_pdf         = @(x) -(GAMMA-x)*slope;
weights_2       = [tri_pdf(BETA_GRID)] .* (BETA_GRID>=(betalow+middle));
weights         = weights_1 + weights_2;
weights         = weights'/sum(weights);
% plot(BETA_GRID,weights)
lenalpha        = length(BETA_GRID(2:end-1)); % adjust
weights         = weights(2:end-1);
weights         = flipud(weights);
ALPHA_GRID      = fliplr(GAMMA - BETA_GRID(2:end-1));
clear BETA_GRID

% Effective discount factor
RHO             = RHO_org*(1-x);

% Construct productivity grid
m               = sqrt(PARMS.leneps-1); 
EPS             = mu_eps + linspace(-m*sigma_eps,m*sigma_eps,PARMS.leneps)';
tmp             = normpdf(EPS,mu_eps,sigma_eps)';
invar           = tmp/sum(tmp);
tran_eps        = eye(PARMS.leneps);
EPS             = exp(EPS);
pi_e            = invar; % distribution of entrants over eps
clear m tmp
