% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

clear 
close all
clc

% Adjust the working directory path below
direc       = '...\Replication files';

% The main Matlab folder (leave these relative paths unchanged)
mainfolder      = sprintf('%s/Matlab',direc);
% Folder to save output in
tabfolder   = sprintf('%s/Tables/Tables_data',direc);
figfolder   = sprintf('%s/Figures/Figures_data',direc);

cd(mainfolder)

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

%% Setup

% Define parameters and set up quantitative solution
set_parms

% Define data moments
assign_datamoms

%% Solve baseline model

out_bench           = solve_model(datamoms,PARMS);

% Use benchmark results as input in experiments
PARMS.out_bench     = out_bench;
fprintf('Finished running the benchmark model. The resulting labor share was %1.2f.\n\n',out_bench.LS);


%% Conduct experiments

%% Model with high corporate tax rate (1954)

% Change the tax rate to 50%:
PARMS.BENCHMARK = 0; 
PARMS.TAU       = 0.50;

out_t50         = solve_model(datamoms,PARMS);
fprintf('Finished running the model with high tax rate. The resulting labor share was %1.2f.\n\n',out_t50.LS);

%% Model with low corporate tax rate (2014)

% Change the tax rate to 20%:
PARMS.BENCHMARK = 0; 
PARMS.TAU       = 0.20;

out_t20         = solve_model(datamoms,PARMS);
fprintf('Finished running the model with low tax rate. The resulting labor share was %1.2f.\n\n',out_t20.LS);

%% Beyond the manufacturing sector

%% Setup

% The model is solved for the following sectors:
% MAN, MIN, TCPU, WHO, RET, SRV
% For each sector, the model is solve three times
% 1) Benchmark 1987
% 2) Changed sector-specific tax rate
% 3) Apply aggregate tax rate change to each sector (homogeneous)

% Sector-specific data moments from Table C.I
assign_datamoms_sector

% Sector-specific parameters from Table C.II
set_parms_sector

%% Solve baseline model for each sector
% Save all moments by sector
M_sec           = zeros(6,6);
% Save labor share by sector
LS_sec          = zeros(6,3);

% Solve each sector with the three different tax rates

for ii = 1:3

    PARMS.BENCHMARK         = ii;

    for jj = 1:6

        if ii == 1
            fprintf('Solving %s sector, baseline.\n',secnames{jj});
        elseif ii == 2
            fprintf('Solving %s sector, sector-specific change in tax.\n',secnames{jj});
        elseif ii == 3
            fprintf('Solving %s sector, common change in tax.\n',secnames{jj});
        end

        out_bench           = solve_model_sec(datamoms,PARMS,jj);

        if ii == 1
            M_sec(jj,:)         = out_bench.mm; % Model moments, baseline
        end
        LS_sec(jj,ii)       = out_bench.LS; % Labor shares

    end
end
% Create Table C.I: Comparison between model and data moments
tablec1

% Create model results for Figure 5
figure5


%% End of code



