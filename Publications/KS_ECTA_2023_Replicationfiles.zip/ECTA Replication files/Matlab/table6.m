% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

% The employment size distribution
% Create 5 indicator variables for size classes 1-19,20-99,100-499,499+
ind_sz1000plus  = n_pol(:)>=1000;
ind_sz250to999  = (250<=n_pol(:) & n_pol(:)<1000);
ind_sz100to249  = (100<=n_pol(:) & n_pol(:)<250);
ind_sz20to99    = (20<=n_pol(:) & n_pol(:)<100);
ind_sz0to19     = n_pol(:)<20;

% Compute fraction of establishments in various bins
dist_sz1000plus = sum(probst(ind_sz1000plus))/sum(probst);
dist_sz250to999 = sum(probst(ind_sz250to999))/sum(probst);
dist_sz100to249 = sum(probst(ind_sz100to249))/sum(probst);
dist_sz20to99   = sum(probst(ind_sz20to99))/sum(probst);
dist_sz0to19    = sum(probst(ind_sz0to19))/sum(probst);
firms           = [dist_sz0to19 dist_sz20to99 dist_sz100to249 dist_sz250to999 dist_sz1000plus];
firms           = round(firms/sum(firms),3); % Round

% Compute employment in various bins
emp_mass        = n_pol(:).*probst*Mstar;
emp_sz1000plus  = sum(emp_mass(ind_sz1000plus));
emp_sz250to999  = sum(emp_mass(ind_sz250to999));
emp_sz100to249  = sum(emp_mass(ind_sz100to249));
emp_sz20to99    = sum(emp_mass(ind_sz20to99));
emp_sz0to19     = sum(emp_mass(ind_sz0to19));
emp             = [emp_sz0to19 emp_sz20to99 emp_sz100to249 emp_sz250to999 emp_sz1000plus];
emp             = round(emp/sum(emp),3); % Round

% Save the output
filename        = sprintf('%s%s','Table6','.mat');
Tab6.est       = firms;
Tab6.emp       = emp;
fullname        = fullfile(PARMS.tabfolder, filename);
save(fullname,'Tab6'); % save as .mat file
fprintf('Saved data for Table 6.\n');
