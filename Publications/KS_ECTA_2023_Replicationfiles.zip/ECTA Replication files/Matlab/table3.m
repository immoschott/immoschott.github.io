% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

tmp_data                        = cat(1,datamoms{:,1});
tmp_model                       = cat(1,modelmoms{:,1});

% Moments to target
momchoice                       = [1,     2,      3,      4];
% 1)    Aggregate labor share
% 2)    Median value-added weighted labor share divided by median labor share
% 3)    Average Firm Size
% 4)    Fraction of firms with 250+ employment 

tmp_model                       = tmp_model(momchoice);
tmp_data                        = tmp_data(momchoice);
    
% Compute distance in %
W                               = ones(size(tmp_model)); W = W/sum(W);
WW                              = eye(length(momchoice));
X                               = (tmp_model-tmp_data)./tmp_data;
WW(1:length(momchoice)+1:end)   = W;
res                             = sqrt(X'*WW*X);

% Save the output
filename                        = sprintf('%s%s','Table3','.mat');
Tab3.data                       = datamoms;
Tab3.model                      = modelmoms;
Tab3.res                        = res;
Tab3.momchoice                  = momchoice;
fullname                        = fullfile(PARMS.tabfolder, filename);
save(fullname,'Tab3'); % save as .mat file
fprintf('Saved data for Table 3.\n');


     

