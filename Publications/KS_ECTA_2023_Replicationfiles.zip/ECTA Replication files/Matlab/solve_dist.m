% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

entrants    = pi_e'; % Distribution of entrants
trans       = tran_eps*(1-x); % Aggregate transition matrix
trans       = trans';
% Aggregate distribution over EPS and ALPHA states
probst      = (eye(PARMS.leneps)-trans)^(-1)*entrants*(1-x); 
dist        = kron(ones(1,lenalpha),probst);
dist        = bsxfun(@times,dist,weights'); 
probst      = dist(:);
