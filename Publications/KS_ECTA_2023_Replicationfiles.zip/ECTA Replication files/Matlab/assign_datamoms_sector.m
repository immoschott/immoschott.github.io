% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

% Clear previous results from benchmark model
clear datamoms nummoms out_* 

% The model is solved for the following sectors:
    % MAN, MIN, TCPU, WHO, RET SRV

% The data moments are explained in Table C.I 
datamoms        = zeros(6,6);
datamoms(1,:)   = [0.604, 0.648 / 0.701, 0.104, 54, 0.528, 0.200/ 0.648]; % MAN
datamoms(2,:)   = [0.408, 0.305 / 0.401, 0.208, 23, 0.524, 0.208/ 0.305]; % MIN
datamoms(3,:)   = [0.706, 0.750 / 0.761, 0.129, 24, 0.537, 0.143/ 0.750]; % TCPU
datamoms(4,:)   = [0.588, 0.620 / 0.671, 0.113, 13, 0.379, 0.195/ 0.62]; % WHO
datamoms(5,:)   = [0.61,  0.625 / 0.658, 0.135, 13, 0.370, 0.125/ 0.625 ]; % RET
datamoms(6,:)   = [0.687, 0.690 / 0.723, 0.106, 14, 0.565, 0.159/0.69]; % SRV

% Sector names
secnames        = {"MAN", "MIN", "TCPU", "WHO", "RET", "SRV"};
