% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

if PARMS.fixp == 0 % General equilibrium 
    if count_b == 0
        % Start with a good guess for the price
        if PARMS.BENCHMARK == 1
            p_guess = 1.06958970578738465917467692634090781211853027343750;
        else
            if PARMS.TAU == 0.50
                p_guess     = 1.26391968542152910437;
            elseif PARMS.TAU == 0.20
                p_guess     = 0.76405380066350048196;
            else
                p_guess     = 1;
            end
        end
    else
        p_guess = 0.5*p_0 + 0.5*p_1;
    end
else % Partial equilibrium exercise 
    p_guess     = PARMS.fixp;
end