% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

% Set parameters from Table II
PARMS.DELTA     = 0.10; 
PARMS.GAMMA     = 0.85; 
PARMS.x         = 0.10;
PARMS.RHO_org   = 0.96;
PARMS.w         = 1; % numéraire
PARMS.TAU       = 0.40; 

% Calibrated parameters from Table III
PARMS.mu_eps    = 0.7669490441; 
PARMS.sigma_eps = 0.2895709560; 
PARMS.betalow   = 0.2518690491; 
PARMS.ce        = 158.1532361888;

% Grid length
PARMS.lenalpha  = 21;  % Capital share grid
PARMS.leneps    = 101; % Idiosyncratic productivity grid

% Fixed labor supply
PARMS.N_s       = 1; 

% Switches used during the experiments (0  = no, 1 = yes)
PARMS.BENCHMARK = 1; % to solve benchmark model
PARMS.fixp      = 0; % keep price level fixed (partial eq.)

% Pass output folders to functions
PARMS.tabfolder = tabfolder;
PARMS.figfolder = figfolder;
