% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

function output = solve_model(datamoms,PARMS) %#ok<*INUSL>

% Assign baseline parameters from PARMS object
GAMMA           = PARMS.GAMMA; %#ok<*NASGU>
w               = PARMS.w;
RHO_org         = PARMS.RHO_org;
DELTA           = PARMS.DELTA;
TAU             = PARMS.TAU;
x               = PARMS.x;

% Assign calibrated parameters
mu_eps          = PARMS.mu_eps;
sigma_eps       = PARMS.sigma_eps;
betalow         = PARMS.betalow;
ce              = PARMS.ce;

% Build productivity and capital share grids
build_grids

% Define profits, output, and factor demand functions
set_functions

%% Bisection over the price of the output good

p_0             = 0.5; % lower bound price
p_1             = 1.5; % upper bound price
count_b         = 0;
nCount_b        = 100; % max number of iterations
eval            = 999;
crit_p          = 1e-06;

while (abs(eval) > crit_p) && (count_b <= nCount_b) % Bisection
    
    % Update the price guess
    update_p_guess
    
    % Evaluate the value function at the current price guess
    V_all   = VAL(EPS,TAU,ALPHA_GRID,p_guess);
    
    % Evaluate the free-entry condition
    eval    = (pi_e*V_all)*weights - p_guess*ce;
    
    % Update bounds for the price guess
    if eval > crit_p
        p_1 = p_guess; % Price must fall
    elseif eval < crit_p
        p_0 = p_guess;% Price must increase
    end
    
    % Update counter
    count_b = count_b + 1;
    
end

% Save equilibrium price
pstar       = p_guess;

% Solve for stationary distribution
solve_dist

%% Optimal policy functions
% Dimension is EPS x ALPHA

% Labor demand policy
n_pol       = Nd(EPS,TAU,ALPHA_GRID,pstar);
% Capital demand policy
k_pol       = Kd(EPS,TAU,ALPHA_GRID,pstar);
% Real output function:
q_pol       = Q(EPS,TAU,ALPHA_GRID,pstar);
% Profits (pre-tax)
pi0_pol     = PI_B(EPS,TAU,ALPHA_GRID,p_guess);
% Profits (after tax)
pi1_pol     = PI_A(EPS,TAU,ALPHA_GRID,p_guess);
% Tax payments
tax_pol     = pi0_pol - pi1_pol;

% Find the mass of firms that ensures labor market clearing
Mstar       = PARMS.N_s / (n_pol(:)'*probst);


%% Compute aggregate outcomes

% Aggregate labor demand
N_d_star    = n_pol(:)'*probst*Mstar;
% Aggregate Capital demand
K_d_star    = k_pol(:)'*probst*Mstar;
% Aggregate real output
Q_star      = q_pol(:)'*probst*Mstar;
% Aggregate pre-tax profits
NIBT_star   = pi0_pol(:)'*probst*Mstar - pstar*ce*Mstar;
% Aggregate tax revenue
T_star      = tax_pol(:)'*probst*Mstar;
% Aggregate after-tax profits
NIAT_star   = NIBT_star - T_star;
% Aggregate demand
C_dem       = 1/pstar*(w*PARMS.N_s + NIBT_star) - DELTA*K_d_star;
% Aggregate resource constraint
C_res   = Q_star - DELTA*K_d_star - ce*Mstar;

% Compute model moments
assign_modelmoms


%% Generate output for tables:

if PARMS.BENCHMARK == 1
    % Create Table III: Comparison between model and data moments
    table3
    
    % Create Table IV: Distributions of establishments, employment, value added
    table4
    
    % Create Table V: Main policy experiment
    table5
    
    % Create Figure 4: Joint distribution of value added and labor shares
    figure4
        
elseif PARMS.BENCHMARK == 0
    
    if PARMS.fixp == 0 % General equilibrium
        % Create Table V: Changed tax environment
        table5
        
        if PARMS.TAU == 0.2
            
            % Create Figure 4: Joint distribution of value added and labor shares
            figure4
                        
            % Create Table VI: Employment distribution in low-tax case
            table6

        end

    end
    
end

%% Save additional output

% Save the equilibrium prices
output.w        = PARMS.w;
output.p        = p_guess;
output.r        = R(TAU);
output.K_d      = K_d_star;
output.LS       = round(1000*(modelmoms{1,1}))/1000;

fprintf('\n');

