% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

%% Define moments from the data
datamoms        = cell(1,2);

% Aggregate labor share in 1967
datamoms{1,1}   = 0.539;
datamoms{1,2}   = 'Agg labor share in 1967        '; 

% Median labor share in 1967, value-added weighted
%   divided by the median labor share
datamoms{2,1}   = .8857;  
datamoms{2,2}   = 'VA-weighted p50(LS)/median(LS) '; 

% Average Firm Size, Manufacturing 1967. CofM, p. 39, Table 1
datamoms{3,1}   = 1000*18492 / 305680 ;
datamoms{3,2}   = 'Average Firm Size in 1967      '; 

% Concentration of employment
% Statistical Abstract of the United States 1970 Manufacturing p.22 Table 1190
% Fraction of firms with 250+ employment and their share
datamoms{4,1}   = (5042+6062)/18492;
datamoms{4,2}   = 'EMP share of 250+              '; 

nummoms         = size(datamoms,1);
