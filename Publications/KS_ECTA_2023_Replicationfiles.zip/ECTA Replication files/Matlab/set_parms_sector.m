% Matlab Code for replication of 
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
% by Baris Kaymak and Immo Schott
% June 2023

% The model is solved for the following sectors:
    % MAN, MIN, TCPU, WHO, RET SRV

% Remove benchmark model parameters
fields      = {'x','TAU','mu_eps','sigma_eps','betalow','ce','fixp'};
PARMS       = rmfield(PARMS,fields);

%% Sector-specific parameters
% For each sector, the following vector defines [mu_eps, sigma_eps, x, beta_low, m, c_e]
PARMS_sec       = zeros(6,6); 
PARMS_sec(1,:)  = [0.859001, 0.267136, datamoms(1,3), 0.300867, 1.379330, 115.538]; % MAN
PARMS_sec(2,:)  = [0.901193, 0.259995, datamoms(2,3), 0.164397, 3.261358, 92.901]; % MIN
PARMS_sec(3,:)  = [0.863264, 0.268215, datamoms(3,3), 0.414325, 1.142875, 36.875]; % TCPU
PARMS_sec(4,:)  = [0.699107, 0.206526, datamoms(4,3), 0.312076, 1.827144, 31.996]; % WHO
PARMS_sec(5,:)  = [1.102354, 0.197670, datamoms(5,3), 0.430504, 1.739143, 37.097]; % RET
PARMS_sec(6,:)  = [0.450509, 0.276027, datamoms(6,3), 0.381665, 1.290709, 26.357]; % SRV
% Save to PARMS
PARMS.PARMS_sec = PARMS_sec;

% Initial guess for sector-specific price levels
PARMS.p_guess   = [0.962300, 0.879392, 0.806384, 1.008252, 0.629593, 1.128047];

%% Sector-specific tax rates
% Initial 1987, sector-specific 2013, common decline 2013
TAU_sec         = zeros(6,3);
TAU_sec(1,1:2)  = [.39769208, .2821174]; % MAN
TAU_sec(2,1:2)  = [.29360625, .2255227]; % MIN
TAU_sec(3,1:2)  = [.40163863, .205356];  % TCPU
TAU_sec(4,1:2)  = [.31871402, .2300415]; % WHO
TAU_sec(5,1:2)  = [.31871402, .2300415]; % RET
TAU_sec(6,1:2)  = [.22449553, .1899633]; % SRV

% Change in the aggregate tax rate between 1987 and 2013
agg_change      = - (.306 - .18969);
% Homogeneous decline applied to each sector's initial tax rate
TAU_sec(:,3)    = TAU_sec(:,1) + agg_change;
% Save to PARMS
PARMS.TAU_sec   = TAU_sec;
