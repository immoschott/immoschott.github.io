% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

% Use SIC codes here that correspond to `secnames'
sics                       = [20, 10, 40, 50, 52, 70];

% Save the output
filename                        = sprintf('%s%s','Figure5','.csv');
Fig5.data                       = [LS_sec, sics'];
fullname                        = fullfile(PARMS.figfolder, filename);

writematrix(Fig5.data,fullname) 
fprintf('Saved data for Figure 5.\n');
clear sics