% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023
    
% Save output
filename                        = sprintf('%s%s','TableC1','.mat');
TabC1.data                      = datamoms;
TabC1.model                     = M_sec;
TabC1.names                     = secnames;
fullname                        = fullfile(PARMS.tabfolder, filename);
save(fullname,'TabC1'); % save as .mat file
fprintf('Saved data for Table C.1.\n');


     

