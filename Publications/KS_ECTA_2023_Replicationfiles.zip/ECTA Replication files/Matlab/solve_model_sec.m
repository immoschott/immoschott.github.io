% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

function output = solve_model_sec(datamoms,PARMS,jj) %#ok<*INUSL>

% Assign baseline parameters from PARMS object
GAMMA           = PARMS.GAMMA; %#ok<*NASGU>
w               = PARMS.w;
RHO_org         = PARMS.RHO_org;
DELTA           = PARMS.DELTA;

% Assign tax-specific tax rate
TAU             = PARMS.TAU_sec(jj,PARMS.BENCHMARK);

% Assign calibrated parameters
mu_eps          = PARMS.PARMS_sec(jj,1);
sigma_eps       = PARMS.PARMS_sec(jj,2);
x               = PARMS.PARMS_sec(jj,3);
betalow         = PARMS.PARMS_sec(jj,4);
m               = PARMS.PARMS_sec(jj,5);
ce              = PARMS.PARMS_sec(jj,6);

% Build productivity and capital share grids
build_grids_sec

% Define profits, output, and factor demand functions
set_functions

%% Bisection over the price of the output good

p_0             = 0.5; % lower bound price
p_1             = 1.5; % upper bound price
count_b         = 0;
nCount_b        = 100; % max number of iterations
eval            = 999;
crit_p          = 1e-06;

while (abs(eval) > crit_p) && (count_b <= nCount_b) % Bisection
    
    % Update the price guess
    update_p_guess_sec
    
    % Evaluate the value function at the current price guess
    V_all   = VAL(EPS,TAU,ALPHA_GRID,p_guess);
    
    % Evaluate the free-entry condition
    eval    = (pi_e*V_all)*weights - p_guess*ce;
    
    % Update bounds for the price guess
    if eval > crit_p
        p_1 = p_guess; % Price must fall
    elseif eval < crit_p
        p_0 = p_guess;% Price must increase
    end
    
    % Update counter
    count_b = count_b + 1;
    
end

% Save equilibrium price
pstar       = p_guess;

% Solve for stationary distribution
solve_dist

%% Optimal policy functions
% Dimension is EPS x ALPHA

% Labor demand policy
n_pol       = Nd(EPS,TAU,ALPHA_GRID,pstar);
% Capital demand policy
k_pol       = Kd(EPS,TAU,ALPHA_GRID,pstar);
% Real output function:
q_pol       = Q(EPS,TAU,ALPHA_GRID,pstar);
% Profits (pre-tax)
pi0_pol     = PI_B(EPS,TAU,ALPHA_GRID,p_guess);
% Profits (after tax)
pi1_pol     = PI_A(EPS,TAU,ALPHA_GRID,p_guess);
% Tax payments
tax_pol     = pi0_pol - pi1_pol;

% Find the mass of firms that ensures labor market clearing
Mstar       = PARMS.N_s / (n_pol(:)'*probst);


%% Compute aggregate outcomes

% Aggregate labor demand
N_d_star    = n_pol(:)'*probst*Mstar;
% Aggregate Capital demand
K_d_star    = k_pol(:)'*probst*Mstar;
% Aggregate real output
Q_star      = q_pol(:)'*probst*Mstar;
% Aggregate pre-tax profits
NIBT_star   = pi0_pol(:)'*probst*Mstar - pstar*ce*Mstar;
% Aggregate tax revenue
T_star      = tax_pol(:)'*probst*Mstar;
% Aggregate after-tax profits
NIAT_star   = NIBT_star - T_star;
% Aggregate demand
C_dem       = 1/pstar*(w*PARMS.N_s + NIBT_star) - DELTA*K_d_star;
% Aggregate resource constraint
C_res   = Q_star - DELTA*K_d_star - ce*Mstar;

% Compute model moments
assign_modelmoms_sec


%% Generate output for tables:

% Save model moments
output.mm       = cat(1,modelmoms{:,1}); %#ok<USENS>

% Save the equilibrium labor share
output.LS       = modelmoms{1,1}; 

fprintf('\n');

