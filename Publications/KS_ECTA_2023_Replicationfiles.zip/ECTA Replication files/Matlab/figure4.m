% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

tmpy                    = sum(q_pol.*dist*Mstar)/(Q_star); % Distribution of value added
a                       = betalow;
b                       = GAMMA;
c                       = (a+b)/2;
pdft1                   = 2*(fliplr(BETA(ALPHA_GRID))-a)/((b-a)*(c-a));
pdft2                   = 2*(fliplr(b-BETA(ALPHA_GRID)))/((b-a)*(b-c));
pdftm                   = 2/(b-a);
pdft                    = [pdft1(1:(lenalpha-1)/2) pdftm pdft2((lenalpha+1)/2+1:lenalpha)];

% Save the output
if PARMS.BENCHMARK  == 1
    filename            = sprintf('%s%s','Figure4a','.mat');
    Fig4a.x             = BETA(ALPHA_GRID);
    Fig4a.y1            = tmpy;
    Fig4a.y2            = pdft;
    fullname            = fullfile(PARMS.figfolder, filename);
    save(fullname,'Fig4a'); % save as .mat file
else
    if PARMS.TAU == 0.2
        filename        = sprintf('%s%s','Figure4b','.mat');
        Fig4b.x         = BETA(ALPHA_GRID);
        Fig4b.y1        = tmpy;
        Fig4b.y2        = pdft;
        fullname        = fullfile(PARMS.figfolder, filename);
        save(fullname,'Fig4b'); % save as .mat file
    end
end

fprintf('Saved data for Figure 4.\n');


