% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

if count_b == 0
    % Start with a good guess for the price
    if PARMS.BENCHMARK == 1
        p_guess = PARMS.p_guess(jj);
    else
        p_guess = 1;
    end
else
    p_guess = 0.5*p_0 + 0.5*p_1;
end
