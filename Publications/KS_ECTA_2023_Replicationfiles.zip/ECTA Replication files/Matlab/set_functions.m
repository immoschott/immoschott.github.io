% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

% Labor share as a function of the capital share
BETA            = @(ALPHA) GAMMA-ALPHA;

% Effective interest rate in the steady state
R               = @(tau) ((1-RHO)/RHO + DELTA) / (1-tau);

% Firm-level optimal decisions:
% 1) Labor demand: 
Nd              = @(eps,tau,ALPHA,p)    eps.^(1/(1-GAMMA)).*p.^((1-ALPHA)/(1-GAMMA)).*...
                    (BETA(ALPHA)/w).^((1-ALPHA)/(1-GAMMA)) .* (ALPHA./R(tau)).^(ALPHA/(1-GAMMA));        
% 2) Capital demand
Kd              = @(eps,tau,ALPHA,p)    eps.^(1/(1-GAMMA)).*p.^(BETA(ALPHA)/(1-GAMMA)).*...
                    (BETA(ALPHA)/w).^(BETA(ALPHA)/(1-GAMMA)) .* (ALPHA./R(tau)).^((1-BETA(ALPHA))/(1-GAMMA));
% 3) Output (real).
Q               = @(eps,tau,ALPHA,p) eps.^(1/(1-GAMMA)).*p.^(BETA(ALPHA)/(1-GAMMA)).* ...
                    (ALPHA./R(tau)).^(ALPHA/(1-GAMMA)) .* (BETA(ALPHA)/w).^(BETA(ALPHA)/(1-GAMMA));
% 4) Profits before taxes.
PI_B            = @(eps,tau,ALPHA,p) p.^((1-ALPHA)/(1-GAMMA)) .* eps.^(1/(1-GAMMA)) .* ...
                    (ALPHA./R(tau)).^(ALPHA/(1-GAMMA)) .* (BETA(ALPHA)/w).^(BETA(ALPHA)/(1-GAMMA)) .* (1-BETA(ALPHA));
% 5) After-tax Profits
PI_A            = @(eps,tau,ALPHA,p) (1-tau)*PI_B(eps,tau,ALPHA,p);

% 6) Instantaneous part of firm value function.
UTIL            = @(eps,tau,ALPHA,p) p.^((1-ALPHA)/(1-GAMMA)) .* eps.^(1/(1-GAMMA)) .* ...
                    (ALPHA./R(tau)).^(ALPHA/(1-GAMMA)) .* (BETA(ALPHA)/w).^(BETA(ALPHA)/(1-GAMMA)) .* ...
                    ((1-BETA(ALPHA))*(1-tau) - DELTA*ALPHA/R(tau));
% 7) Value function
VAL             = @(eps,tau,ALPHA,p) 1/(1-RHO) * UTIL(eps,tau,ALPHA,p);
