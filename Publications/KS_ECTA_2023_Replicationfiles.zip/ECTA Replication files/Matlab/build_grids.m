% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

% Construct labor share grid
BETA_GRID       = linspace(betalow,GAMMA,PARMS.lenalpha);
base            = GAMMA - betalow;
height          = 2/base; % The area of the triangle = 1, and A = h*b / 2,
slope           = height/(base/2);
tri_pdf         = @(x) (x-betalow)*slope;
weights         = [tri_pdf(BETA_GRID(1:ceil(PARMS.lenalpha/2))) ...
    fliplr(tri_pdf(BETA_GRID(1:floor(PARMS.lenalpha/2))))];
weights         = weights'/sum(weights);
lenalpha        = length(BETA_GRID(2:end-1));
weights         = weights(2:end-1);
weights         = flipud(weights);
ALPHA_GRID      = fliplr(GAMMA - BETA_GRID(2:end-1));
clear BETA_GRID base height slope tri_pdf

% Effective discount factor
RHO             = RHO_org*(1-x);

% Construct productivity grid
m               = sqrt(PARMS.leneps-1); 
EPS             = mu_eps + linspace(-m*sigma_eps,m*sigma_eps,PARMS.leneps)';
tmp             = normpdf(EPS,mu_eps,sigma_eps)';
invar           = tmp/sum(tmp);
tran_eps        = eye(PARMS.leneps);
EPS             = exp(EPS);
pi_e            = invar; % distribution of entrants over eps
clear m tmp
