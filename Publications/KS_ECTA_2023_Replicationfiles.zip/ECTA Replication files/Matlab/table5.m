% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

% Compute the inverse Pareto index 
emp_mass                        = n_pol(:).*probst*Mstar;
e                               = 250; % cutoff
inde                            = (0<=n_pol(:) & n_pol(:)<e);
massf                           = sum(probst(inde))/sum(probst);
masse                           = sum(emp_mass(inde));
paretom                         = log(1-massf);
paretoe                         = log(1-masse);
par_tail1                      = paretom/(paretom - paretoe);

% Save data for Table 5
if PARMS.BENCHMARK  == 1
    % Report tau, LS, median ratio, inverse Pareto index, avg size, price (normalized), cost of capital (normalized), capital (normalized)
    tmp                         = [PARMS.TAU; modelmoms{1}; modelmoms{2}; 1/par_tail1; modelmoms{3}; 1; 1; 1];
else
    relp                        = pstar / PARMS.out_bench.p;
    relr                        = R(TAU) / PARMS.out_bench.r;
    relK                        = K_d_star / PARMS.out_bench.K_d;
    tmp                         = [PARMS.TAU; modelmoms{1}; modelmoms{2}; 1/par_tail1; modelmoms{3}; relp; relr; relK];
end

% Save the output
if PARMS.BENCHMARK  == 1
    filename                    = sprintf('%s%s','Table5a','.mat');
    Tab5a                       = tmp;
    fullname                    = fullfile(PARMS.tabfolder, filename);
    save(fullname,'Tab5a'); % save as .mat file
elseif PARMS.BENCHMARK  == 0
    if PARMS.TAU    == 0.5
        filename                = sprintf('%s%s','Table5b','.mat');
        Tab5b                   = tmp;
        fullname                = fullfile(PARMS.tabfolder, filename);
        save(fullname,'Tab5b'); % save as .mat file
    elseif PARMS.TAU    == 0.2
        filename                = sprintf('%s%s','Table5c','.mat');
        Tab5c                   = tmp;        
        fullname                = fullfile(PARMS.tabfolder, filename);
        save(fullname,'Tab5c'); % save as .mat file
    end
end

fprintf('Saved data for Table 5.\n');



