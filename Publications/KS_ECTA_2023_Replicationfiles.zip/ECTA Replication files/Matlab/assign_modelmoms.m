% Matlab Code for replication of
% "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share"
% by Baris Kaymak and Immo Schott
% June 2023

%% Define model moments
modelmoms       = cell(1,1);

% Aggregate labor share
LS              = (n_pol(:)'*probst*Mstar) / (pstar*Q_star); % Total wage payments over total output
modelmoms{1,1}  = LS;

% Median labor share in 1967, value-added weighted
% Sort the firms by their labor share
[lssort, order] = sort(w*n_pol(:)./(pstar*q_pol(:)),'ascend');
% Apply the same order to value added distribution
va              = pstar*q_pol(:);
va              = va(order) / sum(va);
% Find weighted median labor share
idx             = find(cumsum(va)>=0.5,1,'first');
% Find the unweighted median labor share
firms           = probst(order) / sum(probst); 
idx_uw          = find(cumsum(firms)>=0.5,1,'first');
% VA-weighted median labor share divided by unweighted median labor share
modelmoms{2,1}  = lssort(idx)/lssort(idx_uw);
     
% Average employment
modelmoms{3,1}  = n_pol(:)'*probst/sum(probst);

% Concentration of employment in largest 4.25% of firms
%   (corresponds to 250+ in the data)
[nsort, order]  = sort(n_pol(:),'descend');
% Sum up employment in top 4.25% of firms 
firms           = probst(order) / sum(probst); 
idx             = find(cumsum(firms)>=0.0425,1,'first');
% Total employment in those firms:
modelmoms{4,1}  = sum(nsort(1:idx).*firms(1:idx)) / sum(nsort.*firms);

nummoms         = size(modelmoms,1);
