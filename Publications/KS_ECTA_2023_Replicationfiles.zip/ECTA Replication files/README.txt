* README 
* Replication files for
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" by Barıs Kaymak and Immo Schott
* Prepared: June 2023
* The authors used Matlab R2023a and Stata 15 to produce the results in the paper.

The folder that contains this README.txt file also contains the following folders and subfolders:

- DATA
	- Datasets
	- Data setup
		- Figures_data_setup
		- Tables_data_setup
- FIGURES
	- Figures_code
	- Figures_data
- TABLES
	- Tables_code
	- Tables_data
- MATLAB
	

GENERAL OVERVIEW:

To replicate the TABLES and FIGURES in the paper:
	For the figures, go to the FIGURES folder and open MASTER_FIGURE.do and MASTER_FIGURE.m. There is one Master file for the figures produced by Stata and one Master file for the figures produced in Matlab. 
	For the tables, go to the TABLES folder and open MASTER_TABLES.do and MASTER_TABLES.m. There is one Master file for the tables produced by Stata and one Master file for tables produced in Matlab. 
	The data that is used to reproduce the tables and figures is saved inside the FIGURES/FIGURES_data and TABLES/TABLES_data subdirectories. The content of those folders are generated and updated using respective files that re-run the data analysis and re-run the quantitative exercises (inside Data/Data_setup and inside Matlab).

	
To replicate the empirical data work:
	The data used throughout the paper is inside the DATA/DATASETS folder. The DATA directory contains a Master do file that explains how each of the individual datasets used throughout the paper was constructed. 
	Note that Compustat is a proprietary dataset. We therefore only provide highly aggregated Compustat data. 
	Documentation for Compustat is available at https://wrds-web.wharton.upenn.edu/wrds/support/Data.


To replicate the quantitative results of the model:
	To replicate the quantitative results of the model, go to the MATLAB folder. The main file is entitled "MAIN.m". The code generates the Matlab output that is saved in the TABLES_DATA and FIGURES_DATA subdirectories. Those files are then loaded as part of the FIGURES and TABLES Master files. 


LIST OF REQUIRED Stata PACKAGES:
	- Some packages might not be previously installed on your local Stata distribution.
	- You can use the following commands to install any missing packages.

ssc install tsmktim
ssc install kountry
ssc install freduse
ssc install reghdfe
net install grc1leg, from(http://www.stata.com/users/vwiggins)





