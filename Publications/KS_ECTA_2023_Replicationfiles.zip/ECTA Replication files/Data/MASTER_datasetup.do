* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Master file to import the data used in the empirical part of the paper

global path ".../Replication files/Data/Data_setup"
global datapath ".../Replication files/Data"
global figpath ".../Replication files/Figures/Figures_data"
global tabpath ".../Replication files/Tables/Tables_data"

cd "$path"

* Create data sets to replicate tables and figures

* Create data sets for figures
do Figures_data.do

* Create data sets for tables
do Tables_data.do

* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 


