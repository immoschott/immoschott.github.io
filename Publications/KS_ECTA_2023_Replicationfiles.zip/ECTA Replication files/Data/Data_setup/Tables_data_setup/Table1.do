* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table 1

cd "$datapath"

use KLEMS_OECD, clear

sort country year sector

keep if year>=1981 

keep LIS cit_aux sector year cid

lab var cit_aux "Corporate tax rate"

* Save dataset
compress
save "$tabpath/Table1.dta", replace

cd "$path"
