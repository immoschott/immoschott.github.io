* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table 8

cd "$datapath"

use STATELEVEL.dta, clear 

gen lw = log(avg_w)

lab var atr "Corporate tax rate"
lab var lw "Log Wage"
lab var unemp "Unemployment rate"

* Take out US, Alaska, Hawaii, DC, and overseas
drop if fips  == 0
drop if fips == 2
drop if fips == 11
drop if fips == 15
drop if fips >= 91

keep lis atr statefip year lw unemp

* Save dataset
compress
save "$tabpath/Table8.dta", replace

cd "$path"
