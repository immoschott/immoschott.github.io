* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table D.5 and Table D.6

cd "$datapath"

* Load NBER data
use sic581113, clear
* Merge with industry-level data 
merge 1:1 sic year using INDUSTRY.dta, keepus(teit EST_it)
drop if _merge==2
drop _merge
xtset sic year
g beta=pay/vadd

replace teit=teit*100

g lkn=log(cap/emp)
g lik=log(invest/piinv/cap)
g lin=log(invest/piinv/emp)
g lest=log(EST_it)

label var lkn "$\log(K/N)$"
label var lin "$\log(I/N)$"
label var lik "$\log(I/K)$"
label var lest "$\log(# estabs.)$"

keep sic year teit beta lkn lin lest lik

* Save dataset
compress
save "$tabpath/TableD5_D6.dta", replace

cd "$path"
