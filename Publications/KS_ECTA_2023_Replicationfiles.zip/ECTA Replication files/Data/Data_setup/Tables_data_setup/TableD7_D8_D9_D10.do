* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table D.7, D.8, D.9, and D.10

cd "$datapath"

* Load NBER data
use sic581113, clear
* Merge with industry-level data 
merge 1:1 sic year using INDUSTRY.dta, keepus(teit)
drop _merge
xtset sic year
merge 1:1 sic year using CONCENTRATION_ALL_SIC.dta

gen ls_NBER = pay/va

xtset sic year
drop if year<1972

* Match end of sample 2012 from Census to end of sample 2011 from NBER
replace ls=l1.ls if year==2012
replace teit=l1.teit if year==2012

* Match beginning of sample 1972 from Census to beginning of sample 1974 from tax data.
replace teit=f2.teit if year==1972

* Drop extreme observations with pareto index below 1 (industry share more than 100%)
foreach var of varlist con20 con20_va con50 con50_va {
	replace `var'=. if `var'>1
}

* Label variables
foreach num of numlist 4 8 20 50 {
	label var con`num' "sa-con`num'"
	label var con`num'_va "va-con`num'"
}
label var teit "Tax Rate (x100)"
label var ls_NBER "Labor Share"

keep con* ls_NBER teit year sic 



* Save dataset
compress
save "$tabpath/TableD7_D8_D9_D10.dta", replace

cd "$path"
