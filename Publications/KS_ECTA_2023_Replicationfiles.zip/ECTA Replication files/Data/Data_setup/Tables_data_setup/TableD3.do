* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table D.3

cd "$datapath"

use KLEMS_OECD, clear

sort country year sector

keep cit_aux LIS sector year country cid

* Save dataset
compress
save "$tabpath/TableD3.dta", replace

cd "$path"
