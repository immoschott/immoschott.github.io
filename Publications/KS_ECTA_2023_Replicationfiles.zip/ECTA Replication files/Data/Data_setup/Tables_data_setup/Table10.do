* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table 10

cd "$datapath"

* Load NBER data
use sic581113, clear
* Merge with industry-level data 
merge 1:1 sic year using INDUSTRY.dta, keepus(teit EST_it)
drop if _merge==2
drop _merge
xtset sic year
g beta=pay/vadd

replace teit=teit*100

g lest=log(EST_it)
label var lest "$\log(# estabs.)$"
label var teit "Tax Rate (x100)"
label var beta "Labor Share"

keep lest sic year teit beta 

* Save dataset
compress
save "$tabpath/Table10.dta", replace

cd "$path"
