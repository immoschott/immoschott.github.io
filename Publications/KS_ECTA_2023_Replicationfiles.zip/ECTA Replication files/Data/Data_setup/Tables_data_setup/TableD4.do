* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table D.4

cd "$datapath"

use STATELEVEL.dta, clear 

g lw=log(avg_w)

* Take out US, Alaska, Hawaii, DC, and overseas
drop if fips  == 0
drop if fips == 2
drop if fips == 11
drop if fips == 15
drop if fips >= 91

keep year statefip lw unemp atr lis

* Save dataset
compress
save "$tabpath/TableD4.dta", replace

cd "$path"
