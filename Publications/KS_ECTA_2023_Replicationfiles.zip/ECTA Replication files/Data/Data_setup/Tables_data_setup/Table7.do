* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table 7

cd "$datapath"

use Taxes_SIC_hist_all.dta, clear 

keep if year == 1985 | year == 2013
drop if SIC == 7 | SIC == 15 | SIC == 60

gen tmp = avg if year == 1985
bys SIC: egen tau85 = max(tmp)
drop tmp

gen tmp = avg if year == 2013
bys SIC: egen tau13 = max(tmp)
drop tmp

* Change in tax rate
gen dtax 	= tau13 - tau85

egen tmp = tag(SIC)
keep if tmp == 1

keep SIC tau85 tau13 dtax

merge 1:1 SIC using Compustat_LS_moments, nogen
sort SIC

* Save dataset
compress
save "$tabpath/Table7.dta", replace

cd "$path"

