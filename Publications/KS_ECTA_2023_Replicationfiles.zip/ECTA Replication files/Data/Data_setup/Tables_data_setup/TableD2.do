* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table D.2

cd "$datapath"

use PENN_OECD.dta, clear

egen cid=group(country)

lab var cit_aux "Corporate tax rate"
lab var lplk "Price of capital"

sort cid year

keep cid year lknhc lplk ltfp cit_aux

* Save dataset
compress
save "$tabpath/TableD2.dta", replace

cd "$path"
