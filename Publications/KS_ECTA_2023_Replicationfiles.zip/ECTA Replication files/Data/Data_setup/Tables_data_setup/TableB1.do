* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Table B.1

cd "$datapath"

use LS.dta, clear
drop if year < 1954
drop if year > 2011

* Compute decline in various measures between the first year and 2011 (last NBER year)
gen delta_LS_BEA_man 	= -100*(LS_BEA_man_2[1] - LS_BEA_man_4[58])
gen delta_PS_BEA_man 	= -100*(PS_BEA_man_2[1] - PS_BEA_man_4[58])
gen delta_LS_Census  	= -100*(LS_Census[1] - LS_Census[58])
gen delta_PS_Census  	= -100*(PS_Census[1] - PS_Census[58])
gen delta_PS_NBER 		= -100*(PS_NBER[5] - PS_NBER[58])
gen delta_LS_BLS_man 	= -100*(LS_BLS_man_SIC[1] - LS_BLS_man_NAICS[58])
ren delta_* d_*

lab var d_LS_BEA_man "NIPA / BEA"
lab var d_LS_BLS_man "BLS"
lab var d_LS_Census "Census"

lab var d_PS_BEA_man "NIPA / BEA"
lab var d_PS_Census "Census"
lab var d_PS_NBER "NBER"

keep d_LS_BEA_man d_LS_BLS_man d_LS_Census d_PS_BEA_man d_PS_Census d_PS_NBER
keep in 1

* Save dataset
compress
save "$tabpath/TableB1.dta", replace

cd "$path"
