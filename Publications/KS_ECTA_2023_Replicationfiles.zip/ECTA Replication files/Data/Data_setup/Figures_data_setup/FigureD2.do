* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure D.2

cd "$datapath"

use PENN_OECD.dta, clear

egen cid=group(country)

xtset cid year

by cid: egen miny=min(year) if cit!=. & lknhc!=. & lkna!=. & lkhhc!=.
by cid: egen maxy=max(year) if cit!=.  & lknhc!=. & lkna!=. & lkhhc!=.

* Create long differences
foreach var of varlist cit lkna lknhc lkhhc ltfp{
	gen first`var' = `var' if year == miny
	gen last`var' = `var' if year == maxy
	by cid: egen beg`var' = mean(first`var')
	by cid: egen end`var' = mean(last`var')
	gen d`var' = end`var'-beg`var'
}

* Only show the beginning-to-end changes once
gen grsample=1 if year==2007 

keep if grsample == 1
keep dlknhc dcit country_

* Save dataset
compress
save "$figpath/FigureD2.dta", replace

cd "$path"
