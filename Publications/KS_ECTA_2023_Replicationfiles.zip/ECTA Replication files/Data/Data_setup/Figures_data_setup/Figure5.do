* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

clear
cd "$datapath"

* Import model results from Matlab
import delimited "$figpath/Figure5.csv"
ren v4 SIC
ren v1 LS_ini
ren v2 LS_sec 
ren v3 LS_agg
* Compute LS changes
gen dls_hat_cal_sec14 = 100 * (LS_sec - LS_ini)
sort SIC
gen dls_hat_cal_com14 = 100 * (LS_agg - LS_ini)
keep SIC dls*
save Fig5_model.dta, replace

* Load data
use BEA_KLEMS_LS_1987_2014_SIC.dta, clear 
sort SIC year 

* Compute the initial share of wholesale trade in overall trade
qui su VA_BEA_KLEMS if SIC == 50 & year == 1987 
local aux = r(mean)
qui su VA_BEA_KLEMS if SIC == 999 & year == 1987 
local aux2 = r(mean)
local who_share = `aux' / `aux2'
* Compute the observed labor share decline 
g dLS14_BEA 	= 100 * s27.LS_SIC if year==2014

* Merge with Matlab results
merge m:1 SIC using Fig5_model.dta
erase Fig5_model.dta
* Generate results for Trade sector
qui su dls_hat_cal_sec14 if year == 2014 & SIC == 50
local tw1 = r(mean)
qui su dls_hat_cal_sec14 if year == 2014 & SIC == 52
local tr1 = r(mean)
replace dls_hat_cal_sec14 	= (`tr1'*(1-`who_share') + `tw1'*`who_share') if SIC==999

qui su dls_hat_cal_com14 if year == 2014 & SIC == 50
local tw2 = r(mean)
qui su dls_hat_cal_com14 if year == 2014 & SIC == 52
local tr2 = r(mean)
replace dls_hat_cal_com14 	= (`tr2'*(1-`who_share') + `tw2'*`who_share') if SIC==999

* Remove sectors without data
drop if SIC == 7 | SIC == 15 | SIC == 60 | SIC == 91 | SIC == 99 
keep if year == 2014

keep SIC dLS14_BEA dls_hat_cal_sec14 dls_hat_cal_com14 share_VA

* Shifts the data label for MIN a bit for better legibility
gen pos = 4
replace pos = 11 if SIC == 10

* Save dataset
compress
save "$figpath/Figure5.dta", replace

cd "$path"



	