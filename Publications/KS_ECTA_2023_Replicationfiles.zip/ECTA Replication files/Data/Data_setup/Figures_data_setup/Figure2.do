* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure 2

cd "$datapath"

use KLEMS_OECD, clear

* Multiply labor share by 100 to be in %
replace LIS = 100 * LIS

keep year LIS cit sector country_abbr

* Save dataset
compress
save "$figpath/Figure2.dta", replace

cd "$path"
