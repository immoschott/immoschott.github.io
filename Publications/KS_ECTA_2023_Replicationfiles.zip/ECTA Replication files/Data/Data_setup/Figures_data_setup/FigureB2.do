* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure B.2

cd "$datapath"

use LS.dta, clear
drop if year < 1963
* Create the different value added series from BEA KLEMS
* A) Value added
* 1) SIC-based from 1963 - 1997
* 2) NAICS-based from 1997-
* Note that KLEMS compensation is only available from 1987 onwards
* For the previous years we use the NIPA compensation
gen LS_tmp1 = COMP_BEA_man_2 / Valueadded_sic / 1000 
gen LS_tmp2 = Compensationofemployees_sic / Valueadded_sic 
gen LS_tmp3 = Compensationofemployees / Valueadded
replace LS_tmp2 = LS_tmp3 if LS_tmp2 == .

* B) Value added plus purchased service inputs
gen LSS_tmp1 = COMP_BEA_man_2 / (Valueadded_sic + Purchasedservicesinputs_sic) / 1000 
gen LSS_tmp2 = Compensationofemployees_sic / (Valueadded_sic + Purchasedservicesinputs_sic)
gen LSS_tmp3 = Compensationofemployees / (Valueadded + Purchasedservicesinputs)
replace LSS_tmp2 = LSS_tmp3 if LSS_tmp2 == .

* Labor share in %
replace LS_tmp1 = LS_tmp1 * 100
replace LS_tmp2 = LS_tmp2 * 100
replace LSS_tmp1 = LSS_tmp1 * 100
replace LSS_tmp2 = LSS_tmp2 * 100

* Compute service share in VA
gen Serv_share = Purchasedservicesinputs_sic / (Valueadded_sic + Purchasedservicesinputs_sic)
replace Serv_share = Purchasedservicesinputs / (Valueadded+Purchasedservicesinputs) if Serv_share == . 
lab var Serv_share "Purchased service share"
replace Serv_share = Serv_share * 100

keep year LSS_tmp? LS_tmp? Serv_share

* Save dataset
compress
save "$figpath/FigureB2.dta", replace

cd "$path"
