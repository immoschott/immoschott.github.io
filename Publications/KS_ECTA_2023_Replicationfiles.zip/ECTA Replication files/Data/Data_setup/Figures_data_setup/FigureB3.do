* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure B.3.

cd "$datapath"

use KLEMS_OECD, clear

* Remove countries with few observations from graph
g grsample    = 1 if year>=1981 & LIS <. & cit_aux < .
replace grsample= . if  cid==5 | cid==9 | cid== 18 | cid== 19 | cid==20| cid==21 | cid==22 | cid==26 | cid==27
replace country ="netherlands" if country=="nerlands"
g cname = proper(country)

keep if sector == 0 & grsample == 1 & cit_aux !=.
keep year LIS cit_aux cname 

* Save dataset
compress
save "$figpath/FigureB3.dta", replace

cd "$path"
