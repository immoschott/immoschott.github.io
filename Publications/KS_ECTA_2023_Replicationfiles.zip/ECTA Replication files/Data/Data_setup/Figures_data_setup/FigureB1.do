* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure B.1

cd "$datapath"

use LS.dta, clear
drop if year < 1948
drop if year > 2014

* Labor share measure based on BEA KLEMS
gen LS_BEA_KLEMS_man = Compensationofemployees_sic/Valueadded_sic
replace LS_BEA_KLEMS_man = Compensationofemployees/Valueadded if LS_BEA_KLEMS_man == .

* Express in % terms
replace LS_BEA_man_2 = LS_BEA_man_2 * 100
replace LS_BEA_man_4 = LS_BEA_man_4 * 100
replace LS_BEA_KLEMS_man = LS_BEA_KLEMS_man * 100
replace PS_BEA_man_2 = 100 * PS_BEA_man_2
replace PS_BEA_man_4 = 100 * PS_BEA_man_4
replace PS_NBER = 100 * PS_NBER
replace PS_Census = 100 * PS_Census
replace LS_Census = 100 * LS_Census
replace LS_BLS_man_SIC = 100 * LS_BLS_man_SIC
replace LS_BLS_man_NAICS = 100 * LS_BLS_man_NAICS

cap gen PS_BLS_man_SIC = .
cap gen PS_BLS_man_NAICS = .

keep year PS_BEA_man_2 PS_BEA_man_4 PS_BLS_man_SIC PS_BLS_man_NAICS ///
	PS_Census PS_NBER LS_BEA_man_2 LS_BEA_KLEMS_man LS_BLS_man_SIC LS_BLS_man_NAICS LS_Census

* Save dataset
compress
save "$figpath/FigureB1.dta", replace

cd "$path"
