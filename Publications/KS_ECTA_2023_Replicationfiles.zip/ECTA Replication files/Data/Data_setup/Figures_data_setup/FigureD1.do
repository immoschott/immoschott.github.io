* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure D.1

cd "$datapath"

* Use firm size data from the Census BDS database
use firmsizesic.dta, clear
replace sizeclass=13-sizeclass
sort year sic1 sizeclass
by year sic1 : egen totemp=sum(emp)
by year sic1 : egen totfirm=sum(firms)

g eshare=emp/totemp
g fshare=firms/totfirm

bysort year sic1 (sizeclass) : gen cumeshare = sum(eshare)
bysort year sic1 (sizeclass) : gen cumfshare = sum(fshare)

g pareto=log(cumfshare)/(log(cumfshare)-log(cumeshare))
g concentration=1/pareto

g avemp=totemp/totfirm

* Merge with sector-level labor share data
merge m:1 sic1 year using ls_majorsic_1987_2016.dta
drop _merge
g lshare=comp/va

drop if sic1==.
drop if fsize==""

egen obsid=group(fsize sic1)
xtset obsid year

* Other Sectors for Comparison
label define industry 7	"Agriculture" 10	"Mining" 15	"Construction" 20	"Manufacturing" 40	"T C and U", modify
label define industry 50	"Wholesale Trade" 52	"Retail Trade" 60	"FIRE" 70	"Services",modify
label values sic1 industry

* Construct long differences: 1987 - 2014
g dls=s27.lshare if year==2014
g dcon=s27.concentration if year==2014
g davemp=s27.avemp if year==2014


* Estimate long-run trends
g trlshare=.
g trcon=.
local c=1 /* size class. 1 is 10k+, 4 is 1000+, 6 is 250+ */ 
foreach num of numlist 07 10 15 20 40 50 52 60 70 {
	quietly reg lshare year if sic1==`num' & sizeclass==`c' & year>=1987 & year<=2016	
	replace trlshare=_b[year]*10 if sic1==`num' & year==2014
	quietly reg concentration year if sic1==`num' & sizeclass==`c' & year>=1987 & year<=2014	
	replace trcon=_b[year]*10 if sic1==`num' & year==2014	
}

keep year sic1 trcon trlshare concentration sizeclass
keep if sic1 == 20 

keep year concentration sizeclass

* Save temporary dataset
save D1_tmp.dta, replace 

import excel BDS_est_empconc.xlsx, sheet("Sheet1") firstrow clear
ren Year year

merge 1:m year using D1_tmp.dta, nogen
erase D1_tmp.dta

* Save dataset
compress
save "$figpath/FigureD1.dta", replace

cd "$path"
