* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure 6

cd "$datapath"

use STATELEVEL.dta, clear 

* Multiply labor shares and tax rates by 100 for % interpretation
replace lis = lis * 100
replace atr = atr * 100

keep lis atr year statefip  state_abbr
* Save dataset
compress
save "$figpath/Figure6.dta", replace

cd "$path"
