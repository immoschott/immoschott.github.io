* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure 3

cd "$datapath"

use KLEMS_OECD, clear

* Use first available year for countries that enter the database at a later date.
egen pid = group(cid sector)
xtset pid year
by pid: egen miny=min(year) if cit!=. & LIS!=.

* Multiply labor share by 100 to be in %
replace LIS = 100 * LIS

g firstLIS=LIS if year==miny
g firstcit=cit if year==miny
g lastLIS=LIS if year==2007
g lastcit=cit if year==2007

foreach var of varlist LIS cit{
	by pid: egen beg`var'=mean(first`var')
	by pid: egen end`var'=mean(last`var')
	g d`var'=end`var'-beg`var'
}

keep year sector country_abbr dLIS dcit 

* Save dataset
compress
save "$figpath/Figure3.dta", replace

cd "$path"
