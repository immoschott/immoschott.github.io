* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure 1

cd "$datapath"

use LS.dta, clear
drop if year < 1954
drop if year > 2016

* Backcast series for 1986-1997
gen LS_BEA_KLEMS_man = Compensationofemployees_sic/Valueadded_sic
replace LS_BEA_KLEMS_man = Compensationofemployees/Valueadded if LS_BEA_KLEMS_man == .
replace LS_BEA_man_4 = LS_BEA_KLEMS_man if LS_BEA_KLEMS_man <. & LS_BEA_man_4 == .

* Express in % terms
replace LS_Census = 100 * LS_Census
replace LS_BEA_man_2 = 100 * LS_BEA_man_2
replace LS_BEA_man_4 = 100 * LS_BEA_man_4
replace LS_BLS_agg = 100 * LS_BLS_agg

keep year LS_Census LS_BEA_man_2 LS_BEA_man_4 LS_BLS_agg

compress
* Save temporary dataset
save "$figpath/tmp1.dta"


use CTAX.dta, clear
drop if year < 1954
drop if year > 2016

merge  1:1 year using "$figpath/tmp1.dta"  , nogen

* Save dataset
save "$figpath/Figure1.dta", replace

* Cleaning
erase "$figpath/tmp1.dta"

cd "$path"
