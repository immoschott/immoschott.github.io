* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Create data set for Figure B.4 and Figure B.5

cd "$datapath"

use STATELEVEL.dta, clear

* Average tax rate in percent
gen atr100 = atr * 100

keep atr100 year lis atr statefip State

* Save dataset
compress
save "$figpath/FigureB4_B5.dta", replace

cd "$path"
