* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

* Data for Table 1
do Tables_data_setup/Table1.do

* Data for Table 8
do Tables_data_setup/Table8.do

* Data for Table 9
do Tables_data_setup/Table9.do

* Data for Table 10
do Tables_data_setup/Table10.do

* Data for Table 11
do Tables_data_setup/Table11.do

* * * 
* Appendix 
* * *

* Data for Table B.1
do Tables_data_setup/TableB1.do

* Data for Table D.1
do Tables_data_setup/TableD1.do

* Data for Table D.2
do Tables_data_setup/TableD2.do

* Data for Table D.3
do Tables_data_setup/TableD3.do

* Data for Table D.4
do Tables_data_setup/TableD4.do

* Data for Table D.5 and Table D.6
do Tables_data_setup/TableD5_D6.do

* Data for Table D.7, Table D.8, Table D.9, and Table D.10
do Tables_data_setup/TableD7_D8_D9_D10.do
