* Stata Code for replication of 
* "Corporate Tax Cuts and the Decline of the Manufacturing Labor Share" 
* by Baris Kaymak and Immo Schott
* June 2023

cd "$path"

* Data for Figure 1
do Figures_data_setup/Figure1.do

* Data for Figure 2
do Figures_data_setup/Figure2.do

* Data for Figure 3
do Figures_data_setup/Figure3.do

* Data for Figure 5
do Figures_data_setup/Figure5.do

* Data for Figure 6
do Figures_data_setup/Figure6.do

* * * 
* Appendix 
* * *

* Data for Figure B.1
do Figures_data_setup/FigureB1.do

* Data for Figure B.2
do Figures_data_setup/FigureB2.do

* Data for Figure B.3
do Figures_data_setup/FigureB3.do

* Data for Figure B.4 and B.5
do Figures_data_setup/FigureB4_B5.do

* Data for Figure D.1
do Figures_data_setup/FigureD1.do

* Data for Figure D.2
do Figures_data_setup/FigureD2.do




